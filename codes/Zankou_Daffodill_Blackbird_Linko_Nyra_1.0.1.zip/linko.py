import sys


def _load_team_module():
    import importlib.util
    from pathlib import Path

    key = "_zankou_wheelchair_team_module"
    team_path = Path(__file__).resolve().with_name("zankou.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_OPEN_LINKO_QE = _team.STAGE_OPEN_LINKO_QE
STAGE_LOOP_LINKO_PASS = _team.STAGE_LOOP_LINKO_PASS
STAGE_LOOP_LINKO_QE = _team.STAGE_LOOP_LINKO_QE
get_rotation = _team.get_rotation
advance_rotation = _team.advance_rotation
diag_sleep = _team.diag_sleep
wait_sound_idle = _team.wait_sound_idle
send_ultimate_with_diag = _team.send_ultimate_with_diag
sound_action_stamp = _team.sound_action_stamp
sound_action_changed = _team.sound_action_changed
make_stage_none_handler = _team.make_stage_none_handler
_reset_and_switch_to_alive = _team._reset_and_switch_to_alive

from src.char.Support import Support
from src.combat.planner import Planner, RoleProfile


class Linko(Support):
    cn_name = "灵可"
    en_name = "Linko"
    element = Support.ElementType.GREEN

    INTRO_WAIT = 0.7
    Q_POST_TIMEOUT = 4
    Q_POST_SEND_SLEEP = 0.1
    E1_TO_E2_WAIT = 0.5
    E2_TO_E3_WAIT = 0.5
    E3_TO_E4_WAIT = 3.5
    E4_TO_E5_WAIT = 3.5
    E5_TO_SELECT_WAIT = 2
    POST_SELECT_WAIT = 1.5
    E_FALLBACK_POST_SLEEP = 2
    Q_CHARGE_TIMEOUT = 5
    CHARGE_ATTACK_INTERVAL = 0.05
    # tight-input-loop 补 pacing
    SKILL_AFTER_SLEEP = 0.05

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.planner_handles_arc = True
        self._wait_switch_since = None

    def send_skill_key(self, after_sleep=0, interval=-1, down_time=0.01, action_name=None, wait_sound=True):
        if wait_sound:
            wait_sound_idle(self, label="灵可·E发键")
        self._skill_available = False
        return self.send_key(
            self.get_skill_key(),
            interval=interval,
            down_time=down_time,
            after_sleep=after_sleep,
            action_name=action_name,
        )

    def send_ultimate_key(self, after_sleep=0, interval=-1, down_time=0.01, action_name=None, **_):
        wait_sound_idle(self, label="灵可·Q发键")
        return super().send_ultimate_key(
            after_sleep=after_sleep, interval=interval, down_time=down_time, action_name=action_name
        )

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def wait_intro(self, time_out=-1, click=True):
        if self.has_intro:
            self.logger.info(f"[砍量] 灵可INTRO_WAIT 1.00→{self.INTRO_WAIT:.2f}s")
            diag_sleep(self, "灵可援护入场", self.INTRO_WAIT)

    def _ultimate_ready(self):
        value = self.ultimate_available()
        return bool(value) if value is not None else False

    def _charge_for_q(self):
        self.logger.info(
            f"[灵可] 循环轴 Q 不满，开始攒能（上限 {self.Q_CHARGE_TIMEOUT}s）"
        )
        start = self.clock.now()
        attacks = 0
        stamp = sound_action_stamp()
        while self.clock.now() - start <= self.Q_CHARGE_TIMEOUT:
            if self.is_dead:
                return False
            if self._ultimate_ready():
                self.logger.info(
                    f"[灵可] 攒能成功（普攻 {attacks} 次，耗时 {self.clock.now() - start:.2f}s）"
                )
                return True
            if sound_action_changed(stamp):
                self.logger.info("[灵可] 攒能检测到声音打断，补一次普攻保持段数")
                self.check_combat()
                self.click(interval=self.CHARGE_ATTACK_INTERVAL)
                stamp = sound_action_stamp()
                continue
            self.check_combat()
            self.click(interval=self.CHARGE_ATTACK_INTERVAL)
            stamp = sound_action_stamp()
            attacks += 1
        self.logger.warning(
            f"[灵可] 攒能 {self.Q_CHARGE_TIMEOUT}s 超时（普攻 {attacks} 次），强制放弃"
        )
        return False

    def _block_q_eeee_e_select(self, select_key: str, target_name: str, is_loop=False):
        if self.is_dead:
            self.logger.warning("[灵可] 角色阵亡，跳过本段")
            return False

        wait_sound_idle(self, label="灵可·入场稳定")

        q_ready = self._ultimate_ready()

        if is_loop and not q_ready:
            q_ready = self._ultimate_ready()
            if not q_ready:
                q_ready = self._charge_for_q()

        if not q_ready:
            q_ready = self._ultimate_ready()

        if not q_ready:
            self.logger.warning(
                "[灵可] Q 不可用（已重查），跳过 Q-EEEE-E5，放 E + 合击"
            )
            e_ready = self.skill_available()
            if not e_ready:
                e_ready = self.skill_available()
            if e_ready:
                e_start = self.clock.now()
                self.click_skill(down_time=0.05, post_sleep=self.E_FALLBACK_POST_SLEEP)
                self.logger.info(f"[诊断·灵可E(fallback)] click_skill 耗时={self.clock.now()-e_start:.2f}s")
                if self.is_dead:
                    return False
            else:
                self.logger.warning("[灵可] E 也不可用（已重查），仅合击")
            wait_sound_idle(self, label="灵可·合击(fallback)")
            self.logger.info(f"[灵可] 按 {select_key} 同频合击 {target_name}")
            self.send_key(select_key, down_time=0.1)
            self.logger.info(f"[砍量] 灵可POST_SELECT_WAIT(fallback) 2.20→{self.POST_SELECT_WAIT:.2f}s")
            diag_sleep(self, "灵可合击后（fallback）", self.POST_SELECT_WAIT)
            return not self.is_dead

        self.logger.info("[灵可] Q 进入过载")
        send_ultimate_with_diag(
            self, "灵可Q", self.Q_POST_TIMEOUT, self.Q_POST_SEND_SLEEP, retry=True
        )
        if self.is_dead:
            return False

        e_intervals = [
            ("灵可E1→E2", self.E1_TO_E2_WAIT),
            ("灵可E2→E3", self.E2_TO_E3_WAIT),
            ("灵可E3→E4", self.E3_TO_E4_WAIT),
            ("灵可E4→E5", self.E4_TO_E5_WAIT),
        ]
        for i, (label, wait) in enumerate(e_intervals):
            self.logger.info(f"[灵可] E{i + 1}")
            e_start = self.clock.now()
            # tight-input-loop 补 pacing
            self.send_skill_key(down_time=0.05, wait_sound=False, after_sleep=self.SKILL_AFTER_SLEEP)
            e_actual = self.clock.now() - e_start
            self.logger.info(f"[诊断·E发键] 灵可E{i+1} 耗时 {e_actual:.2f}s")
            if wait > 0:
                diag_sleep(self, label, wait)
            if self.is_dead:
                return False

        self.logger.info("[灵可] E5（弹轮盘）")
        e_start = self.clock.now()
        # tight-input-loop 补 pacing
        self.send_skill_key(down_time=0.05, wait_sound=False, after_sleep=self.SKILL_AFTER_SLEEP)
        self.logger.info(f"[诊断·E发键] 灵可E5 耗时 {self.clock.now()-e_start:.2f}s")
        if self.E5_TO_SELECT_WAIT > 0:
            diag_sleep(self, "灵可E5→合击", self.E5_TO_SELECT_WAIT)
        if self.is_dead:
            return False

        wait_sound_idle(self, label="灵可·合击(正常)")
        self.logger.info(f"[灵可] 按 {select_key} 同频合击 {target_name}")
        self.send_key(select_key, down_time=0.1)
        if self.POST_SELECT_WAIT > 0:
            self.logger.info(f"[砍量] 灵可POST_SELECT_WAIT 2.20→{self.POST_SELECT_WAIT:.2f}s")
            diag_sleep(self, "灵可合击后（正常）", self.POST_SELECT_WAIT)
        return not self.is_dead

    def combat_plan(self):
        rotation = get_rotation(self.task)
        handle_none = make_stage_none_handler(self, rotation)

        def entry():
            stage = rotation.stage_for(self)
            self.logger.info(f"[灵可入场] 阶段={stage}")

            if stage is None:
                handle_none()
                return
            self._wait_switch_since = None

            if self.is_dead:
                self.logger.warning("[灵可] 阵亡，重置轴")
                _reset_and_switch_to_alive(self, rotation, "灵可阵亡")
                return

            try:
                if stage == STAGE_OPEN_LINKO_QE:
                    self._block_q_eeee_e_select("1", "残虹", is_loop=False)
                elif stage == STAGE_LOOP_LINKO_QE:
                    self._block_q_eeee_e_select("2", "达芙蒂尔", is_loop=True)
                elif stage == STAGE_LOOP_LINKO_PASS:
                    self.logger.info("[灵可] 过场")
                else:
                    self.logger.error(f"[灵可异常] 未处理的阶段 {stage}，等待人工排查")
                    return
            except Exception as e:
                err_name = type(e).__name__
                if err_name == "TaskDisabledException":
                    raise
                if err_name == "NotInCombatException":
                    self.logger.warning("[灵可] 脱战，向外抛出")
                    raise
                self.logger.error(f"[灵可异常] {e}")

            try:
                self.task.next_frame()
            except Exception:
                pass

            if self.is_dead:
                self.logger.warning("[灵可] 阶段完成后阵亡，重置轴")
                _reset_and_switch_to_alive(self, rotation, "灵可完成后阵亡")
                return
            advance_rotation(self, rotation)

        return self.plan(entry=entry)