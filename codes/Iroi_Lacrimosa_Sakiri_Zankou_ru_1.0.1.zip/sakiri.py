# -*- coding: utf-8 -*-
"""
早雾（Sakiri）- 辅助 / QE buff手
排轴稿：Q → E，E图标进CD后立刻切人
"""

from src.char.BaseChar import BaseChar
from src.combat.planner import (
    CombatContext,
    Planner,
    RoleProfile,
)


class Sakiri(BaseChar):
    """早雾 - 辅助，QE buff手"""

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=2.0,
        )

    def combat_plan(self, context: CombatContext):
        qe_buff = self.planner_action(
            tags={
                Planner.ActionTag.ULTIMATE_ACTION,
                Planner.ActionTag.SKILL_ACTION,
                Planner.ActionTag.TEAM_BUFF,
            },
            slot=Planner.ActionSlot.SKILL,
            can_execute=lambda ctx: self._ultimate_ready() or self._skill_ready(),
            execute=lambda ctx: self._do_qe_buff(),
            reason="QE buff：有Q先Q→有E后E，E进CD立刻切人",
        )

        def entry():
            result = yield qe_buff
            if result:
                pass  # 切人由 strict route 控制

        return self.plan(qe_buff, entry=entry)

    def combat_policies(self, context: CombatContext):
        return None

    def _do_qe_buff(self):
        """Q → E，E进CD后立刻走"""
        if self._ultimate_ready():
            self.click_ultimate()   # Q
        if self._skill_ready():
            self.click_skill()      # E
            self._wait_skill_cd_icon()
        return True

    def _ultimate_ready(self):
        return self.ultimate_available()

    def _skill_ready(self):
        return self.skill_available()

    def _wait_skill_cd_icon(self):
        for _ in range(30):
            if not self._skill_ready():
                return
            self.sleep(0.1)
