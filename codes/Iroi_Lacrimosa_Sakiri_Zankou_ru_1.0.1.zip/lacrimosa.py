# -*- coding: utf-8 -*-
"""
安魂曲（Lacrimosa）- 副C / 远程合轴
排轴稿：
  - 战前按G切远程模式（全场仅一次）
  - 每轮循环放E番茄酱恶魔（动画3s + 等1s）
  - 远程合轴：a1远→a2远→a3远→预输入切残虹（a4远后台自动）
"""

from src.char.BaseChar import BaseChar
from src.combat.planner import (
    CombatContext,
    Planner,
    RoleProfile,
)

class Lacrimosa(BaseChar):
    """安魂曲 - 副C，远程合轴输出"""

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUB_DPS,
            field_preference=Planner.FieldPreference.SUB_DPS,
            max_field_time=3.0,
        )

    def combat_plan(self, context: CombatContext):
        self._init_state()

        act_switch_remote = self.planner_action(
            tags={Planner.ActionTag.SUPPORT},
            slot=None,
            name="lacri_switch_remote",
            can_execute=lambda ctx: not self.remote_mode,
            execute=lambda ctx: self._do_switch_remote(),
            reason="战前按G切远程模式（全场仅一次）",
        )

        act_e_tomato = self.planner_action(
            tags={Planner.ActionTag.SKILL_ACTION, Planner.ActionTag.TEAM_BUFF},
            slot=Planner.ActionSlot.SKILL,
            name="lacri_e_tomato",
            can_execute=lambda ctx: self._can_e(),
            execute=lambda ctx: self._do_e_tomato(),
            reason="E番茄酱恶魔，动画3s + 等1s",
        )

        act_remote_fusion = self.planner_action(
            tags={Planner.ActionTag.SUPPORT, Planner.ActionTag.COORDINATION},
            slot=Planner.ActionSlot.ARC,
            name="lacri_remote_fusion",
            can_execute=lambda ctx: self.remote_mode,
            execute=lambda ctx: self._do_remote_fusion(),
            reason="远程合轴：a1远→a2远→a3远→预输入（a4远后台自动）",
        )

        def entry():
            if not self.remote_mode:
                result = yield act_switch_remote
                if result:
                    self.remote_mode = True
                return
            # E番茄酱恶魔（步骤3）
            if self._skill_ready():
                result = yield act_e_tomato
                if result:
                    pass  # 切人由 route 控制
                return
            # 远程合轴（步骤6/8）
            result = yield act_remote_fusion
            if result:
                pass  # 切人由 route 控制

        return self.plan(act_switch_remote, act_e_tomato, act_remote_fusion, entry=entry)

    def combat_policies(self, context: CombatContext):
        return None

    def _init_state(self):
        if not hasattr(self, "remote_mode"):
            self.remote_mode = False

    def _can_e(self):
        return self.remote_mode and self._skill_ready()

    def _do_switch_remote(self):
        self.send_key("g")
        self.sleep(0.2)
        self.remote_mode = True 
        return True

    def _do_e_tomato(self):
        if self._ultimate_ready():
            self.click_ultimate()
            self.sleep(0.2)
        self.click_skill()
        return True

    def _do_remote_fusion(self):
        if self._ultimate_ready():
            self.click_ultimate()       # Q2焚天（时停）
            self.sleep(0.2)
            return True
        self.click()
        self.sleep(0.3)
        self.click()
        self.sleep(0.3)
        self.click()
        self.sleep(0.3)
        self.click()       # 预输入
        return True

    
    def _skill_ready(self):
        return self.skill_available()
    
    def _ultimate_ready(self):
         return self.ultimate_available()