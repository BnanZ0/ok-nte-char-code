# -*- coding: utf-8 -*-
"""
残虹（Zankou）- 主C / 站场核心
排轴稿：
  - 0觉首轮：大连段(z→e绯影闪→幻境a1×6→e离魂错) → Q1血宴 → Q2焚天+a1z
  - 1觉循环：6段交替合轴(a1z + 预输入)，Q满插共天a1z
  - 每次z重击后预输入切安魂曲，后台自动放a5合轴
"""

from src.char.BaseChar import BaseChar
from src.combat.planner import (
    CombatContext,
    FollowupStep,
    Planner,
    RoleProfile,
)
from src.Labels import Labels


class Zankou(BaseChar):
    """残虹 - 主C，站场输出核心"""

    STAGE_BIG_COMBO = "big_combo"
    STAGE_Q1 = "q1"
    STAGE_Q2 = "q2"
    STAGE_LOOP = "loop"

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.MAIN_DPS,
            field_preference=Planner.FieldPreference.MAIN_DPS,
            max_field_time=8.0,
        )

    def combat_policies(self, context: CombatContext):
        """0觉首轮 + 1觉循环头 完整排轴（strict route 压过 element reaction）。"""
        context.request_route(
            [
                # ---- 0觉首轮 ----
                FollowupStep(reason="0觉1：早雾QE", slot=Planner.ActionSlot.SKILL,
                             target_names={"早雾", "Sakiri"}),
                FollowupStep(reason="0觉2：伊洛伊援护e", slot=Planner.ActionSlot.ENTRY_REACTION,
                             target_names={"伊洛伊", "Iroi"}),
                FollowupStep(reason="0觉3：安魂曲E", slot=Planner.ActionSlot.SKILL,
                             target_names={"安魂曲", "Lacrimosa"}),
                FollowupStep(reason="0觉4：伊洛伊qza1", slot=Planner.ActionSlot.ULTIMATE,
                             target_names={"伊洛伊", "Iroi"}),
                FollowupStep(reason="0觉5：残虹大连段", slot=Planner.ActionSlot.SKILL,
                             action_names={"zankou_big_combo"}, target_names={"残虹", "Zankou"}),
                FollowupStep(reason="0觉6：安魂曲远合轴", slot=Planner.ActionSlot.ARC,
                             target_names={"安魂曲", "Lacrimosa"}),
                FollowupStep(reason="0觉7：残虹Q1血宴", slot=Planner.ActionSlot.ULTIMATE,
                             action_names={"zankou_q1"}, target_names={"残虹", "Zankou"}),
                FollowupStep(reason="0觉8：安魂曲远合轴", slot=Planner.ActionSlot.ARC,
                             target_names={"安魂曲", "Lacrimosa"}),
                FollowupStep(reason="0觉9：残虹Q2焚天+a1z", slot=Planner.ActionSlot.ULTIMATE,
                             action_names={"zankou_q2"}, target_names={"残虹", "Zankou"}),
                # ---- 1觉循环头 ----
                FollowupStep(reason="循环头1：伊洛伊援护e", slot=Planner.ActionSlot.ENTRY_REACTION,
                             target_names={"伊洛伊", "Iroi"}),
                FollowupStep(reason="循环头2：早雾QE", slot=Planner.ActionSlot.SKILL,
                             target_names={"早雾", "Sakiri"}),
                FollowupStep(reason="循环头3：安魂曲E", slot=Planner.ActionSlot.SKILL,
                             target_names={"安魂曲", "Lacrimosa"}),
                FollowupStep(reason="循环头4：伊洛伊qza1", slot=Planner.ActionSlot.ULTIMATE,
                             target_names={"伊洛伊", "Iroi"}),
                FollowupStep(reason="循环头5：安魂曲远合轴", slot=Planner.ActionSlot.ARC,
                             target_names={"安魂曲", "Lacrimosa"}),
            ],
            reason="残虹队完整排轴（0觉首轮+1觉循环头）",
        )

    def combat_plan(self, context: CombatContext):
        self._init_state()

        act_big_combo = self.planner_action(
            tags={Planner.ActionTag.SKILL_ACTION, Planner.ActionTag.COORDINATION},
            slot=Planner.ActionSlot.SKILL,
            name="zankou_big_combo",
            can_execute=lambda ctx: self.stage == self.STAGE_BIG_COMBO,
            execute=lambda ctx: self._do_big_combo(),
            reason="0觉首轮大连段：z→e绯影闪→幻境a1×6→e离魂错",
        )

        act_q1 = self.planner_action(
            tags={Planner.ActionTag.ULTIMATE_ACTION},
            slot=Planner.ActionSlot.ULTIMATE,
            name="zankou_q1",
            can_execute=lambda ctx: True,
            execute=lambda ctx: self._do_q1(),
            reason="Q1血宴入梦（等Q变紫后点按Q）",
        )

        act_q2 = self.planner_action(
            tags={Planner.ActionTag.ULTIMATE_ACTION, Planner.ActionTag.TEAM_BUFF},
            slot=Planner.ActionSlot.ULTIMATE,
            name="zankou_q2",
            can_execute=lambda ctx: True,
            execute=lambda ctx: self._do_q2(),
            reason="Q2焚天烬灭舞→a1→z→预输入",
        )

        act_fentian_az = self.planner_action(
            tags={Planner.ActionTag.ULTIMATE_ACTION, Planner.ActionTag.SUPPORT},
            slot=Planner.ActionSlot.ULTIMATE,
            name="zankou_fentian_az",
            can_execute=lambda ctx: self.stage == self.STAGE_LOOP and self._ultimate_ready(),
            execute=lambda ctx: self._do_fentian_az(),
            reason="共天a1z：[Q焚天时停]→a1→z→预输入",
        )

        act_fusion_az_wait = self.planner_action(
            tags={Planner.ActionTag.SUPPORT, Planner.ActionTag.COORDINATION},
            slot=Planner.ActionSlot.ARC,
            name="zankou_fusion_az_wait",
            can_execute=lambda ctx: self.stage == self.STAGE_LOOP and self.fusion_segment % 6 in (1, 2),
            execute=lambda ctx: self._do_fusion_az_wait(),
            reason="无a1z：等a5收尾(1.2s)→a1→z→预输入",
        )

        act_fusion_az = self.planner_action(
            tags={Planner.ActionTag.SUPPORT, Planner.ActionTag.COORDINATION},
            slot=Planner.ActionSlot.ARC,
            name="zankou_fusion_az",
            can_execute=lambda ctx: self.stage == self.STAGE_LOOP and self.fusion_segment % 6 in (0, 3),
            execute=lambda ctx: self._do_fusion_az(),
            reason="普通a1z：a1→z→预输入",
        )

        act_fusion_az_final = self.planner_action(
            tags={Planner.ActionTag.SUPPORT, Planner.ActionTag.COORDINATION},
            slot=Planner.ActionSlot.ARC,
            name="zankou_fusion_az_final",
            can_execute=lambda ctx: self.stage == self.STAGE_LOOP and self.fusion_segment % 6 == 5,
            execute=lambda ctx: self._do_fusion_az_final(),
            reason="循环末段a1z：a1→z（不预输入），之后切伊洛伊",
        )

        act_assist_az = self.planner_action(
            tags={Planner.ActionTag.SUPPORT, Planner.ActionTag.COORDINATION},
            slot=Planner.ActionSlot.ARC,
            name="zankou_assist_az",
            can_execute=lambda ctx: self.stage == self.STAGE_LOOP and self.fusion_segment % 6 == 4,
            execute=lambda ctx: self._do_assist_az(),
            reason="援护a1z：[残虹援护自动]→a1→z→预输入",
        )

        def entry():
            if self.stage == self.STAGE_BIG_COMBO:
                yield act_big_combo
            elif self.stage == self.STAGE_Q1:
                yield act_q1
            elif self.stage == self.STAGE_Q2:
                yield act_q2
            else:  # STAGE_LOOP：6段合轴循环
                seg = self.fusion_segment % 6
                if seg == 0:
                    yield (act_fentian_az if self._ultimate_ready() else act_fusion_az)
                elif seg in (1, 2):
                    yield act_fusion_az_wait
                elif seg == 3:
                    yield act_fusion_az
                elif seg == 4:
                    yield act_assist_az
                else:  # seg == 5
                    yield act_fusion_az_final

        return self.plan(
            act_big_combo, act_q1, act_q2, act_fentian_az,
            act_fusion_az_wait, act_fusion_az, act_fusion_az_final, act_assist_az,
            claims=None,
            entry=entry,
        )

    def _init_state(self):
        if not hasattr(self, "stage"):
            self.stage = self.STAGE_BIG_COMBO
            self.fusion_segment = 0

    def _ultimate_ready(self, stage=None):
        return self.ultimate_available()

    # ---- execute（严格按排轴稿）----
    def _do_big_combo(self):
        self._wait_assist_animation()
        """大连段（3.2）：z绰影 → e绯影闪(进幻境) → 幻境a1a2a3a4a1a2 → e离魂错(回现实)"""
        self.heavy_attack(1.0)      # ① z 绰影（长按重击，解锁强化E）
        self.sleep(0.6)
        if self._find_skill_gold():
            self.send_key("e")       # ② e 绯影闪 → 进幻境
            self.sleep(0.6)
        else:
            while True:
                self.heavy_attack(1.0)
                self.sleep(0.45)
                if self._find_skill_gold():
                 break
        self.send_key("e")           # ② e：绯影闪 → 进幻境
        self.sleep(0.6)
        while True:
            self.click()
            self.sleep(0.45)
            if self._find_skill_purple():
                break
        self.send_key("e")           # ③ e：离魂错 → 回现实（有动画时间）
        self.sleep(1.3)
        self.stage = self.STAGE_Q1   # 离魂错后Q变紫，进入Q1阶段
        return True

    def _do_q1(self):
        """Q1血宴入梦（3.1步骤7）：等Q变紫后点按Q"""
        self._wait_ultimate_purple()
        self.click_ultimate()
        self.sleep(0.5)
        self.stage = self.STAGE_Q2
        return True

    def _do_q2(self):
        """Q2焚天烬灭舞 → a1 → z → 预输入（3.1步骤9）"""
        self.click_ultimate()        # Q2焚天（时停）
        self.sleep(0.2)
        self.click()                 # a1 (0.6s)
        self.sleep(0.3)
        self.heavy_attack(1.0)       # z (1.0s)
        self.click()                 # 预输入（点按一下左键）
        self.stage = self.STAGE_LOOP
        self.fusion_segment = 0
        return True

    def _do_fentian_az(self):
        """共天a1z（4.2段1）：Q焚天时停 → a1 → z → 预输入"""
        self.click_ultimate()
        self.sleep(0.2)
        self.click()
        self.sleep(0.3)
        self.heavy_attack(1.0)
        self.click()
        self.fusion_segment += 1
        return True

    def _do_fusion_az_wait(self):
        """无a1z（4.2段2/3）：等a5收尾(1.2s)→a1→z→预输入"""
        self.sleep(1.2)
        self.click()
        self.sleep(0.3)
        self.heavy_attack(1.0)
        self.click()
        self.fusion_segment += 1
        return True

    def _do_fusion_az(self):
        """普通a1z（4.2段1/4）：a1→z→预输入"""
        self.click()
        self.sleep(0.3)
        self.heavy_attack(1.0)
        self.click()
        self.fusion_segment += 1
        return True

    def _do_fusion_az_final(self):
        """循环末段a1z（4.2段6）：a1→z（不预输入）"""
        self.click()
        self.sleep(0.3)
        self.heavy_attack(1.0)
        self.fusion_segment += 1
        return True

    def _do_assist_az(self):
        """援护a1z（4.2段5）：等援护动画→a1→z→预输入"""
        self._wait_assist_animation()
        while True:
            self.heavy_attack(1.0)
            self.sleep(0.45)
            if self._find_skill_gold():
                break
        self.send_key("e")
        self.sleep(0.5)
        while True:
            self.click()
            self.sleep(0.25)
            if self._find_skill_purple():              
                break
        self.send_key("e")
        self.sleep(2.1)
        self.click_ultimate() 
        self.click()
        self.fusion_segment += 1
        return True

    def _wait_ultimate_purple(self):
        for _ in range(50):
            if self.ultimate_available():
                return
            self.sleep(0.1)

    def _wait_assist_animation(self):
        self.sleep(0.5)

    def _find_skill_purple(self):
        return self.task.find_one(Labels.zankou_skill_purple) is not None

    def _find_skill_gold(self):
        return self.task.find_one(Labels.zankou_skill_gold) is not None
