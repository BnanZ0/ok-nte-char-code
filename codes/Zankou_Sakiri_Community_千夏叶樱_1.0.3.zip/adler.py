"""残虹倾陷早雾分支的阿德勒护盾轮转。"""

from src.char.Adler import Adler
from src.combat.planner import Planner, RoleProfile


class CommunityAdlerSakiri(Adler):
    """部署护盾，按情况释放 Q，然后把站场时间交还给残虹。"""

    cn_name = "阿德勒（早雾分支）"
    en_name = "Adler (Sakiri Branch)"

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan, add_tags=Planner.ActionTag.TEAM_BUFF)
        self.register_ultimate(plan)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        if self.skill_available() and self.combat_context.is_slot_available(self, Planner.ActionSlot.SKILL):
            self.continues_normal_attack(1.5)
        if self.click_skill():
            self.sleep(0.5)
            self.click_ultimate()
