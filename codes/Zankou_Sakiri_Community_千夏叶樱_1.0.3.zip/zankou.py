"""残虹倾陷早雾分支的残虹轮转。"""

from src.char.Zankou import Zankou
from src.combat.planner import Planner


class CommunityZankouSakiri(Zankou):
    """点亮强化 E，并在紫 E 窗口完成双 Q。"""

    cn_name = "残虹（早雾分支）"
    en_name = "Zankou (Sakiri Branch)"
    COMBO_TIMEOUT = 10.0
    HEAVY_ATTACK_TIME = 0.45
    PURPLE_ULTIMATE_WAIT = 3.0

    def combat_plan(self):
        plan = self.plan()
        plan.register(
            self.perform_skill_combo,
            tags={
                Planner.ActionTag.DEFAULT_ACTION,
                Planner.ActionTag.SKILL_ACTION,
                Planner.ActionTag.HIGH_PRIORITY,
            },
            slot=Planner.ActionSlot.SKILL,
            name="community_zankou_skill_combo",
            reason="残虹重击点亮黄 E，并在紫 E 窗口完成双 Q",
            can_execute=lambda: True,
            priority_ready=lambda: True,
        )
        self.register_ultimate(plan)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        if not self.find_ult_purple():
            if self.perform_skill_combo():
                self.task.wait_until(
                    self.find_ult_purple,
                    post_action=self.click_with_interval,
                    time_out=self.PURPLE_ULTIMATE_WAIT,
                )
        if self.find_ult_purple():
            if self.click_ultimate():
                self.task.wait_until(
                    self.ultimate_available,
                    post_action=self.click_with_interval,
                    time_out=3.0,
                )
                self.click_ultimate()

    def perform_skill_combo(self):
        """依据技能视觉状态执行轮转，并为循环设置明确时限。"""

        timer = self.clock.timer(timeout=self.COMBO_TIMEOUT)
        clicked_skill = False

        while not timer.expired():
            feature = self.find_zankou_skill()
            if feature:
                skill_clicked, _ = self.click_zankou_skill()
                clicked_skill = clicked_skill or bool(skill_clicked)
                if self.find_ult_purple():
                    break
            else:
                self.heavy_attack(duration=self.HEAVY_ATTACK_TIME)

            self.sleep(0.1)
            if self.find_ult_purple():
                break

            try:
                self.task.mouse_down()
                for _ in range(5):
                    if self.find_zankou_skill() or self.find_ult_purple():
                        break
                    self.sleep(0.1)
            finally:
                self.task.mouse_up()

        return clicked_skill
