"""黑羽的固定轴执行器外壳 (详见 ``_puppet.py`` 的说明)。"""

from src.char.Blackbird import Blackbird

from ._puppet import RotationPuppet


class BlackbirdPuppet(RotationPuppet, Blackbird):
    """黑羽: 只在明音脚本的第 2 / 5 步被切上场按键, 不自己开一段大。"""

    cn_name = "黑羽（固定轴）"
    en_name = "Blackbird (Fixed Rotation)"
