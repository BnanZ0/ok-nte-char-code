"""浔(老板娘)的固定轴执行器外壳 (详见 ``_puppet.py`` 的说明)。"""

from src.char.Hotori import Hotori

from ._puppet import RotationPuppet


class HotoriPuppet(RotationPuppet, Hotori):
    """浔: 只按明音脚本发的 Q/E, 不自己开记录窗口和大招。"""

    cn_name = "浔（固定轴）"
    en_name = "Hotori (Fixed Rotation)"
