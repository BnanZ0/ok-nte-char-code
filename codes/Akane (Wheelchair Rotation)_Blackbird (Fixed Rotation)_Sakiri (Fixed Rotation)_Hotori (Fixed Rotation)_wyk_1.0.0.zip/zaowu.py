"""早雾的固定轴执行器外壳 (详见 ``_puppet.py`` 的说明)。"""

from src.char.Sakiri import Sakiri

from ._puppet import RotationPuppet


class SakiriPuppet(RotationPuppet, Sakiri):
    """早雾: 按键全部由明音脚本发送, 自己不参与 planner 调度。"""

    cn_name = "早雾（固定轴）"
    en_name = "Sakiri (Fixed Rotation)"
