"""Self-contained Lacrimosa window for the Zankou dual-core team."""

from src.char.Lacrimosa import Lacrimosa
from src.combat.planner import Planner, RoleProfile


class DualCoreLacrimosa(Lacrimosa):
    """接过残虹爆发，完成 Q/E 和短普攻窗口后交回辅助与残虹。"""

    cn_name = "安魂曲（残虹双核）"
    en_name = "Lacrimosa (Zankou Dual Core)"
    WINDOW_SECONDS = 6.5
    SUPPORT_ROUTE_TIMEOUT = 12.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._dual_core_support_route_active = False

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self):
        plan = self.plan()
        plan.register(
            self._run_window,
            tags={
                Planner.ActionTag.DEFAULT_ACTION,
                Planner.ActionTag.DAMAGE,
                Planner.ActionTag.HIGH_PRIORITY,
            },
            slot=Planner.ActionSlot.CUSTOM,
            name="dual_core_lacrimosa_window",
            reason="安魂曲完整 Q/E/普攻窗口",
            can_execute=lambda: self.combat_context.strict_route_wants_action(
                self, slot=Planner.ActionSlot.CUSTOM,
            ),
            priority_ready=lambda: False,
        )
        return plan

    def _run_window(self):
        executed = False
        try:
            if self.ultimate_available():
                executed = bool(self.click_ultimate()) or executed
            if self.skill_available():
                executed = bool(self.click_skill()) or executed
            for _ in range(5):
                if getattr(self, "is_dead", False) or not getattr(self, "is_current_char", True):
                    break
                self.normal_attack()
                executed = True
                self.sleep(0.16)
        finally:
            self._request_support_handoff()
        return executed

    @staticmethod
    def _find_character(chars, aliases):
        aliases = {str(value).casefold() for value in aliases}
        for char in chars or ():
            if char is None or getattr(char, "is_dead", False):
                continue
            values = {
                str(getattr(char, key, "")).casefold()
                for key in ("name", "char_name", "cn_name", "ufn_name", "impl_id")
            }
            if values & aliases:
                return char
        return None

    def _request_support_handoff(self):
        if self._dual_core_support_route_active:
            return False
        chars = getattr(self.task, "chars", ()) or ()
        adler = self._find_character(chars, {"阿德勒", "adler", "builtin:adler"})
        sakiri = self._find_character(chars, {"早雾", "sakiri", "builtin:sakiri"})
        zankou = self._find_character(
            chars,
            {"dualcorezankou", "残虹（安魂曲双核）", "残虹", "zankou"},
        )
        if zankou is None:
            return False
        steps = []
        if adler is not None:
            steps.append(Planner.Route.action(adler, slot=Planner.ActionSlot.SKILL, optional=True))
        if sakiri is not None:
            steps.extend([
                Planner.Route.action(sakiri, slot=Planner.ActionSlot.ULTIMATE, optional=True),
                Planner.Route.action(sakiri, slot=Planner.ActionSlot.SKILL, optional=True),
            ])
        # A character step runs the full combo and both Q attempts once.
        steps.append(zankou)
        route = self.combat_context.request_route(
            steps,
            reason="双核循环：安魂曲 → 阿德勒/早雾 → 残虹",
            timeout=self.SUPPORT_ROUTE_TIMEOUT,
        )
        if route is None:
            return False
        self._dual_core_support_route_active = True
        route.on_finish(self._clear_support_route)
        return True

    def _clear_support_route(self):
        self._dual_core_support_route_active = False
