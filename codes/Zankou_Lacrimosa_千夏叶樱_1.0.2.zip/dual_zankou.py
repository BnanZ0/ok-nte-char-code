"""Self-contained Zankou handoff for the Lacrimosa dual-core team."""

from src.Labels import Labels
from src.char.Zankou import Zankou
from src.combat.planner import Planner, RoleProfile


class DualCoreZankou(Zankou):
    """先完成黄 E、紫 E 和双 Q，再把前台交给安魂曲。"""

    cn_name = "残虹（安魂曲双核）"
    en_name = "Zankou (Lacrimosa Dual Core)"
    COMBO_TIMEOUT = 10.0
    HEAVY_ATTACK_TIME = 0.45
    PURPLE_ULTIMATE_WAIT = 3.0
    HANDOFF_TIMEOUT = 12.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._dual_core_handoff_active = False

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
            combat_start_priority=1000,
        )

    def combat_plan(self):
        plan = self.plan()
        plan.register(
            self.perform_skill_combo,
            tags={
                Planner.ActionTag.DEFAULT_ACTION,
                Planner.ActionTag.SKILL_ACTION,
                Planner.ActionTag.HIGH_PRIORITY,
            },
            slot=Planner.ActionSlot.SKILL,
            name="dual_core_zankou_skill_combo",
            reason="残虹重击点亮黄 E，并在紫 E 窗口完成双 Q",
            can_execute=lambda: True,
            priority_ready=lambda: True,
        )
        self.register_ultimate(plan)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        if not self.find_ult_purple():
            if self.perform_skill_combo():
                self.task.wait_until(
                    self.find_ult_purple,
                    post_action=self.click_with_interval,
                    time_out=self.PURPLE_ULTIMATE_WAIT,
                )
        if self.find_ult_purple():
            if self.click_ultimate():
                self.task.wait_until(
                    self.ultimate_available,
                    post_action=self.click_with_interval,
                    time_out=3.0,
                )
                second_q = self.click_ultimate()
                if second_q:
                    self._request_lacrimosa_handoff()

    def perform_skill_combo(self):
        timer = self.clock.timer(timeout=self.COMBO_TIMEOUT)
        clicked_skill = False
        while not timer.expired():
            feature = self.find_zankou_skill()
            if feature:
                skill_clicked, _ = self.click_zankou_skill()
                clicked_skill = clicked_skill or bool(skill_clicked)
                if self.find_ult_purple():
                    break
            else:
                self.heavy_attack(duration=self.HEAVY_ATTACK_TIME)

            self.sleep(0.1)
            if self.find_ult_purple():
                break

            try:
                self.task.mouse_down()
                for _ in range(5):
                    if self.find_zankou_skill() or self.find_ult_purple():
                        break
                    self.sleep(0.1)
            finally:
                self.task.mouse_up()
        return clicked_skill

    def find_zankou_skill(self):
        for feature_name in (Labels.zankou_skill_gold, Labels.zankou_skill_purple):
            if self.task.find_one(feature_name):
                return feature_name
        return None

    def click_zankou_skill(self):
        clicked = False
        feature_name = self.find_zankou_skill()
        if feature_name:
            clicked = bool(self.click_skill())
        return clicked, feature_name == Labels.zankou_skill_purple

    def find_ult_purple(self):
        return self.task.find_one(Labels.zankou_ult_purple)

    def _find_lacrimosa(self):
        for char in getattr(self.task, "chars", ()) or ():
            if char is self or getattr(char, "is_dead", False):
                continue
            values = {
                str(getattr(char, key, "")).casefold()
                for key in ("name", "char_name", "cn_name", "ufn_name", "impl_id")
            }
            if (
                "dualcorelacrimosa" in "".join(values)
                or "安魂曲（残虹双核）" in values
                or "安魂曲（安魂曲双核）" in values
                or "lacrimosa" in values
            ):
                return char
        return None

    def _request_lacrimosa_handoff(self):
        if self._dual_core_handoff_active:
            return False
        lacrimosa = self._find_lacrimosa()
        if lacrimosa is None:
            return False
        route = self.combat_context.request_route(
            [
                Planner.Route.reaction(self, lacrimosa, optional=True),
                Planner.Route.action(lacrimosa, slot=Planner.ActionSlot.CUSTOM),
            ],
            reason="双核交接：残虹爆发 → 安魂曲完整窗口",
            timeout=self.HANDOFF_TIMEOUT,
        )
        if route is None:
            return False
        self._dual_core_handoff_active = True
        route.on_finish(self._clear_handoff)
        return True

    def _clear_handoff(self):
        self._dual_core_handoff_active = False
