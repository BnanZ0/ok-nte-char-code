"""真红盈蓄社区方案的零环合轮转。"""

from src.char.Zero import Zero
from src.combat.planner import Planner


class CommunityZeroShinku(Zero):
    """优先释放环合技能，必要时补充大招。"""

    cn_name = "零（真红队）"
    en_name = "Zero (Shinku Team)"

    def combat_plan(self, context):
        skill = self.click_skill_action(add_tags=Planner.ActionTag.TEAM_BUFF)
        ultimate = self.click_ultimate_action()
        return self.plan(skill, ultimate)
