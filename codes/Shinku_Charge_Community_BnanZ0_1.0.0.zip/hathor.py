"""真红盈蓄社区方案的哈索尔入场轮转。"""

from src.char.BaseChar import BaseChar
from src.combat.planner import Planner, RoleProfile


class CommunityHathorShinku(BaseChar):
    """通过短暂切入触发延滞反应，然后把站场交还给真红。"""

    cn_name = "哈索尔（真红队）"
    en_name = "Hathor (Shinku Team)"
    element = BaseChar.ElementType.YELLOW

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self, context):
        return self.plan()
