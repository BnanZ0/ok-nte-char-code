"""真红盈蓄社区方案的主场轮转。"""

from src.char.Shinku import Shinku


class CommunityShinku(Shinku):
    """完成 E→Q 并在大招窗口持续执行强化技能与普攻。"""

    cn_name = "真红（盈蓄社区版）"
    en_name = "Shinku (Charge Community)"

    def combat_plan(self, context):
        skill = self.click_skill_action()
        ultimate = self.click_ultimate_action()

        def entry():
            yield skill
            ultimate_result = yield ultimate
            if ultimate_result:
                self.perform_in_ult(context)

        return self.plan(skill, ultimate, entry=entry)
