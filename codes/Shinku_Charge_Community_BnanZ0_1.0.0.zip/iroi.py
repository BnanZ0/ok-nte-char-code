"""真红盈蓄社区方案的伊洛伊辅助轮转。"""

from src.char.Iroi import Iroi
from src.combat.planner import Planner, RoleProfile


class CommunityIroiShinku(Iroi):
    """快速释放 E/Q，并为 E 留出短暂治疗结算时间。"""

    cn_name = "伊洛伊（真红队）"
    en_name = "Iroi (Shinku Team)"
    HEAL_SKILL_SETTLE_TIME = 0.8

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self, context):
        skill = self.click_skill_action(add_tags=Planner.ActionTag.TEAM_BUFF)
        ultimate = self.click_ultimate_action()
        return self.plan(skill, ultimate)

    def click_skill(self, *args, **kwargs):
        kwargs.setdefault("post_sleep", self.HEAL_SKILL_SETTLE_TIME)
        return super().click_skill(*args, **kwargs)
