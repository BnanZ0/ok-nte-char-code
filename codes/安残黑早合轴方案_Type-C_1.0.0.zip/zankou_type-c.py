import time
from src.char.BaseChar import BaseChar
from src.combat.planner import ActionTag, CombatContext, FieldClaim, FollowupStep, Planner, RoleProfile
STATE_ATTR = '_an_can_hei_zao_axis'
PHASE_OPENER = 'opener'
PHASE_LOOP = 'loop'
PHASE_BURST = 'burst'
NA_INTERVAL = 0.35
PREINPUT_DELAY = 0.15
SAKIRI_Q_COOLDOWN = 20.0

def _install_axis_click_filter(task):
    import types
    if getattr(task, '_axis_click_filter_installed', False):
        return
    original_click = task.click

    def filtered_click(_self, *args, **kwargs):
        if kwargs.get('action_name') == 'switch_char_click':
            return None
        session = getattr(task, '_combat_session', None)
        if session is not None and session.start_char is None:
            return None
        return original_click(*args, **kwargs)
    task.click = types.MethodType(filtered_click, task)
    task._axis_click_filter_installed = True

class Zankou(BaseChar):
    cn_name = '残虹'
    element = BaseChar.ElementType.RED

    def describe_role(self):
        return RoleProfile(role=Planner.Role.SUB_DPS, field_preference=Planner.FieldPreference.SUB_DPS, max_field_time=0)

    def wait_intro(self, time_out=-1, click=True):
        if self.has_intro:
            self.sleep(0.2, checks=self.SleepChecks.NONE)

    def _state(self):
        session = self.task.combat_session
        if not hasattr(self.task, STATE_ATTR) or getattr(self.task, STATE_ATTR).get('session') is not session:
            setattr(self.task, STATE_ATTR, {'phase': PHASE_OPENER, 'opener_step': 0, 'loop_step': 0, 'loop_cycles': 0, 'burst_step': 0, 'session': session})
        return getattr(self.task, STATE_ATTR)

    def _find_char(self, cls_name):
        for char in self.task.chars:
            if char is not None and (type(char).__name__ == cls_name or getattr(char, 'cn_name', '') == cls_name):
                return char
        return None

    def _switch_to(self, context, cls_name, reason):
        target = self._find_char(cls_name)
        if target is not None:
            context.request_route([FollowupStep.for_switch(target, reason=reason)], reason=reason)

    def combat_plan(self, context: CombatContext):
        axis_action = self.planner_action(name='zankou_axis', tags={ActionTag.DAMAGE, ActionTag.HIGH_PRIORITY}, execute=self._run_axis, reason='残虹固定轴动作', can_execute=lambda ctx: self._is_my_turn(), priority_ready=lambda ctx: self._is_my_turn())
        claims = []
        if self._is_my_turn():
            claims.append(FieldClaim.strict(reason='残虹回合'))
        return self.plan(axis_action, claims=claims)

    def on_combat_end(self, chars):
        super().on_combat_end(chars)
        if hasattr(self.task, STATE_ATTR):
            delattr(self.task, STATE_ATTR)

    def reset_state(self):
        super().reset_state()
        if hasattr(self.task, STATE_ATTR):
            delattr(self.task, STATE_ATTR)

    def _q_e_a(self):
        self.logger.info('[残虹] q接e接a')
        self.send_ultimate_key(down_time=0.05)
        self.sleep(4.5, checks=self.SleepChecks.NONE)
        self.send_skill_key(down_time=0.05)
        self.sleep(0.5)
        self.continues_normal_attack(duration=0.73)

    def _is_my_turn(self):
        s = self._state()
        phase = s['phase']
        if phase == PHASE_OPENER:
            return s['opener_step'] in (2, 7)
        if phase == PHASE_BURST:
            return s['burst_step'] == 0
        return False

    def _z_a(self):
        self.logger.info('[残虹] z接a (a预输入)')
        self.heavy_attack(duration=0.6)
        self.sleep(0.15, checks=self.SleepChecks.NONE)
        self.click()

    def _ultimate_ready(self):
        return self.ultimate_available()

    def _run_axis(self, context: CombatContext):
        s = self._state()
        phase = s['phase']
        if phase == PHASE_OPENER:
            step = s['opener_step']
            if step == 2:
                self._q_e_a()
                s['opener_step'] = 3
                self._switch_to(context, 'Sakiri', '残虹qea->早雾qe')
                self.send_ultimate_key(down_time=0.05)
            elif step == 7:
                self._z_a()
                s['opener_step'] = 8
                self._switch_to(context, 'Lacrimosa', '残虹za->安魂曲a')
            return True
        if phase == PHASE_BURST:
            if s['burst_step'] == 0:
                if s.get('loop_exit_mode') == 'sakiri_first':
                    self._e_a1()
                else:
                    self._q_e_a_check_sakiri(s)
                s['burst_step'] = 1
                self._switch_to(context, 'Sakiri', '残虹->早雾')
            return True
        return False

    def _e_a1(self):
        self.logger.info('[残虹] e接a1 (a预输入)')
        self.send_skill_key(down_time=0.05)
        self.sleep(0.5)
        self.continues_normal_attack(duration=0.73)
    def _q_e_a_check_sakiri(self, s):
        self.logger.info('[残虹] q后e，检测早雾大招，再a')
        self.send_ultimate_key(down_time=0.05)
        self.sleep(4.5, checks=self.SleepChecks.NONE)
        self.send_skill_key(down_time=0.05)
        self.sleep(1.25, checks=self.SleepChecks.NONE)
        sakiri = self._find_char('Sakiri')
        ready = sakiri is not None and sakiri.ultimate_available()
        s['sakiri_ready_after_zankou'] = ready
        self.logger.info(f'[残虹] 早雾大招后台检测: {ready}')
        self.click()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.planner_handles_arc = True
        _install_axis_click_filter(self.task)

    def perform(self):
        self.last_perform = time.time()
        self.task.record_first_engage(self)
        if self.has_intro:
            self.add_intro_motion_freeze(self.last_perform)
            self.wait_intro()
        self.task.combat_planner.perform_current_char(self)
        self.switch_next_char()
