import time
from src.char.BaseChar import BaseChar
from src.combat.planner import ActionTag, CombatContext, FieldClaim, FollowupStep, Planner, RoleProfile
STATE_ATTR = '_an_can_hei_zao_axis'
PHASE_OPENER = 'opener'
PHASE_LOOP = 'loop'
PHASE_BURST = 'burst'
NA_INTERVAL = 0.25
PREINPUT_DELAY = 0.15
SAKIRI_Q_COOLDOWN = 20.0

def _install_axis_click_filter(task):
    import types
    if getattr(task, '_axis_click_filter_installed', False):
        return
    original_click = task.click

    def filtered_click(_self, *args, **kwargs):
        if kwargs.get('action_name') == 'switch_char_click':
            return None
        session = getattr(task, '_combat_session', None)
        if session is not None and session.start_char is None:
            return None
        return original_click(*args, **kwargs)
    task.click = types.MethodType(filtered_click, task)
    task._axis_click_filter_installed = True

class Lacrimosa(BaseChar):
    cn_name = '安魂曲'
    element = BaseChar.ElementType.PURPLE

    def describe_role(self):
        return RoleProfile(role=Planner.Role.MAIN_DPS, field_preference=Planner.FieldPreference.MAIN_DPS, max_field_time=0, combat_start_priority=100)

    def _state(self):
        session = self.task.combat_session
        if not hasattr(self.task, STATE_ATTR) or getattr(self.task, STATE_ATTR).get('session') is not session:
            setattr(self.task, STATE_ATTR, {'phase': PHASE_OPENER, 'opener_step': 0, 'loop_step': 0, 'loop_cycles': 0, 'burst_step': 0, 'session': session})
        return getattr(self.task, STATE_ATTR)

    def _find_char(self, cls_name):
        for char in self.task.chars:
            if char is not None and (type(char).__name__ == cls_name or getattr(char, 'cn_name', '') == cls_name):
                return char
        return None

    def _switch_to(self, context, cls_name, reason):
        target = self._find_char(cls_name)
        if target is not None:
            context.request_route([FollowupStep.for_switch(target, reason=reason)], reason=reason)

    def combat_plan(self, context: CombatContext):
        axis_action = self.planner_action(name='lacrimosa_axis', tags={ActionTag.DAMAGE, ActionTag.HIGH_PRIORITY}, execute=self._run_axis, reason='安魂曲固定轴动作', can_execute=lambda ctx: self._is_my_turn(), priority_ready=lambda ctx: self._is_my_turn())
        claims = []
        if self._is_my_turn():
            claims.append(FieldClaim.strict(reason='安魂曲回合'))
        return self.plan(axis_action, claims=claims)

    def _opener_a(self):
        self.logger.info('[安魂曲] a')
        self.normal_attack()
        self.sleep(0.3)

    def _loop_ea(self):
        self.logger.info('[安魂曲] ea (a预输入)')
        self.send_skill_key(down_time=0.05)
        self.sleep(0.05, sleep_check=False)
        self.click()

    def _burst_a(self):
        self.logger.info('[安魂曲] a')
        self.normal_attack()
        self.sleep(0.3)

    def _opener_g(self):
        if not self.task.is_in_team():
            self.task.wait_until(self.task.is_in_team, time_out=1.0, post_action=None)
        self.logger.info('[安魂曲] 入场g')
        self.send_key('g')

    def on_combat_end(self, chars):
        super().on_combat_end(chars)
        if hasattr(self.task, '_an_can_hei_zao_remote'):
            delattr(self.task, '_an_can_hei_zao_remote')
        if hasattr(self.task, STATE_ATTR):
            delattr(self.task, STATE_ATTR)

    def reset_state(self):
        super().reset_state()
        if hasattr(self.task, '_an_can_hei_zao_remote'):
            delattr(self.task, '_an_can_hei_zao_remote')
        if hasattr(self.task, STATE_ATTR):
            delattr(self.task, STATE_ATTR)

    def _loop_a1234(self):
        self.logger.info('[安魂曲] a1234 (a3后预输入a4切)')
        self.continues_normal_attack(duration=1.1)

    def wait_intro(self, time_out=-1, click=True):
        if self.has_intro:
            self.sleep(0.6, sleep_check=False)

    def click_ultimate(self, send_click=True, wait_if_no_cd=0):
        return super().click_ultimate(send_click=False, wait_if_no_cd=wait_if_no_cd)

    def _wait_ultimate_unfreeze(self, start, click=True):
        self.task.wait_until(lambda: self.has_cd('ultimate'), time_out=4.0, post_action=None)
        duration = self.now() - start
        self.add_freeze_duration(start, duration, freeze_time=-100)
        return duration

    def _opener_e_q(self):
        self.logger.info('[安魂曲] e接q')
        self.click_skill(send_click=False)
        self.sleep(0.1, sleep_check=False)
        self.click_ultimate(send_click=False)

    def _burst_e_q(self):
        self.logger.info('[安魂曲] eq')
        self.click_skill(send_click=False)
        self.sleep(0.1, sleep_check=False)
        self.click_ultimate(send_click=False)

    def _is_my_turn(self):
        s = self._state()
        phase = s['phase']
        if phase == PHASE_OPENER:
            return s['opener_step'] in (0, 5, 8)
        if phase == PHASE_LOOP:
            return s['loop_step'] in (0, 2)
        if phase == PHASE_BURST:
            return s['burst_step'] == 3
        return False

    def _run_axis(self, context: CombatContext):
        s = self._state()
        phase = s['phase']
        if phase == PHASE_OPENER:
            step = s['opener_step']
            if step == 0:
                self._opener_g()
                s['opener_step'] = 1
                self._switch_to(context, 'Blackbird', '安魂曲g->黑羽e')
            elif step == 5:
                self._opener_e_q_a()
                s['opener_step'] = 6
                self._switch_to(context, 'Blackbird', '安魂曲eqa->黑羽')
            elif step == 8:
                self._opener_a_preinput()
                s['opener_step'] = 9
                self._switch_to(context, 'Blackbird', '安魂曲a->黑羽a123')
            return True
        if phase == PHASE_LOOP:
            step = s['loop_step']
            if step == 0:
                self._loop_a1234()
                s['loop_step'] = 1
                self._switch_to(context, 'Blackbird', '安魂曲a1234->黑羽a45eza')
            elif step == 2:
                self._loop_ea()
                s['phase'] = PHASE_BURST
                s['burst_step'] = 0
                self._switch_to(context, 'Zankou', '安魂曲ea->残虹qea')
            return True
        if phase == PHASE_BURST:
            step = s['burst_step']
            if step == 3:
                self._burst_e_q()
                s['burst_step'] = 4
                self._switch_to(context, 'Blackbird', '安魂曲eq->黑羽a123')
            return True
        return False

    def _opener_e_q_a(self):
        self.logger.info('[安魂曲] e接q接a (a预输入)')
        self._opener_e_q()
        self.click()

    def _opener_a_preinput(self):
        self.logger.info('[安魂曲] a (a预输入)')
        self.click()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.planner_handles_arc = True
        _install_axis_click_filter(self.task)

    def perform(self):
        self.last_perform = time.time()
        self.task.record_first_engage(self)
        if self.has_intro:
            self.add_intro_motion_freeze(self.last_perform)
            self.wait_intro()
        self.task.combat_planner.perform_current_char(self)
        self.switch_next_char()

    def _sound_action_stamp(self):
        from src.sound_trigger.SoundCombatContext import SoundCombatContext
        trigger = SoundCombatContext().trigger
        if trigger is None:
            return (0.0, 0.0)
        return (
            getattr(trigger, '_last_dodge_time', 0.0),
            getattr(trigger, '_last_counter_time', 0.0),
        )

    def _sound_action_changed(self, stamp):
        return self._sound_action_stamp() != stamp

    def _loop_a1234(self):
        self.logger.info('[安魂曲] a1234 (被打断则补a后切人)')
        stamp = self._sound_action_stamp()
        deadline = time.time() + 1.1
        while time.time() < deadline:
            self.click()
            if self._sound_action_changed(stamp):
                self.logger.info('[安魂曲] a1234 被闪避/弹刀打断，补一次普通攻击后切人')
                self.click()
                return
            self.sleep(0.1)
            if self._sound_action_changed(stamp):
                self.logger.info('[安魂曲] a1234 被闪避/弹刀打断，补一次普通攻击后切人')
                self.click()
                return