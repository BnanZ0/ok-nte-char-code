import time
from src.char.BaseChar import BaseChar
from src.combat.planner import ActionTag, CombatContext, FieldClaim, FollowupStep, Planner, RoleProfile
STATE_ATTR = '_an_can_hei_zao_axis'
PHASE_OPENER = 'opener'
PHASE_LOOP = 'loop'
PHASE_BURST = 'burst'
NA_INTERVAL = 0.35
PREINPUT_DELAY = 0.15
SAKIRI_Q_COOLDOWN = 35.0

def _install_axis_click_filter(task):
    import types
    if getattr(task, '_axis_click_filter_installed', False):
        return
    original_click = task.click

    def filtered_click(_self, *args, **kwargs):
        if kwargs.get('action_name') == 'switch_char_click':
            return None
        session = getattr(task, '_combat_session', None)
        if session is not None and session.start_char is None:
            return None
        return original_click(*args, **kwargs)
    task.click = types.MethodType(filtered_click, task)
    task._axis_click_filter_installed = True

class Sakiri(BaseChar):
    cn_name = '早雾'
    element = BaseChar.ElementType.RED

    def describe_role(self):
        return RoleProfile(role=Planner.Role.SUPPORT, field_preference=Planner.FieldPreference.SUPPORT, max_field_time=0)

    def wait_intro(self, time_out=-1, click=True):
        if self.has_intro:
            self.sleep(0.2, sleep_check=False)

    def _state(self):
        session = self.task.combat_session
        if not hasattr(self.task, STATE_ATTR) or getattr(self.task, STATE_ATTR).get('session') is not session:
            setattr(self.task, STATE_ATTR, {'phase': PHASE_OPENER, 'opener_step': 0, 'loop_step': 0, 'loop_cycles': 0, 'burst_step': 0, 'session': session})
        return getattr(self.task, STATE_ATTR)

    def _find_char(self, cls_name):
        for char in self.task.chars:
            if char is not None and (type(char).__name__ == cls_name or getattr(char, 'cn_name', '') == cls_name):
                return char
        return None

    def _switch_to(self, context, cls_name, reason):
        target = self._find_char(cls_name)
        if target is not None:
            context.request_route([FollowupStep.for_switch(target, reason=reason)], reason=reason)

    def combat_plan(self, context: CombatContext):
        axis_action = self.planner_action(name='sakiri_axis', tags={ActionTag.SUPPORT, ActionTag.TEAM_BUFF, ActionTag.HIGH_PRIORITY}, execute=self._run_axis, reason='早雾固定轴动作', can_execute=lambda ctx: self._is_my_turn(), priority_ready=lambda ctx: self._is_my_turn())
        claims = []
        if self._is_my_turn():
            claims.append(FieldClaim.strict(reason='早雾回合'))
        return self.plan(axis_action, claims=claims)

    def on_combat_end(self, chars):
        super().on_combat_end(chars)
        if hasattr(self.task, STATE_ATTR):
            delattr(self.task, STATE_ATTR)

    def reset_state(self):
        super().reset_state()
        if hasattr(self.task, STATE_ATTR):
            delattr(self.task, STATE_ATTR)

    def _q_e(self):
        self.logger.info('[早雾] q完接e (e预输入)')
        self.send_ultimate_key(down_time=0.05)
        self.sleep(3.5, sleep_check=False)
        self.send_skill_key(down_time=0.05)
        self.sleep(0.2, sleep_check=False)

    def _is_my_turn(self):
        s = self._state()
        phase = s['phase']
        if phase == PHASE_OPENER:
            return s['opener_step'] == 3
        if phase == PHASE_BURST:
            return s['burst_step'] == 1
        return False

    def _run_axis(self, context: CombatContext):
        s = self._state()
        phase = s['phase']
        if phase == PHASE_OPENER:
            if s['opener_step'] == 3:
                self._q_e()
                s['opener_step'] = 4
                self._switch_to(context, 'Blackbird', '早雾qe->黑羽qa')
            return True
        if phase == PHASE_BURST:
            if s['burst_step'] == 1:
                if s.get('loop_exit_mode') == 'zankou_first' and (not s.get('sakiri_ready_after_zankou', True)):
                    self._e_only()
                else:
                    self._q_e()
                s['burst_step'] = 2
                self._switch_to(context, 'Blackbird', '早雾->黑羽qeqa')
            return True
        return False

    def _e_only(self):
        self.logger.info('[早雾] 大招未好，仅e后切人')
        self.send_skill_key(down_time=0.05)
        self.sleep(0.1, sleep_check=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.planner_handles_arc = True
        _install_axis_click_filter(self.task)

    def perform(self):
        self.last_perform = time.time()
        self.task.record_first_engage(self)
        if self.has_intro:
            self.add_intro_motion_freeze(self.last_perform)
            self.wait_intro()
        self.task.combat_planner.perform_current_char(self)
        self.switch_next_char()
