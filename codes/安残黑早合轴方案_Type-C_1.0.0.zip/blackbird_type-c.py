import time
from src.Labels import Labels
from src.char.BaseChar import BaseChar
from src.combat.planner import ActionTag, CombatContext, FieldClaim, FollowupStep, Planner, RoleProfile
STATE_ATTR = '_an_can_hei_zao_axis'
PHASE_OPENER = 'opener'
PHASE_LOOP = 'loop'
PHASE_BURST = 'burst'
NA_INTERVAL = 0.25
PREINPUT_DELAY = 0.15
SAKIRI_Q_COOLDOWN = 20.0
HEAVY_ATTACK_DURATION = 0.8

def _install_axis_click_filter(task):
    import types
    if getattr(task, '_axis_click_filter_installed', False):
        return
    original_click = task.click

    def filtered_click(_self, *args, **kwargs):
        if kwargs.get('action_name') == 'switch_char_click':
            return None
        session = getattr(task, '_combat_session', None)
        if session is not None and session.start_char is None:
            return None
        return original_click(*args, **kwargs)
    task.click = types.MethodType(filtered_click, task)
    task._axis_click_filter_installed = True

class Blackbird(BaseChar):
    cn_name = '黑羽'
    element = BaseChar.ElementType.BLUE

    def describe_role(self):
        return RoleProfile(role=Planner.Role.SUB_DPS, field_preference=Planner.FieldPreference.SUB_DPS, max_field_time=0)

    def wait_intro(self, time_out=-1, click=True):
        if self.has_intro:
            self.sleep(0.2, checks=self.SleepChecks.NONE)

    def _state(self):
        session = self.task.combat_session
        if not hasattr(self.task, STATE_ATTR) or getattr(self.task, STATE_ATTR).get('session') is not session:
            setattr(self.task, STATE_ATTR, {'phase': PHASE_OPENER, 'opener_step': 0, 'loop_step': 0, 'loop_cycles': 0, 'burst_step': 0, 'session': session})
        return getattr(self.task, STATE_ATTR)

    def _find_char(self, cls_name):
        for char in self.task.chars:
            if char is not None and (type(char).__name__ == cls_name or getattr(char, 'cn_name', '') == cls_name):
                return char
        return None

    def _switch_to(self, context, cls_name, reason):
        target = self._find_char(cls_name)
        if target is not None:
            context.request_route([FollowupStep.for_switch(target, reason=reason)], reason=reason)

    def combat_plan(self, context: CombatContext):
        axis_action = self.planner_action(name='blackbird_axis', tags={ActionTag.DAMAGE, ActionTag.HIGH_PRIORITY}, execute=self._run_axis, reason='黑羽固定轴动作', can_execute=lambda ctx: self._is_my_turn(), priority_ready=lambda ctx: self._is_my_turn())
        claims = []
        if self._is_my_turn():
            claims.append(FieldClaim.strict(reason='黑羽回合'))
        return self.plan(axis_action, claims=claims)

    def _burst_a123(self):
        self.logger.info('[黑羽] a123 (a3预输入切)')
        self.continues_normal_attack(duration=0.93)

    def _cast_blackbird_q2(self):
        if not self.in_blackbird_ult:
            return False
        self.send_ultimate_key(down_time=0.05)
        self.in_blackbird_ult = False
        self.sleep(0.4, checks=self.SleepChecks.NONE)
        return True

    def on_combat_end(self, chars):
        super().on_combat_end(chars)
        if hasattr(self.task, STATE_ATTR):
            delattr(self.task, STATE_ATTR)

    def reset_state(self):
        super().reset_state()
        self.in_blackbird_ult = False
        if hasattr(self.task, STATE_ATTR):
            delattr(self.task, STATE_ATTR)

    def _opener_e(self):
        self.logger.info('[黑羽] e')
        self.send_skill_key(down_time=0.05)


    def _cast_blackbird_q1(self):
        self.send_ultimate_key(down_time=0.05)
        self._ultimate_available = False
        self.last_ultimate_time = self.now()
        self.in_blackbird_ult = True
        self.sleep(0.3, checks=self.SleepChecks.NONE)

    def _opener_q_a(self):
        self.logger.info('[黑羽] qa (a预输入)')
        self._cast_blackbird_q1()
        self.sleep(4.19, checks=self.SleepChecks.NONE)
        self.click()

    def _burst_qeqa(self):
        self.logger.info('[黑羽] qeqa (q2 -> e -> q1 -> a)')
        self._cast_blackbird_q2()
        self.sleep(4.0, checks=self.SleepChecks.NONE)
        self.send_skill_key(down_time=0.05)
        self.sleep(0.1, checks=self.SleepChecks.NONE)
        self._cast_blackbird_q1()
        self.sleep(4.1, checks=self.SleepChecks.NONE)
        self.click()

    def _is_my_turn(self):
        s = self._state()
        phase = s['phase']
        if phase == PHASE_OPENER:
            return s['opener_step'] in (1, 4, 6, 9)
        if phase == PHASE_LOOP:
            return s['loop_step'] == 1
        if phase == PHASE_BURST:
            return s['burst_step'] in (2, 4)
        return False

    def _run_axis(self, context: CombatContext):
        s = self._state()
        phase = s['phase']
        if phase == PHASE_OPENER:
            step = s['opener_step']
            if step == 1:
                self._opener_e()
                s['opener_step'] = 2
                self.sleep(0.05)
                self._switch_to(context, 'Zankou', '黑羽e->残虹qea')
            elif step == 4:
                self._opener_q_a()
                s['opener_step'] = 5
                self._switch_to(context, 'Lacrimosa', '黑羽qa->安魂曲eqa')
            elif step == 6:
                self.sleep(0.15)
                self._click_()
                s['opener_step'] = 7
                self._switch_to(context, 'Zankou', '黑羽->残虹za')
            elif step == 9:
                self._opener_a123()
                s['phase'] = PHASE_LOOP
                s['loop_step'] = 0
                s['loop_cycles'] = 0
                self._switch_to(context, 'Lacrimosa', '黑羽a123->进入循环->安魂曲a1234')
            return True
        if phase == PHASE_LOOP:
            self._loop_a45_eza_three(context, s)
            return True
        if phase == PHASE_BURST:
            step = s['burst_step']
            if step == 2:
                self._burst_qeqa()
                s['burst_step'] = 3
                self._switch_to(context, 'Lacrimosa', '黑羽qeqa->安魂曲eq')
            elif step == 4:
                self._burst_a123()
                s['phase'] = PHASE_LOOP
                s['loop_step'] = 0
                s['loop_cycles'] = 0
                self._switch_to(context, 'Lacrimosa', '黑羽a123->回到循环->安魂曲a1234')
            return True
        return False

    def _click_(self):
        self.continues_normal_attack(duration=0.2)


    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.planner_handles_arc = True
        self.in_blackbird_ult = False
        _install_axis_click_filter(self.task)

    def perform(self):
        self.last_perform = time.time()
        self.task.record_first_engage(self)
        if self.has_intro:
            self.add_intro_motion_freeze(self.last_perform)
            self.wait_intro()
        self.task.combat_planner.perform_current_char(self)
        self.switch_next_char()

    def _opener_a123(self):
        self.logger.info('[黑羽] a123 (屏蔽声音打断)')
        with self.task.skip_sleep_checks() as skip:
            skip.sound_combat_context = True
            skip.check_combat = True
            self.continues_normal_attack(duration=0.93)

    def _loop_a45_eza_three(self, context, s):
        self.logger.info('[黑羽] a45后eza (屏蔽声音打断 + 后台检测大招)')
        with self.task.skip_sleep_checks() as skip:
            skip.sound_combat_context = True
            skip.check_combat = True
            self.click()
            self.sleep(0.25, checks=self.SleepChecks.NONE)
            self.click()
            self.sleep(0.78, checks=self.SleepChecks.NONE)
            self.send_skill_key(down_time=0.05)
            self.sleep(0.25, checks=self.SleepChecks.NONE)
            self.heavy_attack(duration=0.8)
            self.sleep(0.20, checks=self.SleepChecks.NONE)
            self.click()

        s['loop_cycles'] = s.get('loop_cycles', 0) + 1
        zankou = self._find_char('Zankou')
        sakiri = self._find_char('Sakiri')
        zankou_ready = zankou is not None and zankou.ultimate_available()
        sakiri_ready = sakiri is not None and sakiri.ultimate_available()
        self.logger.info(
            f"[黑羽] 后台检测 残虹:{zankou_ready} 早雾:{sakiri_ready} 已循环:{s['loop_cycles']}"
        )
        if s['loop_cycles'] < 3:
            s['loop_step'] = 0
            self._switch_to(context, 'Lacrimosa', '安黑循环不足三次->继续')
            return
        if zankou_ready:
            s['loop_exit_mode'] = 'zankou_first'
            s['sakiri_ready_after_zankou'] = sakiri_ready
            s['phase'] = PHASE_BURST
            s['burst_step'] = 0
            self._switch_to(context, 'Zankou', '残虹大招已好->切残虹')
        elif sakiri_ready:
            s['loop_exit_mode'] = 'sakiri_first'
            s['phase'] = PHASE_BURST
            s['burst_step'] = 0
            self._switch_to(context, 'Zankou', '早雾大招已好->残虹e接a1后切早雾')
        else:
            s['loop_step'] = 0
            self._switch_to(context, 'Lacrimosa', '双大招未好->继续安黑循环')