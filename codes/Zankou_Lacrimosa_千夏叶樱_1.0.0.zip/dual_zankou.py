"""Self-contained Zankou handoff for the Lacrimosa dual-core team."""

from src.Labels import Labels
from src.char.Zankou import Zankou
from src.combat.planner import CombatContext, FollowupStep, Planner, RoleProfile


class DualCoreZankou(Zankou):
    """先完成黄 E、紫 E 和双 Q，再把前台交给安魂曲。"""

    cn_name = "残虹（安魂曲双核）"
    en_name = "Zankou (Lacrimosa Dual Core)"
    COMBO_TIMEOUT = 10.0
    HEAVY_ATTACK_TIME = 0.45
    PURPLE_ULTIMATE_WAIT = 3.0
    HANDOFF_TIMEOUT = 12.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._dual_core_handoff_active = False

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
            combat_start_priority=1000,
        )

    def combat_plan(self, context: CombatContext):
        ultimate = self.click_ultimate_action()
        skill_combo = self.planner_action(
            tags={
                Planner.ActionTag.DEFAULT_ACTION,
                Planner.ActionTag.DAMAGE,
                Planner.ActionTag.SKILL_ACTION,
                Planner.ActionTag.COORDINATION_FINISHER,
            },
            slot=Planner.ActionSlot.SKILL,
            execute=lambda action_context: self.perform_skill_combo(),
            name="dual_core_zankou_skill_combo",
            reason="残虹重击点亮黄 E，并在紫 E 窗口完成双 Q",
            can_execute=lambda _: True,
            priority_ready=lambda _: True,
        )

        def entry():
            if not self.find_ult_purple():
                combo_result = yield skill_combo
                if combo_result:
                    self.task.wait_until(
                        self.find_ult_purple,
                        post_action=self.click_with_interval,
                        time_out=self.PURPLE_ULTIMATE_WAIT,
                    )

            if self.find_ult_purple():
                first_q = yield ultimate
                if first_q:
                    self.task.wait_until(
                        self.ultimate_available,
                        post_action=self.click_with_interval,
                        time_out=3.0,
                    )
                    second_q = yield ultimate.repeat_for_entry()
                    if second_q:
                        self._request_lacrimosa_handoff(context)

        return self.plan(skill_combo, ultimate, entry=entry)

    def perform_skill_combo(self):
        deadline = self.now() + self.COMBO_TIMEOUT
        clicked_skill = False
        while self.now() < deadline:
            feature = self.find_zankou_skill()
            if feature:
                skill_clicked, _ = self.click_zankou_skill()
                clicked_skill = clicked_skill or bool(skill_clicked)
                if self.find_ult_purple():
                    break
            else:
                self.heavy_attack(duration=self.HEAVY_ATTACK_TIME)

            self.sleep(0.1)
            if self.find_ult_purple():
                break

            try:
                self.task.mouse_down()
                for _ in range(5):
                    if self.find_zankou_skill() or self.find_ult_purple():
                        break
                    self.sleep(0.1)
            finally:
                self.task.mouse_up()
        return clicked_skill

    def find_zankou_skill(self):
        for feature_name in (Labels.zankou_skill_gold, Labels.zankou_skill_purple):
            if self.task.find_one(feature_name):
                return feature_name
        return None

    def click_zankou_skill(self):
        clicked = False
        feature_name = self.find_zankou_skill()
        if feature_name:
            clicked = bool(self.click_skill())
        return clicked, feature_name == Labels.zankou_skill_purple

    def find_ult_purple(self):
        return self.task.find_one(Labels.zankou_ult_purple)

    def _find_lacrimosa(self):
        for char in getattr(self.task, "chars", ()) or ():
            if char is self or getattr(char, "is_dead", False):
                continue
            values = {
                str(getattr(char, key, "")).casefold()
                for key in ("name", "char_name", "cn_name", "ufn_name", "impl_id")
            }
            if (
                "dualcorelacrimosa" in "".join(values)
                or "安魂曲（残虹双核）" in values
                or "安魂曲（安魂曲双核）" in values
                or "lacrimosa" in values
            ):
                return char
        return None

    def _request_lacrimosa_handoff(self, context):
        if self._dual_core_handoff_active or context is None:
            return False
        lacrimosa = self._find_lacrimosa()
        if lacrimosa is None or not callable(getattr(context, "request_route", None)):
            return False
        steps = [
            FollowupStep.for_entry_reaction(
                lacrimosa,
                reason="残虹双 Q 后触发安魂曲入场反应",
                optional=True,
                wait_timeout=1.5,
            ),
            FollowupStep.for_action(
                lacrimosa,
                Planner.ActionSlot.CUSTOM,
                action_names={"dual_core_lacrimosa_window"},
                reason="安魂曲完整 Q/E/普攻窗口",
            ),
        ]
        deadline = self.now() + self.HANDOFF_TIMEOUT
        route = context.request_route(
            steps,
            reason="双核交接：残虹爆发 → 安魂曲完整窗口",
            until=lambda: self.now() >= deadline,
            return_to_source=False,
        )
        if route is None:
            return False
        self._dual_core_handoff_active = True
        route.on_fulfilled(self._clear_handoff)
        route.on_expired(self._clear_handoff)
        return True

    def _clear_handoff(self):
        self._dual_core_handoff_active = False
