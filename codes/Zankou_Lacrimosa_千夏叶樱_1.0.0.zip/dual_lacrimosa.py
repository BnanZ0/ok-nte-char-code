"""Self-contained Lacrimosa window for the Zankou dual-core team."""

from src.char.Lacrimosa import Lacrimosa
from src.combat.planner import CombatContext, FollowupStep, Planner, RoleProfile, SwitchInGuard


class DualCoreLacrimosa(Lacrimosa):
    """接过残虹爆发，完成 Q/E 和短普攻窗口后交回辅助与残虹。"""

    cn_name = "安魂曲（残虹双核）"
    en_name = "Lacrimosa (Zankou Dual Core)"
    WINDOW_SECONDS = 6.5
    SUPPORT_ROUTE_TIMEOUT = 12.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._dual_core_support_route_active = False

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def switch_in_guard(self, context, from_char, has_intro):
        if context is None or not context.has_strict_route():
            return SwitchInGuard.deny("安魂曲只在残虹双核交接窗口入场")
        if context.strict_route_wants_entry_reaction(self):
            return SwitchInGuard.allow()
        if context.strict_route_wants_action(
            self,
            slot=Planner.ActionSlot.CUSTOM,
            action_name="dual_core_lacrimosa_window",
        ):
            return SwitchInGuard.allow()
        return SwitchInGuard.deny("安魂曲等待残虹双核交接步骤")

    def combat_plan(self, context: CombatContext):
        window = self.planner_action(
            tags={
                Planner.ActionTag.DEFAULT_ACTION,
                Planner.ActionTag.DAMAGE,
                Planner.ActionTag.COORDINATION,
            },
            slot=Planner.ActionSlot.CUSTOM,
            execute=lambda action_context: self._run_window(action_context),
            name="dual_core_lacrimosa_window",
            reason="安魂曲完整 Q/E/普攻窗口",
            can_execute=lambda action_context: bool(
                action_context
                and action_context.strict_route_wants_action(
                    self,
                    slot=Planner.ActionSlot.CUSTOM,
                    action_name="dual_core_lacrimosa_window",
                )
            ),
            priority_ready=lambda _: False,
        )
        return self.plan(window)

    def _run_window(self, context):
        executed = False
        try:
            if self.ultimate_available():
                executed = bool(self.click_ultimate()) or executed
            if self.skill_available():
                executed = bool(self.click_skill()) or executed
            for _ in range(5):
                if getattr(self, "is_dead", False) or not getattr(self, "is_current_char", True):
                    break
                self.normal_attack()
                executed = True
                self.sleep(0.16)
        finally:
            self._request_support_handoff(context)
        return executed

    @staticmethod
    def _find_character(chars, aliases):
        aliases = {str(value).casefold() for value in aliases}
        for char in chars or ():
            if char is None or getattr(char, "is_dead", False):
                continue
            values = {
                str(getattr(char, key, "")).casefold()
                for key in ("name", "char_name", "cn_name", "ufn_name", "impl_id")
            }
            if values & aliases:
                return char
        return None

    def _request_support_handoff(self, context):
        if self._dual_core_support_route_active or context is None:
            return False
        chars = getattr(self.task, "chars", ()) or ()
        adler = self._find_character(chars, {"阿德勒", "adler", "builtin:adler"})
        sakiri = self._find_character(chars, {"早雾", "sakiri", "builtin:sakiri"})
        zankou = self._find_character(
            chars,
            {"dualcorezankou", "残虹（安魂曲双核）", "残虹", "zankou"},
        )
        if zankou is None or not callable(getattr(context, "request_route", None)):
            return False

        steps = []
        if adler is not None:
            steps.append(
                FollowupStep.for_action(
                    adler,
                    Planner.ActionSlot.SKILL,
                    reason="阿德勒优先开盾",
                    optional=True,
                )
            )
        if sakiri is not None:
            steps.extend(
                [
                    FollowupStep.for_action(
                        sakiri,
                        Planner.ActionSlot.ULTIMATE,
                        reason="早雾 Q 提供队伍增益",
                        optional=True,
                    ),
                    FollowupStep.for_action(
                        sakiri,
                        Planner.ActionSlot.SKILL,
                        reason="早雾 E 完成短切",
                        optional=True,
                    ),
                ]
            )
        steps.append(
            FollowupStep.for_action(
                zankou,
                Planner.ActionSlot.SKILL,
                action_names={"dual_core_zankou_skill_combo"},
                reason="辅助完成后回残虹",
            )
        )
        deadline = self.now() + self.SUPPORT_ROUTE_TIMEOUT
        route = context.request_route(
            steps,
            reason="双核循环：安魂曲 → 阿德勒/早雾 → 残虹",
            until=lambda: self.now() >= deadline,
            return_to_source=False,
        )
        if route is None:
            return False
        self._dual_core_support_route_active = True
        route.on_fulfilled(self._clear_support_route)
        route.on_expired(self._clear_support_route)
        return True

    def _clear_support_route(self):
        self._dual_core_support_route_active = False
