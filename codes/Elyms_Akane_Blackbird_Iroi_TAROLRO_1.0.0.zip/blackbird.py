"""四环队输出轴 - 黑羽.

排轴定位: 首段 E -> Q1 -> A 到星盘(缩轴切明音凛); 收尾 E -> 5A -> E -> Q2.
手法原文: 黑羽 E-Q1-AAAAA-E-AAAAA-E-Q2, 与明音凛分开穿插成双 C 循环;
"一段大招动画结束后, 不断普攻到看到星盘, 看到星盘后立即切明音凛".

星盘用 Labels.blackbird_ult_2 近似检测(与内置黑羽同一模板), 检测不到时
按 STAR_DIAL_TIMEOUT 超时兜底, 不会卡死; 实测若星盘另有模板可替换.
通过共享模块(elyms.py)获取全队排轴状态机, 本文件不持有状态机定义.
"""

import sys


def _load_team_module():
    """加载同目录 elyms.py 内的全队共享排轴核心(按 mtime 失效缓存)."""
    import importlib.util
    from pathlib import Path

    key = "_four_ring_team_rotation_module"
    team_path = Path(__file__).resolve().with_name("elyms.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_BLACKBIRD_EQA = _team.STAGE_BLACKBIRD_EQA
STAGE_BLACKBIRD_FINISH = _team.STAGE_BLACKBIRD_FINISH
get_rotation = _team.get_rotation
register_rotation_actions = _team.register_rotation_actions
log_stage = _team.log_stage

from src.Labels import Labels
from src.char.BaseChar import BaseChar
from src.char.Blackbird import Blackbird as StockBlackbird
from src.combat.planner import Planner, RoleProfile


class Blackbird(_team.RotationMixin, StockBlackbird):
    cn_name = "四环队·黑羽"
    en_name = "Four Ring · Blackbird"
    element = BaseChar.ElementType.BLUE

    # 排轴时值(按实测微调)
    STAR_DIAL_TIMEOUT = 3.0
    FINISH_ATTACK_COUNT = 5
    ATTACK_INTERVAL = 0.2

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUB_DPS,
            max_field_time=0.5,
            combat_start_priority=0,
        )

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan)
        self.register_ultimate(plan)
        register_rotation_actions(plan, self)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        log_stage(self, rotation, stage)
        if stage == STAGE_BLACKBIRD_EQA:
            self.perform_eqa()
            self.rotation_next()
        elif stage == STAGE_BLACKBIRD_FINISH:
            self.perform_finish()
            self.rotation_next()
        else:
            self.logger.warning("[four-ring] Blackbird unexpected entry, fallback")
            if self.skill_available():
                self.click_skill()
            if self.ultimate_available():
                self.click_ultimate()
            self.rotation_retry()

    def perform_eqa(self):
        """E -> Q1 -> 持续普攻到星盘/超时, 然后切明音凛."""
        self.click_skill()
        if self.click_ultimate():
            self.in_ult = True
        timer = self.clock.timer(timeout=self.STAR_DIAL_TIMEOUT)
        while not timer.expired():
            if self.task.find_one(Labels.blackbird_ult_2):
                break
            self.click()
            self.sleep(self.ATTACK_INTERVAL)
        return True

    def perform_finish(self):
        """E -> 5A -> E -> Q2, 一轮循环的收尾."""
        self.click_skill()
        for _ in range(self.FINISH_ATTACK_COUNT):
            self.click()
            self.sleep(self.ATTACK_INTERVAL)
        self.click_skill()
        self.click_ultimate()
        self.in_ult = False
        self.claim_after_skill = False
        return True
