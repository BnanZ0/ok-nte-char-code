"""四环队(曳尔沐+明音凛+黑羽+伊洛伊)输出轴 - 共享排轴核心 + 曳尔沐.

队伍: 曳尔沐(光 WHITE) / 明音凛(相 YELLOW) / 黑羽(魂 BLUE) / 伊洛伊(灵 GREEN).
四环: 魂+相=浸染, 相+光=延滞, 光+灵=创生, 相+光+灵=盈蓄.

轴依据: 尤雪落儿 2026-11-11「曳尔沐+明音凛+黑羽+伊洛伊浸染延滞创生
盈蓄队伍输出手法」(0觉轮椅手法, 一轮轴长约 23 秒). 用户给的 11-01
「四环队伍分析」是强度分析文, 本身只附了「明黑伊早」参考轴, 未给出
本队手法, 故以配套手法文为准.

首轮(7 段):
    曳尔沐 E -> 明音凛 E -> 伊洛伊 EQZ -> 曳尔沐 EQ -> 黑羽 EQA~
    -> 明音凛 Q1-8A-E-Q2 -> 黑羽 E-5A-E-Q2
次轮起(6 段, 省掉明音凛开场 E):
    曳尔沐 E -> 伊洛伊 EQZ -> 曳尔沐 EQ -> 黑羽 EQA~
    -> 明音凛 Q1-8A-E-Q2 -> 黑羽 E-5A-E-Q2 -> 重复

手法备注:
    - 明音凛与黑羽是双 C, 各打一套但分开穿插.
    - 黑羽 EQA~: 一段大动画结束后持续普攻到星盘, 见星盘立即切明音凛缩轴.
      脚本用 Labels.blackbird_ult_2 近似检测, 超时兜底.
    - 伊洛伊 Z 是重击浮游炮.
    - 曳尔沐若要强信号, EQ 改为 EAAAEQ(开关 STRONG_SIGNAL, 默认关闭).
    - 次轮卡充能时原文给出替代: 曳尔沐E -> 伊洛伊援护技+E ->
      曳尔沐EAAAEQ -> 伊洛伊QZ. 该分支需实测充能判定, 暂未启用.

命名约定: 官方内置实现已占用角色本名(如 "Elyms" / "曳尔沐"), 自建出招表
必须换不同名字. UI 下拉显示为 "[外置代码] <目录> - <出招表名>", 内置则是
"[内置代码] 曳尔沐"; 为避免混淆, 搭配名前置: 本套统一为 "四环队·曳尔沐" /
"Four Ring · Elyms", 开头即与内置及其他搭配不同. 脚本文件名仍沿用官方角色
英文名以便对照.
"""

import sys

from src.char.BaseChar import BaseChar
from src.char.Elyms import Elyms as StockElyms
from src.combat.planner import Planner, RoleProfile

# ---------------------------------------------------------------------------
# 阶段定义(全队共享)
# ---------------------------------------------------------------------------

STAGE_ELYMS_OPEN = "elyms_open_e"
STAGE_AKANE_OPEN = "akane_open_e"
STAGE_IROI_EQZ = "iroi_eqz"
STAGE_ELYMS_EQ = "elyms_eq"
STAGE_BLACKBIRD_EQA = "blackbird_eqa"
STAGE_AKANE_COMBO = "akane_q1_8a_e_q2"
STAGE_BLACKBIRD_FINISH = "blackbird_e_5a_e_q2"

OPENING_STAGES = [
    STAGE_ELYMS_OPEN,
    STAGE_AKANE_OPEN,
    STAGE_IROI_EQZ,
    STAGE_ELYMS_EQ,
    STAGE_BLACKBIRD_EQA,
    STAGE_AKANE_COMBO,
    STAGE_BLACKBIRD_FINISH,
]

LOOP_STAGES = [
    STAGE_ELYMS_OPEN,
    STAGE_IROI_EQZ,
    STAGE_ELYMS_EQ,
    STAGE_BLACKBIRD_EQA,
    STAGE_AKANE_COMBO,
    STAGE_BLACKBIRD_FINISH,
]

STAGE_OWNER = {
    STAGE_ELYMS_OPEN: "Elyms",
    STAGE_AKANE_OPEN: "Akane",
    STAGE_IROI_EQZ: "Iroi",
    STAGE_ELYMS_EQ: "Elyms",
    STAGE_BLACKBIRD_EQA: "Blackbird",
    STAGE_AKANE_COMBO: "Akane",
    STAGE_BLACKBIRD_FINISH: "Blackbird",
}

ROTATION_ATTR = "four_ring_rotation"


class FourRingRotation:
    """首轮固定队列 + 次轮循环指针, 挂在 task.four_ring_rotation 上."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.queue = list(OPENING_STAGES)
        self.loop_cursor = 0
        self.rounds = 0

    def current_stage(self):
        if self.queue:
            return self.queue[0]
        return LOOP_STAGES[self.loop_cursor]

    def current_owner(self):
        return STAGE_OWNER[self.current_stage()]

    def stage_for(self, char):
        """当前阶段归属该角色时返回阶段名, 否则返回 None(脱轴)."""
        if self.current_owner() == type(char).__name__:
            return self.current_stage()
        return None

    def advance(self):
        if self.queue:
            self.queue.pop(0)
            if not self.queue:
                self.loop_cursor = 0
        else:
            self.loop_cursor = (self.loop_cursor + 1) % len(LOOP_STAGES)
            if self.loop_cursor == 0:
                self.rounds += 1

    def is_opening(self):
        return bool(self.queue)


def get_rotation(task):
    """获取(或惰性创建)本场战斗的排轴状态机."""
    rotation = getattr(task, ROTATION_ATTR, None)
    if rotation is None:
        rotation = FourRingRotation()
        setattr(task, ROTATION_ATTR, rotation)
    return rotation


def find_teammate(char, owner_name):
    """按角色类名在队伍里查找队友对象."""
    for teammate in char.task.chars:
        if teammate is not None and type(teammate).__name__ == owner_name:
            return teammate
    return None


def request_rotation_next(char, rotation, reason):
    """请求切到下一阶段归属角色(必须在 action/entry 帧内调用)."""
    target = find_teammate(char, rotation.current_owner())
    if target is None:
        char.logger.warning(
            f"four ring rotation: teammate {rotation.current_owner()} not found"
        )
        return
    char.logger.info(
        f"[four-ring] {type(char).__name__} done -> stage={rotation.current_stage()} "
        f"owner={rotation.current_owner()} rounds={rotation.rounds} "
        f"opening={rotation.is_opening()}"
    )
    char.combat_context.request_switch(target, reason=reason)


class RotationMixin:
    """收尾动作: 登记为 plan action, 在 action 帧内推进排轴并发布切人请求."""

    def rotation_next(self):
        rotation = get_rotation(self.task)
        rotation.advance()
        request_rotation_next(self, rotation, "four ring rotation -> next stage")
        return True

    def rotation_retry(self):
        """脱轴兜底: 不推进状态机, 只请求切回当前阶段归属角色."""
        rotation = get_rotation(self.task)
        request_rotation_next(self, rotation, "four ring rotation -> retry current stage")
        return True


def register_rotation_actions(plan, char):
    """把两个收尾动作登记进 plan, 并让它们不参与切人评分."""
    plan.register(
        char.rotation_next,
        name=f"{type(char).__name__}_four_ring_next",
        tags={Planner.ActionTag.DEFAULT_ACTION},
        reason="advance four ring rotation",
        priority_ready=lambda: False,
    )
    plan.register(
        char.rotation_retry,
        name=f"{type(char).__name__}_four_ring_retry",
        tags={Planner.ActionTag.DEFAULT_ACTION},
        reason="retry four ring rotation without advancing",
        priority_ready=lambda: False,
    )


def log_stage(char, rotation, stage):
    char.logger.info(
        f"[four-ring] {type(char).__name__} entry stage={stage} "
        f"current={rotation.current_stage()} rounds={rotation.rounds} "
        f"queue={rotation.queue}"
    )


# ---------------------------------------------------------------------------
# 曳尔沐(四环队出招表)
# ---------------------------------------------------------------------------


class Elyms(RotationMixin, StockElyms):
    cn_name = "四环队·曳尔沐"
    en_name = "Four Ring · Elyms"
    element = BaseChar.ElementType.WHITE

    # 排轴时值(按实测微调)
    SKILL_RECHECK_TIMEOUT = 1.2
    STRONG_SIGNAL = False
    STRONG_ATTACK_COUNT = 4
    ATTACK_INTERVAL = 0.2

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUB_DPS,
            max_field_time=0.5,
            combat_start_priority=10,
        )

    def combat_policies(self):
        """每场战斗重置排轴, 并锁定固定切人(屏蔽元素反应自动改切).

        四环队仍靠固定切人顺序触发浸染/延滞/创生/盈蓄; 这里屏蔽的是
        planner 在环合满时的自动改切(优先级 999500), 不是游戏内反应本身.
        """
        rotation = get_rotation(self.task)
        rotation.reset()
        self.logger.info("[four-ring] rotation reset, element reaction retarget disabled")
        self.task.find_element_reaction_target = lambda source_char: None

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan, add_tags=Planner.ActionTag.HIGH_PRIORITY)
        self.register_ultimate(plan)
        register_rotation_actions(plan, self)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        log_stage(self, rotation, stage)
        if stage == STAGE_ELYMS_OPEN:
            self.click_skill()
            self.rotation_next()
        elif stage == STAGE_ELYMS_EQ:
            self.perform_eq()
            self.rotation_next()
        else:
            self.logger.warning("[four-ring] Elyms unexpected entry, fallback")
            self.click_skill()
            if self.ultimate_available():
                self.click_ultimate()
            self.rotation_retry()

    def perform_eq(self):
        """E -> Q; 进阶版 E -> AAAA -> E -> Q(攒强信号)."""
        self.click_skill()
        if self.STRONG_SIGNAL:
            for _ in range(self.STRONG_ATTACK_COUNT):
                self.click()
                self.sleep(self.ATTACK_INTERVAL)
            self.task.wait_until(
                self.skill_available,
                post_action=self.click_with_interval,
                time_out=self.SKILL_RECHECK_TIMEOUT,
            )
            if not self.click_special_skill():
                self.click_skill()
        self.click_ultimate()
        return True


# ---------------------------------------------------------------------------
# 共享模块注册
# ---------------------------------------------------------------------------

TEAM_MODULE_KEY = "_four_ring_team_rotation_module"

try:
    from pathlib import Path as _Path

    _TEAM_SOURCE_STAMP = _Path(__file__).resolve().stat().st_mtime_ns
except OSError:
    _TEAM_SOURCE_STAMP = None

sys.modules[TEAM_MODULE_KEY] = sys.modules[__name__]
