"""四环队输出轴 - 伊洛伊.

排轴定位: E -> Q -> Z(长按普攻出浮游炮) -> 点一下预输入 -> 切下一段.
手法原文: 伊洛伊 EQZ, 其中 Z 为重击浮游炮; 切走后后台打完剩余段数.

用固定时长近似"松手后点一下"的合轴窗口, 实测快了/慢了调 HEAVY_DURATION.
通过共享模块(elyms.py)获取全队排轴状态机, 本文件不持有状态机定义.
"""

import sys


def _load_team_module():
    """加载同目录 elyms.py 内的全队共享排轴核心(按 mtime 失效缓存)."""
    import importlib.util
    from pathlib import Path

    key = "_four_ring_team_rotation_module"
    team_path = Path(__file__).resolve().with_name("elyms.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_IROI_EQZ = _team.STAGE_IROI_EQZ
get_rotation = _team.get_rotation
register_rotation_actions = _team.register_rotation_actions
log_stage = _team.log_stage

from src.char.BaseChar import BaseChar
from src.char.Iroi import Iroi as StockIroi
from src.combat.planner import Planner, RoleProfile


class Iroi(_team.RotationMixin, StockIroi):
    cn_name = "四环队·伊洛伊"
    en_name = "Four Ring · Iroi"
    element = BaseChar.ElementType.GREEN

    # 排轴时值(按实测微调)
    HEAVY_DURATION = 1.2
    PREINPUT_SLEEP = 0.15

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            max_field_time=0.5,
            combat_start_priority=0,
        )

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan)
        self.register_ultimate(plan)
        register_rotation_actions(plan, self)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        log_stage(self, rotation, stage)
        if stage == STAGE_IROI_EQZ:
            self.click_skill()
            self.click_ultimate()
            self.heavy_attack(self.HEAVY_DURATION)
            self.click()
            self.sleep(self.PREINPUT_SLEEP)
            self.rotation_next()
        else:
            self.logger.warning("[four-ring] Iroi unexpected entry, fallback")
            if self.skill_available():
                self.click_skill()
            if self.ultimate_available():
                self.click_ultimate()
            self.rotation_retry()
