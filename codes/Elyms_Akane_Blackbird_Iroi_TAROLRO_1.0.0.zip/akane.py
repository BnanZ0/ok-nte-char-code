"""四环队输出轴 - 明音凛.

排轴定位: 首轮 E 起手; 主段 Q1 -> 8A -> E -> Q2.
手法原文: 明音凛 E-Q1-AAAA-AAAA-E-Q2, 与黑羽分开穿插成双 C 循环.
通过共享模块(elyms.py)获取全队排轴状态机, 本文件不持有状态机定义.
"""

import sys


def _load_team_module():
    """加载同目录 elyms.py 内的全队共享排轴核心(按 mtime 失效缓存)."""
    import importlib.util
    from pathlib import Path

    key = "_four_ring_team_rotation_module"
    team_path = Path(__file__).resolve().with_name("elyms.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_AKANE_OPEN = _team.STAGE_AKANE_OPEN
STAGE_AKANE_COMBO = _team.STAGE_AKANE_COMBO
get_rotation = _team.get_rotation
register_rotation_actions = _team.register_rotation_actions
log_stage = _team.log_stage

from src.char.BaseChar import BaseChar
from src.char.Akane import Akane as StockAkane
from src.combat.planner import Planner, RoleProfile


class Akane(_team.RotationMixin, StockAkane):
    cn_name = "四环队·明音凛"
    en_name = "Four Ring · Akane"
    element = BaseChar.ElementType.YELLOW

    # 排轴时值(按实测微调)
    ULT_ATTACK_COUNT = 8
    ATTACK_INTERVAL = 0.2

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.MAIN_DPS,
            max_field_time=1.8,
            combat_start_priority=0,
        )

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan)
        self.register_ultimate(plan)
        register_rotation_actions(plan, self)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        log_stage(self, rotation, stage)
        if stage == STAGE_AKANE_OPEN:
            self.cast_skill()
            self.rotation_next()
        elif stage == STAGE_AKANE_COMBO:
            self.perform_q1_8a_e_q2()
            self.rotation_next()
        else:
            self.logger.warning("[four-ring] Akane unexpected entry, fallback")
            if self.skill_available():
                self.cast_skill()
            if self.ultimate_available():
                self.click_ultimate()
            self.rotation_retry()

    def perform_q1_8a_e_q2(self):
        """Q1 -> 8 段普攻 -> E(强化) -> Q2 收尾."""
        if self.click_ultimate():
            self.in_ult_start = self.clock.now()
        for _ in range(self.ULT_ATTACK_COUNT):
            self.click()
            self.sleep(self.ATTACK_INTERVAL)
        self.cast_skill()
        self.click_ultimate()
        self.in_ult_start = self.clock.UNSET
        self.skill_2_count = 0
        return True
