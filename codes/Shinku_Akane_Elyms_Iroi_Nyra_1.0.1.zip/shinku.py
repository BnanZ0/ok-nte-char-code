import sys
import dataclasses

from src.char.Shinku import Shinku as StockShinku
from src.combat.planner import Planner, RoleProfile

STAGE_OPEN_SHINKU_PASS = "open_shinku_pass"
STAGE_OPEN_AKANE_Q1 = "open_akane_q1"
STAGE_OPEN_ELYMS_EQ = "open_elyms_eq"
STAGE_OPEN_IROI_EQZ = "open_iroi_eqz"
STAGE_OPEN_AKANE_Q2 = "open_akane_q2"
STAGE_OPEN_SHINKU_BURST = "open_shinku_burst"

STAGE_LOOP_IROI_E = "loop_iroi_e"
STAGE_LOOP_AKANE_EQ = "loop_akane_eq"
STAGE_LOOP_ELYMS_EQ = "loop_elyms_eq"
STAGE_LOOP_IROI_QZ = "loop_iroi_qz"
STAGE_LOOP_AKANE_Q2 = "loop_akane_q2"
STAGE_LOOP_SHINKU_BURST = "loop_shinku_burst"

STAGE_OWNER = {
    STAGE_OPEN_SHINKU_PASS: "Shinku",
    STAGE_OPEN_AKANE_Q1: "Akane",
    STAGE_OPEN_ELYMS_EQ: "Elyms",
    STAGE_OPEN_IROI_EQZ: "Iroi",
    STAGE_OPEN_AKANE_Q2: "Akane",
    STAGE_OPEN_SHINKU_BURST: "Shinku",
    STAGE_LOOP_IROI_E: "Iroi",
    STAGE_LOOP_AKANE_EQ: "Akane",
    STAGE_LOOP_ELYMS_EQ: "Elyms",
    STAGE_LOOP_IROI_QZ: "Iroi",
    STAGE_LOOP_AKANE_Q2: "Akane",
    STAGE_LOOP_SHINKU_BURST: "Shinku",
}

OPENING_STAGES = [
    STAGE_OPEN_SHINKU_PASS,
    STAGE_OPEN_AKANE_Q1,
    STAGE_OPEN_ELYMS_EQ,
    STAGE_OPEN_IROI_EQZ,
    STAGE_OPEN_AKANE_Q2,
    STAGE_OPEN_SHINKU_BURST,
]

LOOP_STAGES = [
    STAGE_LOOP_IROI_E,
    STAGE_LOOP_AKANE_EQ,
    STAGE_LOOP_ELYMS_EQ,
    STAGE_LOOP_IROI_QZ,
    STAGE_LOOP_AKANE_Q2,
    STAGE_LOOP_SHINKU_BURST,
]

EXPECTED_ROLES = ("Shinku", "Akane", "Elyms", "Iroi")
WAIT_SWITCH_TIMEOUT = 3
ROTATION_LOG_ENABLED = False
_MUTED_LOG_LEVELS = ("debug", "info", "warning")


class _NoopLogger:
    def __init__(self, wrapped):
        self._wrapped = wrapped

    def __getattr__(self, name):
        if not ROTATION_LOG_ENABLED and name in _MUTED_LOG_LEVELS:
            return lambda *args, **kwargs: None
        return getattr(self._wrapped, name)


def load_team_module(current_file):
    import importlib.util
    from pathlib import Path

    key = "_shinku_wheelchair_team_module"
    team_path = Path(current_file).resolve().with_name("shinku.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


def _bind_rotation_logger(char):
    logger = getattr(char, "logger", None)
    if logger is None or getattr(logger, "_is_rotation_noop_logger", False):
        return
    wrapped = _NoopLogger(logger)
    try:
        wrapped._is_rotation_noop_logger = True
        char.logger = wrapped
    except Exception:
        pass


def diag_sleep(char, label, duration, checks=None):
    if duration <= 0:
        return
    start = char.clock.now()
    if checks is not None:
        char.sleep(duration, checks=checks)
    else:
        char.sleep(duration, checks=char.SleepChecks.NONE)
    actual = char.clock.now() - start
    if actual - duration > 0.15:
        char.logger.info(f"[诊断·sleep] {label} 设{duration:.2f} 实{actual:.2f} 超时")


def wait_sound_idle(char, max_wait=0.1, poll=0.03, label=""):
    try:
        from src.sound_trigger.SoundCombatContext import SoundCombatContext
    except Exception:
        return

    def _active():
        try:
            return bool(SoundCombatContext.should_interrupt_combat())
        except Exception:
            return False

    if not _active():
        return

    start = char.clock.now()
    waited = False
    while char.clock.now() - start < max_wait:
        if not _active():
            return
        waited = True
        char.sleep(poll, checks=char.SleepChecks.SOUND)
    if waited:
        char.logger.warning(
            f"[诊断·sound静默超时] {label} 等{char.clock.now()-start:.2f}s仍活跃"
        )


def sound_action_stamp():
    try:
        from src.sound_trigger.SoundCombatContext import SoundCombatContext

        ctx = SoundCombatContext()
        listener = getattr(ctx, "listener", None)
        return (getattr(listener, "_last_trigger_time", 0),) if listener else (0,)
    except Exception:
        return (0,)


def sound_action_changed(stamp):
    return sound_action_stamp() != stamp


def _log_send_state(char, label, phase, kind):
    try:
        avail = (
            char.ultimate_available() if kind == "ultimate" else char.skill_available()
        )
    except Exception:
        avail = "err"
    char.logger.info(f"[诊断·{phase}] {label} avail={avail}")


def log_before_click(char, label, kind):
    _log_send_state(char, label, f"{kind.upper()}点击前", kind)


def log_after_click(char, label, kind):
    _log_send_state(char, label, f"{kind.upper()}点击后", kind)


def _detect_missing_roles(task):
    present = {type(c).__name__ for c in task.chars if c is not None}
    return [r for r in EXPECTED_ROLES if r not in present]


class ShinkuRotation:
    _is_shinku_wheelchair_rotation = True

    def __init__(self):
        self.queue = []
        self._boss_approached = False
        self._battle_end_logged_session = None
        self._battle_start_session = None
        self._missing_roles_logged = False
        self.reset()

    def reset(self, new_battle=False):
        self.queue = list(OPENING_STAGES)
        self._battle_end_logged_session = None
        if new_battle:
            self._boss_approached = False

    def current_stage(self):
        return self.queue[0] if self.queue else None

    def current_owner(self):
        return STAGE_OWNER.get(self.current_stage(), "") if self.current_stage() else ""

    def stage_for(self, char):
        stage = self.current_stage()
        if stage and STAGE_OWNER.get(stage) == type(char).__name__:
            return stage
        return None

    def advance(self):
        if self.queue:
            self.queue.pop(0)
        if not self.queue:
            self.queue = list(LOOP_STAGES)


ROTATION_ATTR = "shinku_wheelchair_rotation"


def get_rotation(task):
    rotation = getattr(task, ROTATION_ATTR, None)
    if not getattr(rotation, "_is_shinku_wheelchair_rotation", False):
        rotation = ShinkuRotation()
        setattr(task, ROTATION_ATTR, rotation)
        task.find_element_reaction_target = lambda source_char: None
    return rotation


def find_teammate(char, owner_name):
    for t in char.task.chars:
        if t is not None and type(t).__name__ == owner_name:
            return t
    return None


def _safe_request_switch(char, target, reason):
    if target is None or getattr(target, "is_dead", False):
        return False
    if not getattr(char.task, "_in_combat", True):
        char.logger.info(f"[排轴] 已不在战斗中，跳过切人请求: {reason}")
        return False
    try:
        char.combat_context.request_switch(target, reason=reason)
        return True
    except RuntimeError as e:
        if "inactive planner cycle" in str(e):
            char.logger.warning(
                f"[排轴] planner 周期已结束，忽略切人请求 ({reason}): {e}"
            )
            return False
        raise


def _reset_and_switch_to_alive(char, rotation, reason="阵亡重置并切活人"):
    rotation.reset(new_battle=True)
    for t in getattr(char.task, "chars", ()):
        if t is not None and not getattr(t, "is_dead", False) and t is not char:
            char.logger.info(f"[{type(char).__name__}] {reason} -> {type(t).__name__}")
            try:
                char.task.next_frame()
            except Exception:
                pass
            _safe_request_switch(char, t, reason=reason)
            return True
    char.logger.warning(f"[{type(char).__name__}] {reason}，但无其他存活队友可切")
    return False


def advance_rotation(char, rotation):
    old_stage = rotation.current_stage()

    if old_stage == STAGE_OPEN_SHINKU_PASS and type(char).__name__ != "Shinku":
        shinku = find_teammate(char, "Shinku")
        if shinku is not None and not shinku.is_dead:
            char.logger.info(
                f"[排轴] 首切真红过场：{type(char).__name__} 请求切到 Shinku（不推进阶段）"
            )
            try:
                char.task.next_frame()
            except Exception:
                pass
            _safe_request_switch(char, shinku, reason="首切真红过场")
            return
        char.logger.warning(f"[排轴] 首切真红过场：Shinku 已死，跳过 {old_stage}")

    rotation.advance()

    max_skip = len(OPENING_STAGES) + len(LOOP_STAGES)
    for _ in range(max_skip):
        target_name = rotation.current_owner()
        target = find_teammate(char, target_name) if target_name else None
        if target is not None and not target.is_dead:
            break
        if target is None and target_name in EXPECTED_ROLES:
            char.logger.warning(
                f"[排轴跳过] {rotation.current_stage()} owner={target_name} 找不到，跳过"
            )
        else:
            char.logger.warning(
                f"[排轴跳过] {rotation.current_stage()} owner={target_name} 已死或不存在，跳过"
            )
        rotation.advance()
    else:
        char.logger.warning("[排轴警告] 所有阶段 owner 都已死亡或缺失，重置轴到启动轴")
        rotation.reset()
        return

    target_name = rotation.current_owner()
    target = find_teammate(char, target_name)
    char.logger.info(
        f"[排轴推进] {type(char).__name__} 完成 {old_stage} -> 推进至 {rotation.current_stage()}"
    )

    if target is char:
        char.logger.info(f"[排轴推进] 下一阶段仍为 {target_name}，原地继续")
        return

    try:
        char.task.next_frame()
    except Exception:
        pass
    _safe_request_switch(
        char, target, reason=f"wheelchair -> {rotation.current_stage()}"
    )


class RotationInput:

    INTRO_SETTLE_SLEEP = 0.5
    ULTIMATE_FREEZE_MAX = 1.5

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bind_rotation_logger(self)
        self.planner_handles_arc = True
        self._wait_switch_since = None

    def _record_combat_end(self, reason=""):
        _bind_rotation_logger(self)
        rotation = get_rotation(self.task)
        session = getattr(self.task, "combat_session", None)
        if getattr(rotation, "_battle_end_logged_session", None) is session:
            return
        rotation._battle_end_logged_session = session
        suffix = f" ({reason})" if reason else ""
        self.logger.info(f"[排轴] 战斗结束，记录 session{suffix}")

    def on_combat_end(self, chars):
        self._record_combat_end()
        super().on_combat_end(chars)

    def _on_self_dead(self, rotation):
        """默认阵亡处理：重置轴到启动阶段并切到存活队友。"""
        _bind_rotation_logger(self)
        self._wait_switch_since = None
        self.logger.warning(
            f"[{type(self).__name__}] 阵亡于 {rotation.current_stage()}，重置轴并切活人"
        )
        _reset_and_switch_to_alive(
            self, rotation, reason=f"{type(self).__name__}阵亡重置"
        )

    def _handle_waiting_other_stage(self, rotation):
        current_owner_name = rotation.current_owner()
        current_owner = (
            find_teammate(self, current_owner_name) if current_owner_name else None
        )
        if current_owner is None or current_owner.is_dead:
            self.logger.warning(
                f"[{self.cn_name}] 队列头 {current_owner_name} 已死或不存在，跳过"
            )
            self._wait_switch_since = None
            self._wait_switch_first_at = None
            self._wait_retry_count = 0
            advance_rotation(self, rotation)
            return

        now = self.clock.now()
        if getattr(self, "_wait_switch_since", None) is None:
            self._wait_switch_since = now
            self._wait_switch_first_at = now
            self._last_wait_log_at = 0
            self._wait_retry_count = 0
        waited = now - self._wait_switch_since

        # 超过超时时间先多次补发切人；仅在长时间（约 3 倍超时）仍无法切走时才兜底推进，避免误跳正常轴
        if waited > WAIT_SWITCH_TIMEOUT:
            retry_idx = getattr(self, "_wait_retry_count", 0) + 1
            self._wait_retry_count = retry_idx
            total_waited = now - self._wait_switch_first_at
            self.logger.warning(
                f"[{self.cn_name}] 等待切人超时 {waited:.1f}s（累计 {total_waited:.1f}s，第 {retry_idx} 次），"
                f"重新 request_switch 到 {current_owner_name}"
            )
            try:
                self.task.next_frame()
            except Exception:
                pass
            _safe_request_switch(
                self,
                current_owner,
                reason=f"retry switch -> {rotation.current_stage()}",
            )
            if total_waited >= WAIT_SWITCH_TIMEOUT * 3 and retry_idx >= 3:
                self.logger.warning(
                    f"[{self.cn_name}] 累计等待 {total_waited:.1f}s 仍未切走，兜底推进阶段防死锁"
                )
                self._wait_switch_since = None
                self._wait_switch_first_at = None
                self._wait_retry_count = 0
                advance_rotation(self, rotation)
                return
            self._wait_switch_since = now
        else:
            # [修改] 每 0.8s 最多打印一次等待日志，避免高频刷屏
            last_log = getattr(self, "_last_wait_log_at", 0)
            if now - last_log >= 0.8:
                self._last_wait_log_at = now
                self.logger.info(
                    f"[{self.cn_name}] 当前非本角色阶段"
                    f"（{rotation.current_stage()}），等待切人 {waited:.1f}s"
                )

    def wait_intro(self, time_out=-1, click=False):
        if not self.has_intro:
            return
        self.sleep(self.INTRO_SETTLE_SLEEP, checks=self.SleepChecks.COMBAT)

    def _wait_ultimate_unfreeze(self, start, click=False):
        from src.Labels import Labels
        from src.utils import game_filters as gf

        post_action = (
            (lambda: self.click(action_name="ultimate_click", interval=0.25))
            if click
            else None
        )

        if self.ultimate_freeze_wait is not None:
            wait = self.ultimate_freeze_wait
            if click:
                self.continues_normal_attack(wait)
            else:
                self.sleep(wait, checks=self.SleepChecks.NONE)
            duration = self.clock.now() - start
            self.add_freeze_duration(start, duration)
            return duration

        self.task.wait_until(
            lambda: self.has_cd("ultimate"), post_action=post_action, time_out=1
        )
        box_ultimate = self.task.get_box_by_name(Labels.box_ultimate)
        snapshot = box_ultimate.crop_frame(self.task.frame)
        processed_snapshot = gf.isolate_text_to_black(snapshot)

        def condition():
            if not self.task.find_one(
                Labels.box_ultimate,
                template=processed_snapshot,
                box=box_ultimate.scale(1.1, 1.1),
                frame_processor=gf.isolate_text_to_black,
                threshold=0.9,
            ):
                self.logger.info("ultimate unfreeze cause cd changed")
                return True
            elif not self.available("ultimate", check_cd=False):
                self.logger.info("ultimate unfreeze cause ultimate not available")
                return True

        self.task.wait_until(condition, time_out=2, post_action=post_action)
        duration = self.clock.now() - start
        self.add_freeze_duration(start, min(duration, self.ULTIMATE_FREEZE_MAX))
        return duration

    def click_with_interval(self, interval=0.1):
        return False

    def refresh_frame(self):
        try:
            self.task.next_frame()
        except Exception:
            pass

    def _ensure_in_combat(self, is_burst=False):
        if getattr(self.task, "in_animation", False):
            return
        if not getattr(self.task, "_in_combat", True):
            if is_burst:
                self.logger.warning("爆发期检测到脱战，但允许继续执行当前动作")
                return
            self.task.raise_not_in_combat("wheelchair loop detected not in combat")

    def _ensure_self_current_char(self, rotation, stage, timeout=0.5):
        if self.is_current_char:
            return True
        wait_start = self.clock.now()
        while not self.is_current_char and self.clock.now() - wait_start < timeout:
            if self.is_dead:
                self._on_self_dead(rotation)
                return False
            self.sleep(0.1, checks=self.SleepChecks.COMBAT)
            self.refresh_frame()
        if not self.is_current_char:
            for retry_idx in range(2):
                self.logger.warning(
                    f"[{self.cn_name}] 阶段 {stage} 入口 {timeout:.1f}s 内未切到本角色，"
                    f"第 {retry_idx + 1} 次主动补发切人"
                )
                try:
                    target = find_teammate(self, type(self).__name__) or self
                    _safe_request_switch(
                        self, target, reason=f"ensure switch -> {stage}"
                    )
                except Exception as sw_err:
                    self.logger.warning(f"[{self.cn_name}] 补发切人失败: {sw_err}")
                self.sleep(0.2, checks=self.SleepChecks.COMBAT)
                self.refresh_frame()
                if self.is_current_char:
                    return True
            self.logger.warning(
                f"[{self.cn_name}] 补发切人后仍未到场，退出本次入场等待下次"
            )
            return False
        return True

    def switch_next_char(self, post_action=None, free_intro=False):
        task = self.task
        original_click = task.click
        had_override = "click" in vars(task)

        def switch_click(*args, **kwargs):
            if kwargs.get("action_name") == "switch_char_click":
                return False
            return original_click(*args, **kwargs)

        def after_switch(target, has_intro):
            target.has_intro = has_intro and task.can_element_react(self, target)
            if post_action:
                post_action(target, target.has_intro)

        task.click = switch_click
        try:
            return super().switch_next_char(
                post_action=after_switch, free_intro=free_intro
            )
        finally:
            if had_override:
                task.click = original_click
            else:
                try:
                    del task.click
                except AttributeError:
                    pass

    def _retry_block(self, name, block_func, max_attempts=2, not_in_combat_retry=True):
        _bind_rotation_logger(self)
        not_in_combat_retried = False
        for attempt in range(max_attempts + 1):
            if attempt > 0:
                self.logger.warning(f"[{name}] 第 {attempt} 次重试")
                if not self.is_current_char or getattr(
                    self.task, "combat_detect_uncertain", False
                ):
                    diag_sleep(
                        self, f"{name}重试前", 0.1, checks=self.SleepChecks.COMBAT
                    )
                else:
                    diag_sleep(
                        self, f"{name}重试前", 0.15, checks=self.SleepChecks.NONE
                    )
            if self.is_dead:
                self.logger.warning(f"[{name}] 角色阵亡，终止")
                return False
            try:
                if block_func():
                    return True
                not_in_combat_retried = False
            except Exception as e:
                err_name = type(e).__name__
                if err_name == "TaskDisabledException":
                    raise
                if err_name == "NotInCombatException":
                    if not not_in_combat_retry:
                        raise
                    if not_in_combat_retried:
                        self.logger.warning(f"[{name}] 重试后再次脱战，向外抛出: {e}")
                        raise
                    not_in_combat_retried = True
                    self.logger.warning(
                        f"[{name}] 瞬时脱战，尝试等待战斗恢复（Boss 飞天/转阶段）: {e}"
                    )
                    try:
                        recovered = self.task.wait_until(
                            self.task.in_combat, time_out=3, raise_if_not_found=False
                        )
                    except Exception as we:
                        self.logger.warning(f"[{name}] 等待战斗恢复异常: {we}")
                        recovered = False
                    if not recovered:
                        self.logger.warning(f"[{name}] 战斗未恢复，向外抛出")
                        raise
                    self.logger.info(f"[{name}] 战斗已恢复，准备重试")
                    continue
                else:
                    self.logger.warning(
                        f"[{name}] 执行异常（{err_name}），准备重试: {e}"
                    )
        if not_in_combat_retried:
            self.task.raise_not_in_combat(f"{name} 重试用尽且期间发生过脱战")
        self.logger.warning(f"[{name}] 重试用尽，放弃")
        return False


class Shinku(RotationInput, StockShinku):
    cn_name = "真红"
    en_name = "Shinku"

    ENABLE_APPROACH_BOSS = True
    APPROACH_W_PRESS_WAIT = 0.1
    APPROACH_DODGE_INTERVAL = 0.2
    APPROACH_DODGE_DOWN_TIME = 0.1
    APPROACH_DODGE_KEY = "lshift"
    APPROACH_FORWARD_KEY = "w"
    APPROACH_FINAL_WAIT = 0.1
    APPROACH_MOUSE_RELEASE_WAIT = 0.05

    ENGAGE_TIMEOUT = 10
    ENGAGE_INITIAL_SETTLE = 0.3
    LOOP_ENGAGE_TIMEOUT = 12
    BURST_WINDOW = 16

    BURST_E_MAX_COUNT = 5
    BURST_E_MAX_RETRY = 2
    BURST_E_FAIL_LIMIT = 6
    BURST_E_POST_SLEEP = 0.3
    BURST_E_RETRY_DELAY = 0.1
    BURST_E_CHECK_TIMEOUT = 0.4
    BURST_Q1_TO_E_SLEEP = 1.5
    BURST_ATTACK_INTERVAL = 0.1

    Q1_ANIMATION_WAIT = 1.2
    Q2_ANIMATION_WAIT = 0.3
    Q2_SETTLE = 0.3
    Q2_RETRY = 1
    QREST_ANIMATION_WAIT = 0.3

    ENGAGE_FULL_STREAK_REQUIRED = 3
    ENGAGE_FULL_DIAG_INTERVAL = 0.2

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.MAIN_DPS,
            field_preference=Planner.FieldPreference.MAIN_DPS,
            max_field_time=0,
            combat_start_priority=100,
        )

    def _on_self_dead(self, rotation):
        """主C阵亡：重置启动状态与轴，并切到存活队友。"""
        _bind_rotation_logger(self)
        self._wait_switch_since = None
        self.logger.warning(
            f"[真红] 阵亡于 {rotation.current_stage()}，主C重置轴并切活人"
        )
        _reset_and_switch_to_alive(self, rotation, reason="真红阵亡重置")

    def _wait_ultimate_unfreeze(self, start, click=False):
        if getattr(self, "_is_q1", False):
            self.sleep(self.Q1_ANIMATION_WAIT, checks=self.SleepChecks.NONE)
            duration = self.clock.now() - start
            self.add_freeze_duration(start, duration)
            return duration
        if getattr(self, "_is_q2", False):
            self.sleep(self.Q2_ANIMATION_WAIT, checks=self.SleepChecks.NONE)
            duration = self.clock.now() - start
            self.add_freeze_duration(start, duration)
            return duration
        if getattr(self, "_is_q_rest", False):
            self.sleep(self.QREST_ANIMATION_WAIT, checks=self.SleepChecks.NONE)
            duration = self.clock.now() - start
            self.add_freeze_duration(start, duration)
            return duration
        return super()._wait_ultimate_unfreeze(start=start, click=click)

    def _install_start_hooks(self):
        task = self.task
        if getattr(task, "_wheelchair_hooks_installed", False):
            return
        task._wheelchair_hooks_installed = True

        original_click = task.click

        def patched_click(*args, **kwargs):
            if getattr(task, "_wheelchair_skip_start_click", False):
                self.logger.info("[首切] 拦截开场多余点击，防止普攻")
                return False
            return original_click(*args, **kwargs)

        task.click = patched_click

        original_begin = task.begin_combat_session

        def patched_begin():
            if task.combat_session.start_char is not None:
                return original_begin()
            task._wheelchair_skip_start_click = True
            try:
                return original_begin()
            finally:
                task._wheelchair_skip_start_click = False

        task.begin_combat_session = patched_begin

        original_switch = task.switch_to_combat_start_char
        char_self = self

        def patched_switch():
            if not task.combat_session.switch_enabled:
                return original_switch()
            try:
                current_char = task.get_current_char(raise_exception=False)
                decision = task.combat_planner.decide_combat_start_char(current_char)
                switch_to = decision.target
                if switch_to is None or current_char == switch_to:
                    return

                orig_intro = getattr(decision, "has_intro", None)
                new_decision = decision
                if dataclasses.is_dataclass(decision) and not isinstance(
                    decision, type
                ):
                    new_decision = dataclasses.replace(decision, has_intro=False)
                else:
                    try:
                        object.__setattr__(decision, "has_intro", False)
                    except Exception:
                        decision.has_intro = False

                _bind_rotation_logger(char_self)
                char_self.logger.info(
                    f"[首切] 强制无援护 -> {switch_to} (原 has_intro={orig_intro})"
                )
                task._switch_to_char(
                    new_decision,
                    current_char=current_char,
                    log_prefix="planner combat start (no-intro)",
                )
            except Exception as e:
                err_name = type(e).__name__
                if err_name in ("TaskDisabledException", "NotInCombatException"):
                    raise
                _bind_rotation_logger(char_self)
                char_self.logger.warning(f"[首切] hook 异常回退: {e}")
                return original_switch()

        task.switch_to_combat_start_char = patched_switch

    def _approach_boss(self):
        if self.is_dead or not self.ENABLE_APPROACH_BOSS:
            return
        rotation = get_rotation(self.task)
        if getattr(rotation, "_boss_approached", False):
            return

        try:
            self.task.mouse_up("left")
        except Exception:
            pass
        if self.APPROACH_MOUSE_RELEASE_WAIT > 0:
            diag_sleep(self, "首切·清残留", self.APPROACH_MOUSE_RELEASE_WAIT)

        self.logger.info("[真红] 首切接近BOSS：按住W + 闪避")
        try:
            self.task.send_key_down(self.APPROACH_FORWARD_KEY)
        except Exception as e:
            self.logger.error(f"[真红] send_key_down 失败：{e}")
            return
        try:
            diag_sleep(self, "首切·W预热", self.APPROACH_W_PRESS_WAIT)
            if self.is_dead:
                return
            self.send_key(
                self.APPROACH_DODGE_KEY, down_time=self.APPROACH_DODGE_DOWN_TIME
            )
            diag_sleep(self, "首切·闪避1后", self.APPROACH_DODGE_INTERVAL)
            if self.is_dead:
                return
            self.send_key(
                self.APPROACH_DODGE_KEY, down_time=self.APPROACH_DODGE_DOWN_TIME
            )
            diag_sleep(self, "首切·闪避2后收尾", self.APPROACH_FINAL_WAIT)
        finally:
            try:
                self.task.send_key_up(self.APPROACH_FORWARD_KEY)
            except Exception:
                pass
        rotation._boss_approached = True

    def _open_engage(self):
        if self.is_dead:
            return False
        self._ensure_in_combat()
        if self.skill_available():
            log_before_click(self, "真红首切E", "skill")
            self.click_skill(send_click=False, down_time=0.05)
            log_after_click(self, "真红首切E", "skill")

        if self.ENGAGE_INITIAL_SETTLE > 0:
            self.sleep(self.ENGAGE_INITIAL_SETTLE, checks=self.SleepChecks.COMBAT)

        start = self.clock.now()
        full_streak = 0
        last_diag_time = start
        while self.clock.now() - start < self.ENGAGE_TIMEOUT:
            if self.is_dead:
                return False
            self._ensure_in_combat()
            full = self.is_cycle_full()
            if full:
                full_streak += 1
            else:
                full_streak = 0
            elapsed = self.clock.now() - start
            if self.clock.now() - last_diag_time >= self.ENGAGE_FULL_DIAG_INTERVAL:
                self.logger.info(
                    f"[首切诊断] {elapsed:.2f}s cycle_full={full} streak={full_streak}"
                )
                last_diag_time = self.clock.now()
            if full_streak >= self.ENGAGE_FULL_STREAK_REQUIRED:
                self.logger.info(f"[首切诊断] 确认满环合 耗时={elapsed:.2f}s")
                return True
            self.check_combat()
            self.click(interval=self.BURST_ATTACK_INTERVAL)
            if self.is_dead:
                return False
        self.logger.warning(f"[真红首切] 打满环合超时 {self.ENGAGE_TIMEOUT}s")
        return False

    def _send_e_burst(self, e_count=0):
        is_last_e = e_count >= self.BURST_E_MAX_COUNT - 1
        max_retry = 1 if is_last_e else self.BURST_E_MAX_RETRY
        e_check_timeout = 0.1 if is_last_e else self.BURST_E_CHECK_TIMEOUT

        for attempt in range(1, max_retry + 1):
            if self.ultimate_available():
                self.logger.warning("[真红爆发] Q2 已亮，放弃 E，转 Q2")
                return None
            label = "真红爆发E" if attempt == 1 else f"真红爆发E补发{attempt-1}"
            wait_sound_idle(self, label=f"真红·{label}前", max_wait=0.1)
            log_before_click(self, label, "skill")
            self.send_skill_key(down_time=0.05, action_name=f"burst_{label}")
            if self.BURST_E_POST_SLEEP > 0:
                post_wait = (
                    min(self.BURST_E_POST_SLEEP, 0.15)
                    if is_last_e
                    else self.BURST_E_POST_SLEEP
                )
                self.sleep(post_wait, checks=self.SleepChecks.NONE)
            self.refresh_frame()
            unavailable = False
            try:
                unavailable = bool(
                    self.task.wait_until(
                        lambda: not self.skill_available(),
                        time_out=e_check_timeout,
                        raise_if_not_found=False,
                    )
                )
            except Exception as e:
                err_name = type(e).__name__
                if err_name in ("TaskDisabledException", "NotInCombatException"):
                    raise
                self.logger.warning(f"[诊断·吞] {label} 等待技能状态异常: {e}")
            log_after_click(self, label, "skill")
            if unavailable:
                return True
            if is_last_e:
                self.logger.info(
                    f"[真红爆发] {label} 已达上限轮次（E={e_count + 1}/{self.BURST_E_MAX_COUNT}），图标仍亮视为收尾"
                )
                return True
            self.logger.warning(
                f"[诊断·吞] {label} E 发键后 {e_check_timeout:.2f}s 仍可用，可能被吞"
            )
            if attempt < max_retry:
                self.logger.warning(
                    f"[真红爆发] {label} 被吞，等 {self.BURST_E_RETRY_DELAY}s"
                )
                self.sleep(self.BURST_E_RETRY_DELAY, checks=self.SleepChecks.NONE)
        return False

    def _open_burst(self):
        if self.is_dead:
            return False
        self._ensure_in_combat(is_burst=True)
        rotation = get_rotation(self.task)
        is_loop_burst = rotation.current_stage() == STAGE_LOOP_SHINKU_BURST

        # [修改] 仅非循环轴（启动轴）在切入或弹刀后短等 Q 就绪，循环轴已由 _loop_burst 完成攒能与就绪等待
        if not is_loop_burst:
            wait_start = self.clock.now()
            while not self.ultimate_available():
                if self.is_dead:
                    return False
                if self.clock.now() - wait_start >= 0.5:
                    self.logger.warning("[真红爆发] Q 能量不足，跳过")
                    return False
                self.check_combat()
                self.click(interval=self.BURST_ATTACK_INTERVAL)
                self.sleep(0.05, checks=self.SleepChecks.NONE)
                self.refresh_frame()

        log_before_click(self, "真红爆发Q1", "ultimate")
        self._is_q1 = True
        try:
            self.click_ultimate(send_click=False)
        finally:
            self._is_q1 = False
        log_after_click(self, "真红爆发Q1", "ultimate")
        if self.BURST_Q1_TO_E_SLEEP > 0:
            self.sleep(self.BURST_Q1_TO_E_SLEEP, checks=self.SleepChecks.NONE)
        if self.is_dead:
            return False
        start = self.clock.now()
        e_count, e_fail_streak, q2_ready = 0, 0, False
        e_max_logged = False

        while self.clock.now() - start < self.BURST_WINDOW:
            if self.is_dead:
                return False
            self._ensure_in_combat(is_burst=True)

            if self.ultimate_available():
                self.logger.info(
                    f"[真红爆发] Q2 亮（{self.clock.now() - start:.2f}s），转 Q2-Q5（E={e_count}）"
                )
                q2_ready = True
                break

            if e_count >= self.BURST_E_MAX_COUNT:
                if not e_max_logged:
                    self.logger.info(
                        f"[真红爆发] E 已打满（E={e_count}），Q2 未亮，转为普攻等待"
                    )
                    e_max_logged = True
                self.check_combat()
                self.click(interval=self.BURST_ATTACK_INTERVAL)
                continue

            if e_fail_streak >= self.BURST_E_FAIL_LIMIT:
                if e_count > 0:
                    if not e_max_logged:
                        self.logger.info(
                            f"[真红爆发] E 连续失败 {e_fail_streak} 次且已打出 {e_count} 个，视为打满，转为普攻等待"
                        )
                        e_max_logged = True
                    self.check_combat()
                    self.click(interval=self.BURST_ATTACK_INTERVAL)
                    continue
                else:
                    self.logger.warning(
                        f"[真红爆发] E 连续失败 {e_fail_streak} 次且 E=0，可能是 Q1 后摇导致，重置失败计数重试"
                    )
                    e_fail_streak = 0
                    self.check_combat()
                    self.click(interval=self.BURST_ATTACK_INTERVAL)
                    continue

            if self.skill_available():
                e_result = self._send_e_burst(e_count=e_count)
                if e_result is True:
                    e_count += 1
                    e_fail_streak = 0
                    self.logger.info(
                        f"[真红爆发] E #{e_count}/{self.BURST_E_MAX_COUNT}"
                    )
                elif e_result is False:
                    e_fail_streak += 1
                    self.logger.warning(
                        f"[真红爆发] E 未放出，连续失败={e_fail_streak}，实际 E={e_count}"
                    )
                    self.sleep(0.1, checks=self.SleepChecks.NONE)
                continue

            self.check_combat()
            self.click(interval=self.BURST_ATTACK_INTERVAL)

        if not q2_ready:
            self.logger.warning(
                f"[真红爆发] 窗口 {self.BURST_WINDOW}s 结束 Q2 仍未亮，E={e_count}"
            )
            return False

        # --- Q2 前稳定 ---
        if self.Q2_SETTLE > 0:
            diag_sleep(
                self, "真红Q2前稳定", self.Q2_SETTLE, checks=self.SleepChecks.NONE
            )
        self.refresh_frame()

        self._is_q2 = True
        try:
            attempt = 0
            while attempt <= self.Q2_RETRY:
                attempt += 1
                log_before_click(self, "真红Q2", "ultimate")
                self.click_ultimate(send_click=False)
                log_after_click(self, "真红Q2", "ultimate")
                if self.is_dead:
                    return False
                try:
                    avail_after = self.ultimate_available()
                except Exception as e:
                    self.logger.warning(f"[真红爆发] Q2 后查询状态异常: {e}")
                    avail_after = None
                # 实机 Q2 后进入 Q3-Q5 连段状态时 ultimate_available() 可能返回 None，视为已触发
                if avail_after is False or avail_after is None:
                    break
                if attempt <= self.Q2_RETRY:
                    diag_sleep(self, "真红Q2重试前", 0.1, checks=self.SleepChecks.NONE)
                else:
                    self.logger.warning("[真红爆发] Q2 重试用尽仍可用，跳过")
                    break
        finally:
            self._is_q2 = False

        self._is_q_rest = True
        try:
            for q_index in range(3, 6):
                if self.is_dead:
                    return False
                self._ensure_in_combat(is_burst=True)
                log_before_click(self, f"真红Q{q_index}", "ultimate")
                self.click_ultimate(send_click=False)
                log_after_click(self, f"真红Q{q_index}", "ultimate")
                self.sleep(0.05, checks=self.SleepChecks.NONE)
        finally:
            self._is_q_rest = False

        self.logger.info(
            f"[真红爆发] 完成 E={e_count} Q2-Q5 已发 耗时={self.clock.now() - start:.2f}s"
        )
        return True

    def _loop_burst(self):
        if self.is_dead:
            return False
        self._ensure_in_combat()
        self.refresh_frame()

        # 先判断 Q：就绪直接爆发，不放站场 E，避免浪费 E CD
        if self.ultimate_available():
            return self._open_burst()

        if self.skill_available():
            log_before_click(self, "真红站场E", "skill")
            self.click_skill(send_click=False, down_time=0.05)
            log_after_click(self, "真红站场E", "skill")
            self.sleep(0.05, checks=self.SleepChecks.NONE)

        start = self.clock.now()

        def _ready():
            return self.ultimate_available()

        while self.clock.now() - start < self.LOOP_ENGAGE_TIMEOUT:
            if self.is_dead:
                return False
            self._ensure_in_combat()
            self.refresh_frame()
            if _ready():
                return self._open_burst()
            self.check_combat()
            self.click(interval=self.BURST_ATTACK_INTERVAL)
            if self.is_dead:
                return False
            self.refresh_frame()
            if _ready():
                return self._open_burst()
            if self.skill_available():
                log_before_click(self, "真红站场E再发", "skill")
                self.click_skill(send_click=False, down_time=0.05)
                log_after_click(self, "真红站场E再发", "skill")
                self.refresh_frame()
                if _ready():
                    return self._open_burst()
        self.logger.warning(f"[真红站场] 等待Q可用超时 {self.LOOP_ENGAGE_TIMEOUT}s")
        return False

    def combat_policies(self):
        _bind_rotation_logger(self)
        rotation = get_rotation(self.task)
        current_session = getattr(self.task, "combat_session", None)
        start_session = getattr(rotation, "_battle_start_session", None)

        if current_session is not start_session:
            rotation.reset(new_battle=True)
            rotation._battle_start_session = current_session
            self.logger.info("[排轴] 新战斗进入，重置到启动轴")
        else:
            self.logger.info(
                f"[排轴] 本战斗内重复调用，保持 stage={rotation.current_stage()}"
            )

        missing = _detect_missing_roles(self.task)
        if missing and not getattr(rotation, "_missing_roles_logged", False):
            rotation._missing_roles_logged = True
            self.logger.warning(
                f"[排轴警告] 队伍缺失角色 {missing}，可能识别为 BaseChar，对应阶段将被跳过"
            )

        self._install_start_hooks()
        self.task.find_element_reaction_target = lambda source_char: None

    def combat_plan(self):
        rotation = get_rotation(self.task)

        def entry():
            _bind_rotation_logger(self)
            stage = rotation.stage_for(self)
            self.logger.info(f"[真红入场] 阶段={stage}")
            if self.is_dead:
                self._on_self_dead(rotation)
                return

            # 非本角色阶段：队列头是别人，等待切人，不推进队列
            if stage is None:
                self._handle_waiting_other_stage(rotation)
                return

            self._wait_switch_since = None
            self._wait_switch_first_at = None
            self._wait_retry_count = 0

            try:
                if stage == STAGE_OPEN_SHINKU_PASS:
                    self._approach_boss()
                    if not self.is_dead:
                        engage_ok = self._retry_block(
                            "真红首切E+打满环合", self._open_engage, max_attempts=2
                        )
                        if not engage_ok and not self.is_dead:
                            self.logger.warning(
                                "[真红首切] 打满环合未完成，本轮不推进阶段，等待下次切入"
                            )
                            return
                elif stage == STAGE_OPEN_SHINKU_BURST:
                    burst_ok = self._retry_block(
                        "真红启动爆发", self._open_burst, max_attempts=2
                    )
                    if not burst_ok and not self.is_dead and self.is_current_char:
                        self.logger.warning(
                            "[真红启动爆发] 未成功触发，尝试补普攻/E攒能一次后再进爆发"
                        )
                        for _ in range(4):
                            if self.is_dead or self.ultimate_available():
                                break
                            self.click(interval=self.BURST_ATTACK_INTERVAL)
                            self.sleep(0.05, checks=self.SleepChecks.COMBAT)
                            self.refresh_frame()
                        if self.ultimate_available():
                            burst_ok = self._open_burst()
                    if not burst_ok:
                        self.logger.warning(
                            "[真红启动爆发] 最终未完成，本轮不推进阶段，等待下次切入"
                        )
                        return
                elif stage == STAGE_LOOP_SHINKU_BURST:
                    loop_ok = self._retry_block(
                        "真红循环爆发", self._loop_burst, max_attempts=2
                    )
                    if not loop_ok:
                        self.logger.warning(
                            "[真红循环爆发] 未完成，本轮不推进阶段，等待下次切入"
                        )
                        return
                else:
                    self.logger.warning(f"[真红异常] 阶段={stage}，直接切人")
            except Exception as e:
                err_name = type(e).__name__
                if err_name == "TaskDisabledException":
                    self._record_combat_end("TaskDisabledException")
                    raise
                if err_name == "NotInCombatException":
                    self._record_combat_end("NotInCombatException")
                    self.logger.warning("[真红] 脱战，向外抛出")
                    raise
                self.logger.error(f"[真红异常] {err_name}: {e}")

            if self.is_dead:
                self._on_self_dead(rotation)
                return
            advance_rotation(self, rotation)

        return self.plan(entry=entry)


TEAM_MODULE_KEY = "_shinku_wheelchair_team_module"
try:
    from pathlib import Path as _Path

    _TEAM_SOURCE_STAMP = _Path(__file__).resolve().stat().st_mtime_ns
except OSError:
    _TEAM_SOURCE_STAMP = None
sys.modules.setdefault(TEAM_MODULE_KEY, sys.modules[__name__])
