import importlib.util
import sys
from pathlib import Path


def _bootstrap_team_module():
    key = "_shinku_wheelchair_team_module"
    cached = sys.modules.get(key)
    if cached is not None and hasattr(cached, "load_team_module"):
        return cached.load_team_module(__file__)
    team_path = Path(__file__).resolve().with_name("shinku.py")
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module.load_team_module(__file__)


_team = _bootstrap_team_module()
STAGE_OPEN_IROI_EQZ = _team.STAGE_OPEN_IROI_EQZ
STAGE_LOOP_IROI_E = _team.STAGE_LOOP_IROI_E
STAGE_LOOP_IROI_QZ = _team.STAGE_LOOP_IROI_QZ
WAIT_SWITCH_TIMEOUT = _team.WAIT_SWITCH_TIMEOUT
get_rotation = _team.get_rotation
advance_rotation = _team.advance_rotation
wait_sound_idle = _team.wait_sound_idle
RotationInput = _team.RotationInput
log_before_click = _team.log_before_click
log_after_click = _team.log_after_click
_bind_rotation_logger = _team._bind_rotation_logger
_safe_request_switch = _team._safe_request_switch

from src.char.Iroi import Iroi as StockIroi
from src.combat.planner import Planner, RoleProfile


class Iroi(RotationInput, StockIroi):
    cn_name = "伊洛伊"
    en_name = "Iroi"

    INTRO_SETTLE_SLEEP = 0.2
    E_TO_Q_SLEEP = 0.3
    E_WAIT_TIMEOUT = 0.5
    E_WAIT_POLL = 0.05
    Q_POST_SLEEP = 0.2
    Q_TO_Z_SLEEP = 0.15
    HEAVY_HOLD_DURATION = 0.6

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def wait_intro(self, time_out=-1, click=False):
        self.sleep(self.INTRO_SETTLE_SLEEP, checks=self.SleepChecks.COMBAT)

    def click_ultimate(self, send_click=True, wait_if_no_cd=0):
        # 绕过 StockIroi.click_ultimate：其内部可能有 Q 状态消耗/充能逻辑，
        # 本队伍走精简路径（直接发键 + Q_POST_SLEEP），如 StockIroi 未来变更需同步
        try:
            ret = super(StockIroi, self).click_ultimate(
                send_click=send_click, wait_if_no_cd=wait_if_no_cd
            )
            if ret:
                self.sleep(self.Q_POST_SLEEP, checks=self.SleepChecks.NONE)
            return ret
        finally:
            # [修改] 避免 _mouse_pressed 尚未初始化时触发 AttributeError
            if getattr(self, "_mouse_pressed", False):
                self.task.mouse_up()
            self._mouse_pressed = False

    def _wait_ultimate_unfreeze(self, start, click=False):
        self.task.mouse_down()
        self._mouse_pressed = True
        return super()._wait_ultimate_unfreeze(start=start, click=click)

    def _cast_e(self):
        if self.is_dead:
            return False
        start = self.clock.now()
        while True:
            self.refresh_frame()
            if self.skill_available():
                break
            if self.clock.now() - start >= self.E_WAIT_TIMEOUT:
                return False
            self.sleep(self.E_WAIT_POLL, checks=self.SleepChecks.COMBAT)
        wait_sound_idle(self, label="伊洛伊·E发键前", max_wait=0.1)
        log_before_click(self, "伊洛伊E", "skill")
        ok = self.click_skill(send_click=False, down_time=0.05)
        log_after_click(self, "伊洛伊E", "skill")
        return ok

    def _cast_q(self):
        if self.is_dead:
            return False
        for attempt in range(1, 3):
            self.refresh_frame()
            if not self.ultimate_available():
                return False
            wait_sound_idle(self, label=f"伊洛伊·Q{attempt}发键前", max_wait=0.1)
            log_before_click(self, "伊洛伊Q", "ultimate")
            ok = self.click_ultimate(send_click=False)
            log_after_click(self, "伊洛伊Q", "ultimate")
            self.last_ultimate_time = self.clock.now()
            if ok:
                return True
            self.sleep(0.1, checks=self.SleepChecks.NONE)
        return False

    def _cast_z(self):
        if self.is_dead:
            return False
        wait_sound_idle(self, label="伊洛伊·Z开始前", max_wait=0.1)
        try:
            with self.task.skip_sleep_checks() as skip:
                skip.sound_combat_context = True
                self.task.mouse_down()
                # 显式 COMBAT：长按蓄力期间若脱战应中断（finally 仍会执行 mouse_up）
                self.sleep(self.HEAVY_HOLD_DURATION, checks=self.SleepChecks.COMBAT)
        finally:
            self.task.mouse_up()
        self.sleep(0.05, checks=self.SleepChecks.NONE)
        return True

    def on_combat_end(self, chars):
        if getattr(self, "_mouse_pressed", False):
            try:
                self.task.mouse_up()
            except Exception:
                pass
            self._mouse_pressed = False
        super().on_combat_end(chars)

    def _stage_e_only(self):
        return self._cast_e()

    def _stage_e_q_z(self):
        e_ok = self._cast_e()
        if self.is_dead:
            return False
        if e_ok and self.E_TO_Q_SLEEP > 0:
            self.sleep(self.E_TO_Q_SLEEP, checks=self.SleepChecks.COMBAT)
        q_ok = self._cast_q()
        if q_ok:
            self.sleep(self.Q_TO_Z_SLEEP, checks=self.SleepChecks.NONE)
        else:
            self.logger.warning("[伊洛伊] Q 能量不足，跳过 Q 直接打重击 Z")
        return self._cast_z()

    def _stage_q_z(self):
        q_ok = self._cast_q()
        if q_ok:
            self.sleep(self.Q_TO_Z_SLEEP, checks=self.SleepChecks.NONE)
        else:
            self.logger.warning("[伊洛伊] Q 能量不足，跳过 Q 直接打重击 Z")
        return self._cast_z()

    def perform_entry(self):
        _bind_rotation_logger(self)
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        if self.is_dead:
            self._on_self_dead(rotation)
            return

        # 非本角色阶段：队列头是别人，等待切人，不推进队列
        if stage is None:
            self._handle_waiting_other_stage(rotation)
            return

        self._wait_switch_since = None
        self._wait_switch_first_at = None
        self._wait_retry_count = 0

        if not self._ensure_self_current_char(rotation, stage):
            return

        try:
            if stage == STAGE_OPEN_IROI_EQZ:
                ok = self._retry_block("伊洛伊E-Q-Z", self._stage_e_q_z, max_attempts=2)
            elif stage == STAGE_LOOP_IROI_E:
                ok = self._retry_block("伊洛伊E", self._stage_e_only, max_attempts=2)
            elif stage == STAGE_LOOP_IROI_QZ:
                ok = self._retry_block("伊洛伊Q-Z", self._stage_q_z, max_attempts=2)
            else:
                ok = True
            if not ok and not self.is_dead:
                self.logger.warning(
                    f"[伊洛伊] 阶段 {stage} 未完成，本轮不推进，等待下次切入"
                )
                return
        except Exception as e:
            err_name = type(e).__name__
            if err_name in ("TaskDisabledException", "NotInCombatException"):
                self._record_combat_end(err_name)
                raise
            self.logger.error(f"[{self.cn_name}异常] {err_name}: {e}")

        advance_rotation(self, rotation)

    def combat_plan(self):
        return self.plan(entry=self.perform_entry)
