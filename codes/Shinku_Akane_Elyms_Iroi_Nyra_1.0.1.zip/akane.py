import importlib.util
import sys
from pathlib import Path


def _bootstrap_team_module():
    key = "_shinku_wheelchair_team_module"
    cached = sys.modules.get(key)
    if cached is not None and hasattr(cached, "load_team_module"):
        return cached.load_team_module(__file__)
    team_path = Path(__file__).resolve().with_name("shinku.py")
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module.load_team_module(__file__)


_team = _bootstrap_team_module()
STAGE_OPEN_AKANE_Q1 = _team.STAGE_OPEN_AKANE_Q1
STAGE_OPEN_AKANE_Q2 = _team.STAGE_OPEN_AKANE_Q2
STAGE_LOOP_AKANE_EQ = _team.STAGE_LOOP_AKANE_EQ
STAGE_LOOP_AKANE_Q2 = _team.STAGE_LOOP_AKANE_Q2
WAIT_SWITCH_TIMEOUT = _team.WAIT_SWITCH_TIMEOUT
get_rotation = _team.get_rotation
advance_rotation = _team.advance_rotation
wait_sound_idle = _team.wait_sound_idle
RotationInput = _team.RotationInput
log_before_click = _team.log_before_click
log_after_click = _team.log_after_click
_bind_rotation_logger = _team._bind_rotation_logger


from src.char.Akane import Akane as StockAkane
from src.combat.planner import Planner, RoleProfile


class Akane(RotationInput, StockAkane):
    cn_name = "明音凛"
    en_name = "Akane"

    E_WAIT_TIMEOUT = 0.6
    E_TO_Q_SLEEP = 0.25
    E_WAIT_POLL = 0.05
    Q1_ANIMATION_WAIT = 0.5
    Q2_ENTRY_SETTLE = 0.1
    Q2_MIN_AFTER_Q1 = 3

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_policies(self):
        self.in_ult_start = self.clock.UNSET

    def _wait_ultimate_unfreeze(self, start, click=False):
        if getattr(self, "_is_q1", False):
            self.sleep(self.Q1_ANIMATION_WAIT, checks=self.SleepChecks.NONE)
            duration = self.clock.now() - start
            self.add_freeze_duration(start, duration)
            return duration
        return super()._wait_ultimate_unfreeze(start=start, click=click)

    def _cast_e(self):
        if self.is_dead:
            return False
        # 轮询等待 E 就绪（入场首帧未就绪 / 上轮 CD 差一点 / 发键被吞）
        start = self.clock.now()
        while True:
            self.refresh_frame()
            if self.skill_available():
                break
            if self.clock.now() - start >= self.E_WAIT_TIMEOUT:
                self.logger.warning(
                    f"[明音凛] E 等待 {self.E_WAIT_TIMEOUT}s 仍不可用，跳过 E（仍会放 Q1）"
                )
                return False
            # 使用 COMBAT：等待 E 期间若真脱战应立即抛出，交给 _retry_block 处理
            self.sleep(self.E_WAIT_POLL, checks=self.SleepChecks.COMBAT)

        wait_sound_idle(self, label="明音凛·E发键前", max_wait=0.1)
        log_before_click(self, "明音凛E", "skill")
        ok = self.click_skill(send_click=False, down_time=0.05)
        log_after_click(self, "明音凛E", "skill")
        return ok

    def _cast_q1(self):
        if self.is_dead:
            return False
        self.refresh_frame()
        if not self.ultimate_available():
            return False
        wait_sound_idle(self, label="明音凛·Q1发键前", max_wait=0.1)
        self._is_q1 = True
        try:
            log_before_click(self, "明音凛Q1", "ultimate")
            ok = self.click_ultimate(send_click=False)
            log_after_click(self, "明音凛Q1", "ultimate")
        finally:
            self._is_q1 = False
        if ok:
            self.in_ult_start = self.clock.now()
        return ok

    def _cast_q2(self):
        if self.is_dead:
            return False
        if (
            getattr(self, "in_ult_start", None) is not None
            and self.in_ult_start != self.clock.UNSET
        ):
            elapsed_since_q1 = self.clock.now() - self.in_ult_start
            remain = self.Q2_MIN_AFTER_Q1 - elapsed_since_q1
            if remain > 0:
                self.logger.info(
                    f"[明音凛] Q2 等待 Q1 满 {self.Q2_MIN_AFTER_Q1:.1f}s，还差 {remain:.2f}s"
                )
                self.sleep(remain, checks=self.SleepChecks.COMBAT)

        self.refresh_frame()
        if self.Q2_ENTRY_SETTLE > 0:
            self.sleep(self.Q2_ENTRY_SETTLE, checks=self.SleepChecks.NONE)
            self.refresh_frame()

        if not self.in_ult():
            self.logger.warning("[明音凛] Q2 时已不在华彩连段")
            return False
        if not self.ultimate_available():
            return False

        wait_sound_idle(self, label="明音凛·Q2发键前", max_wait=0.1)
        log_before_click(self, "明音凛Q2", "ultimate")
        ok = self.click_ultimate(send_click=False)
        log_after_click(self, "明音凛Q2", "ultimate")
        if ok:
            self.in_ult_start = self.clock.UNSET
        return ok

    def _stage_e_q1(self):
        e_ok = self._cast_e()
        if self.is_dead:
            return False
        self.refresh_frame()
        if not e_ok and not self.ultimate_available():
            self.logger.warning("[明音凛] E 未就绪且 Q 能量不足，跳过本段避免站场")
            return False
        if e_ok:
            self.sleep(self.E_TO_Q_SLEEP, checks=self.SleepChecks.COMBAT)
        q1_ok = self._cast_q1()
        if not e_ok and not q1_ok:
            self.logger.warning("[明音凛] E 与 Q1 均未生效，结束本段切人")
            return False
        return q1_ok or e_ok

    def perform_entry(self):
        _bind_rotation_logger(self)
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        if self.is_dead:
            self._on_self_dead(rotation)
            return

        # 非本角色阶段：队列头是别人，等待切人，不推进队列
        if stage is None:
            self._handle_waiting_other_stage(rotation)
            return

        self._wait_switch_since = None
        self._wait_switch_first_at = None
        self._wait_retry_count = 0

        if not self._ensure_self_current_char(rotation, stage):
            return

        try:
            if stage in (STAGE_OPEN_AKANE_Q1, STAGE_LOOP_AKANE_EQ):
                self._retry_block("明音凛E+Q1", self._stage_e_q1, max_attempts=1)
            elif stage in (STAGE_OPEN_AKANE_Q2, STAGE_LOOP_AKANE_Q2):
                self._retry_block(
                    "明音凛Q2",
                    self._cast_q2,
                    max_attempts=2,
                    not_in_combat_retry=False,
                )
        except Exception as e:
            err_name = type(e).__name__
            if err_name in ("TaskDisabledException", "NotInCombatException"):
                self._record_combat_end(err_name)
                raise
            self.logger.error(f"[{self.cn_name}异常] {err_name}: {e}")

        advance_rotation(self, rotation)

    def combat_plan(self):
        return self.plan(entry=self.perform_entry)
