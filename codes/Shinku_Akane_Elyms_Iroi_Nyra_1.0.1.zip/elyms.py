import importlib.util
import sys
from pathlib import Path


def _bootstrap_team_module():
    key = "_shinku_wheelchair_team_module"
    cached = sys.modules.get(key)
    if cached is not None and hasattr(cached, "load_team_module"):
        return cached.load_team_module(__file__)
    team_path = Path(__file__).resolve().with_name("shinku.py")
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module.load_team_module(__file__)


_team = _bootstrap_team_module()
STAGE_OPEN_ELYMS_EQ = _team.STAGE_OPEN_ELYMS_EQ
STAGE_LOOP_ELYMS_EQ = _team.STAGE_LOOP_ELYMS_EQ
WAIT_SWITCH_TIMEOUT = _team.WAIT_SWITCH_TIMEOUT
get_rotation = _team.get_rotation
advance_rotation = _team.advance_rotation
wait_sound_idle = _team.wait_sound_idle
RotationInput = _team.RotationInput
sound_action_stamp = _team.sound_action_stamp
sound_action_changed = _team.sound_action_changed
log_before_click = _team.log_before_click
log_after_click = _team.log_after_click
_bind_rotation_logger = _team._bind_rotation_logger

from src.char.Elyms import Elyms as StockElyms
from src.combat.planner import Planner, RoleProfile


class Elyms(RotationInput, StockElyms):
    cn_name = "曳尔沐"
    en_name = "Elyms"

    E1_WAIT_TIMEOUT = 0.6
    E2_WAIT_TIMEOUT = 2.5
    E3_WAIT_TIMEOUT = 6
    E_WAIT_POLL = 0.05
    E3_TO_Q_SLEEP = 0.3
    ULTIMATE_FREEZE_MAX = 1.5
    E2_TO_Q_ANIMATION_WAIT = 0.8
    Q_ANIMATION_WAIT = 1.5
    SKIP_A_AND_E3 = True

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def _wait_ultimate_unfreeze(self, start, click=False):
        self.sleep(self.Q_ANIMATION_WAIT, checks=self.SleepChecks.NONE)
        duration = self.clock.now() - start
        self.add_freeze_duration(start, min(duration, self.ULTIMATE_FREEZE_MAX))
        return duration

    def _check_special_ready(self):
        self.refresh_frame()
        return (
            False
            if self.is_dead
            else (self.skill_available() and self.is_special_skill())
        )

    def _wait_skill_ready(self, timeout=None):
        """等待普通 E 就绪（用于 E1）。超时返回 False。"""
        timeout = self.E1_WAIT_TIMEOUT if timeout is None else timeout
        start = self.clock.now()
        while True:
            if self.is_dead:
                return False
            self.refresh_frame()
            if self.skill_available():
                return True
            if self.clock.now() - start >= timeout:
                return False
            self.sleep(self.E_WAIT_POLL, checks=self.SleepChecks.NONE)

    def _wait_special(self, tag, timeout, with_attack=True):
        if self.is_dead:
            return False
        start = self.clock.now()
        stamp = sound_action_stamp()
        while self.clock.now() - start < timeout:
            if self.is_dead:
                return False
            if self._check_special_ready():
                return True
            if sound_action_changed(stamp):
                self.logger.info(f"[曳尔沐] {tag} 期间弹刀，放弃 {tag}")
                return False
            if with_attack:
                self.check_combat()
                self.click(interval=self.E_WAIT_POLL)
                if self.is_dead:
                    return False
            self.sleep(self.E_WAIT_POLL, checks=self.SleepChecks.NONE)
        return False

    def _cast_skill(self, label):
        wait_sound_idle(self, label=f"曳尔沐·{label}发键前", max_wait=0.1)
        log_before_click(self, f"曳尔沐{label}", "skill")
        ok = self.click_skill(send_click=False, down_time=0.05)
        log_after_click(self, f"曳尔沐{label}", "skill")
        return ok

    def _cast_e3_with_retry(self):
        if self._wait_special("E3", self.E3_WAIT_TIMEOUT, with_attack=True):
            if self._cast_skill("E3"):
                self.sleep(self.E_WAIT_POLL, checks=self.SleepChecks.NONE)
                self.refresh_frame()
                if not self._check_special_ready():
                    return True
        if self._check_special_ready():
            ok = self._cast_skill("E3补发")
            if ok:
                self.sleep(self.E_WAIT_POLL, checks=self.SleepChecks.NONE)
                self.refresh_frame()
                if not self._check_special_ready():
                    return True
            return ok
        return False

    def _cast_q(self):
        if self.is_dead or not self.ultimate_available():
            return False
        wait_sound_idle(self, label="曳尔沐·Q发键前", max_wait=0.1)
        log_before_click(self, "曳尔沐Q", "ultimate")
        ok = self.click_ultimate(send_click=False)
        log_after_click(self, "曳尔沐Q", "ultimate")
        return ok

    # ===== 延滞链补发：E1 / E2 / Q =====
    def _cast_e1_with_retry(self, attempts=2):
        """E1 补发：等待就绪 → 发键 → 短刷帧校验是否进入 CD，未进入则重试。"""
        for i in range(attempts):
            if self.is_dead:
                return False
            if not self._wait_skill_ready():
                if i < attempts - 1:
                    self.logger.warning(
                        f"[曳尔沐] E1 第 {i+1} 次等待就绪超时，等 {self.E_WAIT_POLL}s 重试"
                    )
                    self.sleep(self.E_WAIT_POLL, checks=self.SleepChecks.NONE)
                continue
            ok = self._cast_skill("E1")
            if ok:
                self.sleep(self.E_WAIT_POLL, checks=self.SleepChecks.NONE)
                self.refresh_frame()
                if not self.skill_available():
                    return True
            if i < attempts - 1:
                self.logger.warning(
                    f"[曳尔沐] E1 第 {i+1} 次未生效（发键返回={ok}），等 {self.E_WAIT_POLL}s 重试"
                )
                self.sleep(self.E_WAIT_POLL, checks=self.SleepChecks.NONE)
        self.logger.warning(f"[曳尔沐] E1 补发 {attempts} 次仍未生效")
        return False

    def _cast_e2_with_retry(self, attempts=2, with_attack=False):
        """E2 补发：等待 special 就绪 → 发键 → 短刷帧校验 special 是否消失，未消失则重试。"""
        for i in range(attempts):
            if self.is_dead:
                return False
            if not self._wait_special(
                "E2", self.E2_WAIT_TIMEOUT, with_attack=with_attack
            ):
                # special 一直不就绪，重试也等不到，直接放弃
                self.logger.warning(
                    f"[曳尔沐] E2 第 {i+1} 次等待 special 超时（{self.E2_WAIT_TIMEOUT}s），放弃 E2"
                )
                return False
            ok = self._cast_skill("E2")
            if ok:
                self.sleep(self.E_WAIT_POLL, checks=self.SleepChecks.NONE)
                self.refresh_frame()
                if not self._check_special_ready():
                    return True
            if i < attempts - 1:
                self.logger.warning(
                    f"[曳尔沐] E2 第 {i+1} 次未生效（发键返回={ok}），等 {self.E_WAIT_POLL}s 重试"
                )
                self.sleep(self.E_WAIT_POLL, checks=self.SleepChecks.NONE)
        self.logger.warning(f"[曳尔沐] E2 补发 {attempts} 次仍未生效")
        return False

    def _cast_q_with_retry(self, attempts=2):
        """Q 补发：click_ultimate 返回 False 时短暂等待重试。"""
        for i in range(attempts):
            if self.is_dead:
                return False
            self.refresh_frame()
            if not self.ultimate_available():
                return False
            ok = self._cast_q()
            if ok:
                return True
            if i < attempts - 1:
                self.logger.warning(
                    f"[曳尔沐] Q 第 {i+1} 次发键失败，等 {self.E_WAIT_POLL}s 重试"
                )
                self.sleep(self.E_WAIT_POLL, checks=self.SleepChecks.NONE)
        self.logger.warning(f"[曳尔沐] Q 补发 {attempts} 次仍未生效")
        return False

    def _stage_intro_path(self):
        if self.SKIP_A_AND_E3:
            self._cast_e1_with_retry()
            ok = self._cast_q_with_retry()
            if ok:
                self.sleep(0.15, checks=self.SleepChecks.NONE)
            return ok

        self._cast_e1_with_retry()
        if self._cast_e3_with_retry():
            self.sleep(self.E3_TO_Q_SLEEP, checks=self.SleepChecks.NONE)
        ok = self._cast_q_with_retry()
        if ok:
            self.sleep(0.15, checks=self.SleepChecks.NONE)
        return ok

    def _stage_normal_path(self):
        if self.SKIP_A_AND_E3:
            self._cast_e1_with_retry()
            e2_ok = self._cast_e2_with_retry(with_attack=False)
            if e2_ok and self.E2_TO_Q_ANIMATION_WAIT > 0:
                self.logger.info(
                    f"[曳尔沐] E2 完成，等待过场动画 {self.E2_TO_Q_ANIMATION_WAIT:.2f}s"
                )
                self.sleep(self.E2_TO_Q_ANIMATION_WAIT, checks=self.SleepChecks.NONE)
            return self._cast_q_with_retry()

        self._cast_e1_with_retry()
        self._cast_e2_with_retry(with_attack=True)
        if self._cast_e3_with_retry():
            self.sleep(self.E3_TO_Q_SLEEP, checks=self.SleepChecks.COMBAT)
        return self._cast_q_with_retry()

    def perform_entry(self):
        _bind_rotation_logger(self)
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        if self.is_dead:
            self._on_self_dead(rotation)
            return

        # 非本角色阶段：队列头是别人，等待切人，不推进队列
        if stage is None:
            self._handle_waiting_other_stage(rotation)
            return

        self._wait_switch_since = None
        self._wait_switch_first_at = None
        self._wait_retry_count = 0

        if not self._ensure_self_current_char(rotation, stage):
            return

        try:
            if stage in (STAGE_OPEN_ELYMS_EQ, STAGE_LOOP_ELYMS_EQ):
                if self.has_intro:
                    self._retry_block(
                        "曳尔沐援护", self._stage_intro_path, max_attempts=2
                    )
                else:
                    self._retry_block(
                        "曳尔沐普通", self._stage_normal_path, max_attempts=2
                    )
        except Exception as e:
            err_name = type(e).__name__
            if err_name in ("TaskDisabledException", "NotInCombatException"):
                self._record_combat_end(err_name)
                raise
            self.logger.error(f"[{self.cn_name}异常] {err_name}: {e}")

        advance_rotation(self, rotation)

    def combat_plan(self):
        return self.plan(entry=self.perform_entry)
