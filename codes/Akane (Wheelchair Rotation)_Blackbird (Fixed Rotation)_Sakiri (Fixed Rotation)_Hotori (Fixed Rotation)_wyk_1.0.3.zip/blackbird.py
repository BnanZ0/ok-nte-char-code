"""黑羽的固定轴执行器外壳（RotationPuppet 定义在主脚本 akane_mingyin.py 里）。"""

from src.char.Blackbird import Blackbird

from .akane_mingyin import RotationPuppet


class BlackbirdPuppet(RotationPuppet, Blackbird):
    """黑羽: 只在明音脚本的固定步骤里被切上场按键, 不自己开一段大。"""

    cn_name = "黑羽（固定轴）"
    en_name = "Blackbird (Fixed Rotation)"
