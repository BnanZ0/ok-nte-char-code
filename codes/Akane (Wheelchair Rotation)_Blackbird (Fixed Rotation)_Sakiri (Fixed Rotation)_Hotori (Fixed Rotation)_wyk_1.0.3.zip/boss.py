"""浔(老板娘)的固定轴执行器外壳（RotationPuppet 定义在主脚本 akane_mingyin.py 里）。"""

from src.char.Hotori import Hotori

from .akane_mingyin import RotationPuppet


class HotoriPuppet(RotationPuppet, Hotori):
    """浔: 只按明音脚本发的 Q/E, 不自己开记录窗口和大招。"""

    cn_name = "浔（固定轴）"
    en_name = "Hotori (Fixed Rotation)"
