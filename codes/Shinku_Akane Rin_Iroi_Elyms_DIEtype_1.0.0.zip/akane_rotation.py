from src.char.Akane import Akane
from src.combat.planner import Planner, RoleProfile


class RotationInput:
    """Keep native switch detection while suppressing incidental attack input."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.planner_handles_arc = True

    def wait_intro(self, time_out=-1, click=False):
        return super().wait_intro(time_out=time_out, click=False)

    def _wait_ultimate_unfreeze(self, start, click=False):
        return super()._wait_ultimate_unfreeze(start=start, click=False)

    def click_with_interval(self, interval=0.1):
        # v1.5.3 uses this for the keep-current fallback.
        return False

    def switch_next_char(self, post_action=None, free_intro=False):
        task = self.task
        original_click = task.click
        had_override = "click" in vars(task)

        def switch_click(*args, **kwargs):
            if kwargs.get("action_name") == "switch_char_click":
                return False
            return original_click(*args, **kwargs)

        def after_switch(target, has_intro):
            # The host also passes the full-gauge flag for incompatible pairs.
            target.has_intro = has_intro and task.can_element_react(self, target)
            if post_action:
                post_action(target, target.has_intro)

        task.click = switch_click
        try:
            return super().switch_next_char(post_action=after_switch, free_intro=free_intro)
        finally:
            if had_override:
                task.click = original_click
            else:
                del task.click


class RotationAkane(RotationInput, Akane):
    cn_name = "明音凛"
    en_name = "Akane Rin"

    def combat_policies(self):
        self.delay_seeded = False
        self.mark_cast_at = self.clock.UNSET
        self.in_ult_start = self.clock.UNSET

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self):
        return self.plan()

    def opening_mark(self):
        if self.has_intro:
            self.delay_seeded = True
            self.logger.info("Rotation 0.4: opening Delay entry via Akane")
        return self.refresh_mark()

    def refresh_mark(self):
        if not self.cast_mark_e():
            return False
        was_in_ult = self.in_ult()
        if self.ultimate_available() and self.click_ultimate(send_click=False):
            self.in_ult_start = self.clock.UNSET if was_in_ult else self.last_ultimate_time
        return True

    def cast_mark_e(self):
        if not self.skill_available() or self.find_skill_2():
            self.logger.info("Rotation 0.4: Akane mark E unavailable, moving on")
            return False
        if not self.click_skill(down_time=0.05, send_click=False):
            return False
        self.mark_cast_at = self.last_skill_time
        self.logger.info("Rotation 0.4: Akane mark E cast")
        return True
