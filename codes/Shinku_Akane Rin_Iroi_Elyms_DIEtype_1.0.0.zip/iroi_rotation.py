from src.char.Iroi import Iroi
from src.combat.planner import Planner, RoleProfile

from .akane_rotation import RotationInput


class RotationIroi(RotationInput, Iroi):
    cn_name = "伊洛伊"
    en_name = "Iroi"
    CANNON_RELEASE_GAP = 0.08
    CANNON_HANDOFF_GAP = 0.30

    def combat_policies(self):
        self.pre_mark_full = False
        self.start_support_pass()

    def start_support_pass(self):
        self.e_cast_in_pass = False
        self.q_cast_in_pass = False
        self.cannon_input_at = self.clock.UNSET

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self):
        return self.plan()

    def transit(self):
        self.logger.info("Rotation 0.4: Iroi transit, no skills")
        return True

    def early_support(self):
        self.log_reaction_entry()
        # Use E early only when it can help charge the reserved late Q.
        if not self.ultimate_available() and self.try_e():
            self.logger.info("Rotation 0.4: Iroi early E for energy; Q reserved")
        self.pre_mark_full = self.is_cycle_full()
        return True

    def late_support(self):
        self.log_reaction_entry()
        used_e = self.try_e()
        if used_e:
            self.logger.info("Rotation 0.4: Iroi late E before Shinku")
        self.cast_support_q(after_e=used_e)
        return True

    def cast_support_q(self, *, after_e=False):
        if self.q_cast_in_pass:
            return False
        if after_e:
            self.sleep(0.8)
        with self.task.skip_sleep_checks() as skip:
            skip.sound_combat_context = True
            if not self.ultimate_available() or not self.click_ultimate(send_click=False):
                self.logger.info("Rotation 0.4: Iroi late Q unavailable or unconfirmed")
                return False
            self.q_cast_in_pass = True
            # The inherited Q releases the held attack before returning.
            self.sleep(self.CANNON_RELEASE_GAP, checks=self.SleepChecks.COMBAT)
            self.click(action_name="iroi_cannon_follow_up")
            self.cannon_input_at = self.clock.now()
            self.sleep(self.CANNON_HANDOFF_GAP, checks=self.SleepChecks.COMBAT)
        self.logger.info("Rotation 0.4: Iroi Q and cannon follow-up input sent; hand off to Shinku")
        return True

    def log_reaction_entry(self):
        if self.has_intro:
            self.logger.info("Rotation 0.4: Iroi reaction entry")

    def try_e(self):
        if self.e_cast_in_pass:
            return False
        self.e_cast_in_pass = self.skill_available() and self.click_skill(send_click=False)
        return self.e_cast_in_pass
