from src.char.Shinku import Shinku
from src.combat.planner import FieldClaim, Planner, RoleProfile

from .akane_rotation import RotationAkane, RotationInput
from .elyms_rotation import RotationElyms
from .iroi_rotation import RotationIroi


class RotationShinku(RotationInput, Shinku):
    cn_name = "真红"
    en_name = "Shinku"

    SUPPORT_ROUTE_TIMEOUT = 35

    def combat_policies(self):
        self.opened = False
        self.setup_started_at = self.clock.UNSET
        self.setup_ready = False
        self.repair_attempted = False
        self.hold_field = False

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.MAIN_DPS, combat_start_priority=100, max_field_time=0
        )

    def combat_plan(self):
        plan = self.plan(entry=self.perform_entry)
        if self.rotation_members() is not None:
            plan.add(FieldClaim.strict(reason="recover rotation on Shinku"))
        return plan

    def rotation_members(self):
        team = self.get_teammate_by_class(RotationAkane, RotationElyms, RotationIroi)
        return team if all(member is not None and not member.is_dead for member in team) else None

    def perform_entry(self):
        self.hold_field = False
        team = self.rotation_members()
        if team is None:
            if self.ultimate_available() and self.cast_burst():
                self.hold_field = True
            else:
                self.wait_on_shinku()
            return

        akane, elyms, iroi = team
        full = self.is_cycle_full()
        q_ready = self.ultimate_available()

        if self.setup_ready:
            if q_ready:
                if self.repair_missing_support(team, full=full):
                    return
                self.log_burst_timing(akane, elyms, iroi)
                if self.cast_burst():
                    self.setup_ready = False
                    if self.is_cycle_full():
                        self.start_setup(team, opening=not akane.delay_seeded)
                        return
                    self.hold_field = True
                    return
            self.wait_on_shinku()
            return

        if not self.opened or q_ready or full:
            opening = not self.opened or (not akane.delay_seeded and full)
            if opening and not full:
                self.click_skill(send_click=False)
            self.start_setup(team, opening=opening)
            return

        self.wait_on_shinku()
        if self.is_cycle_full():
            self.hold_field = False
            self.start_setup(team, opening=not akane.delay_seeded)

    def start_setup(self, team, *, opening):
        akane, _, iroi = team
        first_pass = not self.opened
        self.opened = True
        self.setup_started_at = self.clock.now()
        self.setup_ready = False
        self.repair_attempted = False
        iroi.start_support_pass()
        if opening:
            steps = [
                Planner.Route.reaction(self, akane, optional=True),
                Planner.Route.optional(akane.opening_mark),
            ]
            reason = "rotation 0.4 opening: Shinku to Akane"
        else:
            steps = [
                Planner.Route.reaction(self, iroi, optional=True),
                Planner.Route.optional(iroi.early_support),
                Planner.Route.optional(akane.refresh_mark),
            ]
            reason = "rotation 0.4 steady: Shinku to Iroi to Akane"

        route = self.combat_context.request_route(
            steps, reason=reason, timeout=self.SUPPORT_ROUTE_TIMEOUT
        )
        route.on_fulfilled(lambda: self.finish_setup(team, first_pass=first_pass))
        route.on_failed(self.accept_partial_setup)
        route.on_expired(self.accept_partial_setup)

    def finish_setup(self, team, *, first_pass):
        akane, elyms, iroi = team
        steps = []
        if (
            akane.is_current_char
            and akane.delay_seeded
            and not iroi.pre_mark_full
            and akane.is_cycle_full()
        ):
            # Yellow -> White would spend the full gauge on a second Delay.
            steps.append(Planner.Route.optional(iroi.transit))
        steps.extend(
            [
                Planner.Route.optional(elyms.prepare_opening if first_pass else elyms.prepare),
                Planner.Route.reaction(elyms, iroi, optional=True),
                Planner.Route.optional(iroi.late_support),
                self.accept_handoff,
            ]
        )
        route = self.combat_context.request_route(
            steps,
            reason="rotation 0.4 finish: Elyms to Iroi to Shinku",
            timeout=self.SUPPORT_ROUTE_TIMEOUT,
        )
        route.on_failed(self.accept_partial_setup)
        route.on_expired(self.accept_partial_setup)

    def accept_handoff(self):
        self.setup_ready = True
        self.logger.info("Rotation 0.4: support handoff; hold for Shinku Q")
        return True

    def accept_partial_setup(self):
        self.setup_ready = True
        self.logger.info("Rotation 0.4: support route interrupted; keep completed casts")

    def repair_missing_support(self, team, *, full):
        if self.repair_attempted:
            return False
        akane, elyms, iroi = team
        if iroi.q_cast_in_pass:
            # Iroi's cannon gets a continuous Shinku window after the final Q.
            return False
        mark_missing = akane.mark_cast_at < self.setup_started_at and akane.skill_available()
        link_missing = elyms.link_cast_at < self.setup_started_at and elyms.link_q_repair_ready()
        iroi_missing = not iroi.q_cast_in_pass and iroi.ultimate_available()
        if not (mark_missing or link_missing or iroi_missing):
            return False

        self.repair_attempted = True
        steps = []
        actions = []
        if mark_missing and full:
            # Spend a full gauge on Blossom before moving to Akane for E.
            steps.append(Planner.Route.reaction(self, iroi, optional=True))
        if mark_missing:
            steps.append(Planner.Route.optional(akane.cast_mark_e))
            actions.append("Akane E")
        if link_missing:
            steps.append(Planner.Route.optional(elyms.repair_link_q))
            actions.append("Elyms Q")
        if iroi_missing:
            if link_missing or not mark_missing:
                source = elyms if link_missing else self
                steps.append(Planner.Route.reaction(source, iroi, optional=True))
            steps.append(Planner.Route.optional(iroi.cast_support_q))
            actions.append("Iroi Q")
        steps.append(self.accept_handoff)
        route = self.combat_context.request_route(
            steps,
            reason="rotation 0.4 repair: " + ", ".join(actions),
            timeout=self.SUPPORT_ROUTE_TIMEOUT,
        )
        route.on_failed(self.accept_partial_setup)
        route.on_expired(self.accept_partial_setup)
        return True

    def cast_burst(self):
        self.click_skill(send_click=False)
        if not self.click_ultimate(send_click=False):
            return False
        self.perform_in_ult()
        return True

    def log_burst_timing(self, akane, elyms, iroi):
        def age(stamp):
            if not stamp:
                return "unseen"
            return f"{self.time_elapsed_accounting_for_freeze(stamp):.1f}s"

        self.logger.info(
            f"Rotation 0.4: Shinku burst; Akane E age={age(akane.mark_cast_at)}, "
            f"Elyms Q age={age(elyms.link_cast_at)}, "
            f"Iroi cannon input age={age(iroi.cannon_input_at)} (input/cast timestamps)"
        )

    def wait_on_shinku(self):
        self.hold_field = True
        if self.skill_available():
            self.click_skill(send_click=False)
        self.sleep(0.2)

    def switch_next_char(self, post_action=None, free_intro=False):
        if self.hold_field:
            self.has_intro = False
            return
        return super().switch_next_char(post_action=post_action, free_intro=free_intro)

    def on_combat_end(self, chars):
        pass
