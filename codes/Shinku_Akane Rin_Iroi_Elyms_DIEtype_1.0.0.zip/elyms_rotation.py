from src.char.Elyms import Elyms
from src.combat.planner import Planner, RoleProfile

from .akane_rotation import RotationAkane, RotationInput


class RotationElyms(RotationInput, Elyms):
    cn_name = "曳尔沐"
    en_name = "Elyms"

    ENHANCED_E_BUDGET = 4.0
    SIGNAL_UI_BUDGET = 0.7
    Q_READY_BUDGET = 4.0
    MIN_LINK_Q_STAGE = 2

    def combat_policies(self):
        self.link_cast_at = self.clock.UNSET
        self.last_link_signal_stage = None

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self):
        return self.plan()

    def prepare_opening(self):
        return self.prepare(opening=True)

    def prepare(self, *, opening=False):
        (akane,) = self.get_teammate_by_class(RotationAkane)
        if akane is not None and not akane.delay_seeded and self.has_intro:
            akane.delay_seeded = True
            self.logger.info("Rotation 0.4: opening Delay entry via Elyms")

        stage = self.get_stage()
        enhanced_at_entry = self.is_special_skill()
        if not enhanced_at_entry and self.skill_available() and self.click_skill(send_click=False):
            self.logger.info(f"Rotation 0.4: Elyms first E cast, entry signal stage={stage}")

        # Opening may use EQ. Steady state must finish the enhanced-E step before Q.
        enhanced_cast = False
        if enhanced_at_entry or not opening or not self.link_q_ready():
            enhanced_cast = self.cast_enhanced_e()

        if self.task.combat_session.use_ultimate and not self.link_q_ready():
            can_reach_medium = enhanced_cast or self.get_stage() >= self.MIN_LINK_Q_STAGE
            budget = self.Q_READY_BUDGET if can_reach_medium else self.SIGNAL_UI_BUDGET
            self.task.wait_until(self.link_q_ready, time_out=budget)
        return self.cast_link_q()

    def cast_enhanced_e(self):
        if not self.enhanced_e_ready():
            ready = self.task.wait_until(
                self.enhanced_e_ready,
                post_action=self.attack_until_enhanced,
                time_out=self.ENHANCED_E_BUDGET,
            )
            if not ready:
                self.logger.info(
                    f"Rotation 0.4: Elyms enhanced E timed out, signal stage={self.get_stage()}"
                )
                return False
        if not self.click_skill(send_click=False):
            return False
        self.logger.info(f"Rotation 0.4: Elyms enhanced E cast, signal stage={self.get_stage()}")
        return True

    def attack_until_enhanced(self):
        if not self.is_special_skill():
            self.click()

    def link_q_ready(self):
        return self.ultimate_available() and self.get_stage() >= self.MIN_LINK_Q_STAGE

    def link_q_repair_ready(self):
        stage = self.last_link_signal_stage
        return self.ultimate_available() and (
            stage is None or stage >= self.MIN_LINK_Q_STAGE or self.skill_available()
        )

    def repair_link_q(self):
        if self.get_stage() >= self.MIN_LINK_Q_STAGE:
            return self.cast_link_q()
        return self.prepare()

    def cast_link_q(self):
        stage = self.get_stage()
        self.last_link_signal_stage = stage
        if not self.task.combat_session.use_ultimate:
            reason = "ultimate disabled in task"
        elif not self.ultimate_available():
            reason = (
                "cooldown detected"
                if self.has_cd("ultimate")
                else "HUD did not recognize Q as ready"
            )
        elif stage < self.MIN_LINK_Q_STAGE:
            reason = "Q ready, low signal" if stage == 1 else "Q ready, signal unrecognized"
        elif self.click_ultimate(send_click=False):
            self.link_cast_at = self.last_ultimate_time
            self.logger.info(f"Rotation 0.4: Elyms Q cast, signal stage={stage}")
            return True
        else:
            reason = "Q appeared ready but cast was not acknowledged"

        self.logger.info(f"Rotation 0.4: Elyms Q skipped, signal stage={stage}, {reason}")
        return False

    def enhanced_e_ready(self):
        return self.skill_available() and self.is_special_skill()
