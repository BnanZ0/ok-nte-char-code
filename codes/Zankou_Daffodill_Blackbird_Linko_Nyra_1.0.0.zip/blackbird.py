import sys


def _load_team_module():
    import importlib.util
    from pathlib import Path

    key = "_zankou_wheelchair_team_module"
    team_path = Path(__file__).resolve().with_name("zankou.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_OPEN_BLACKBIRD_E_Q1 = _team.STAGE_OPEN_BLACKBIRD_E_Q1
STAGE_OPEN_BLACKBIRD_Q2 = _team.STAGE_OPEN_BLACKBIRD_Q2
STAGE_LOOP_BLACKBIRD_E_Q1 = _team.STAGE_LOOP_BLACKBIRD_E_Q1
STAGE_LOOP_BLACKBIRD_Q2 = _team.STAGE_LOOP_BLACKBIRD_Q2
get_rotation = _team.get_rotation
advance_rotation = _team.advance_rotation
diag_sleep = _team.diag_sleep
diag_read_q = _team.diag_read_q
send_ultimate_with_diag = _team.send_ultimate_with_diag
wait_sound_idle = _team.wait_sound_idle
sound_action_stamp = _team.sound_action_stamp
sound_action_changed = _team.sound_action_changed

from src.char.BaseChar import BaseChar
from src.combat.planner import Planner, RoleProfile


class Blackbird(BaseChar):
    cn_name = "黑羽（轮椅轴）"
    en_name = "Blackbird (Wheelchair)"
    element = BaseChar.ElementType.BLUE

    INTRO_WAIT = 0.1
    Q1_POST_TIMEOUT = 4
    Q1_POST_SEND_SLEEP = 0.1
    Q2_POST_TIMEOUT = 3.5
    Q2_POST_SEND_SLEEP = 0.1
    Q_CHARGE_TIMEOUT = 5
    CHARGE_ATTACK_INTERVAL = 0.05
    HEAVY_ATTACK_HOLD = 0.8
    HEAVY_POST_SLEEP = 0.1
    MAX_STAGE_ATTEMPTS = 3
    STAGE_RETRY_SLEEP = 0.2

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.planner_handles_arc = True

    def send_skill_key(self, after_sleep=0, interval=-1, down_time=0.01, action_name=None, **_):
        wait_sound_idle(self, label="黑羽·E发键")
        return super().send_skill_key(
            after_sleep=after_sleep, interval=interval, down_time=down_time, action_name=action_name
        )

    def send_ultimate_key(self, after_sleep=0, interval=-1, down_time=0.01, action_name=None, **_):
        wait_sound_idle(self, label="黑羽·Q发键")
        return super().send_ultimate_key(
            after_sleep=after_sleep, interval=interval, down_time=down_time, action_name=action_name
        )

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUB_DPS,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def _ultimate_ready(self):
        value = self.ultimate_available()
        return bool(value) if value is not None else False

    def _retry_block(self, name, block_func, max_attempts=1, not_in_combat_retry=True):
        not_in_combat_retried = False
        for attempt in range(max_attempts + 1):
            if attempt > 0:
                self.logger.warning(f"[{name}] 第 {attempt} 次重试")
                if (
                    not self.is_current_char
                    or getattr(self.task, "combat_detect_uncertain", False)
                ):
                    self.logger.info(
                        f"[{name}] 重试前等待状态落定"
                        f"（is_current_char={self.is_current_char}）"
                    )
                    diag_sleep(self, f"{name}重试前(COMBAT)", 0.1, checks=self.SleepChecks.COMBAT)
                else:
                    diag_sleep(self, f"{name}重试前(NONE)", 0.15, checks=self.SleepChecks.NONE)
            if self.is_dead:
                self.logger.warning(f"[{name}] 角色阵亡，终止")
                return False
            try:
                if block_func():
                    return True
            except Exception as e:
                err_name = type(e).__name__
                if err_name == "TaskDisabledException":
                    raise
                if err_name == "NotInCombatException":
                    if not not_in_combat_retry:
                        self.logger.warning(f"[{name}] 脱战（快速失败，不重试），直接抛出: {e}")
                        raise
                    if not_in_combat_retried:
                        self.logger.warning(f"[{name}] 连续脱战，终止（NotInCombatException）")
                        raise
                    not_in_combat_retried = True
                    self.logger.warning(f"[{name}] 瞬时脱战，允许重试一次: {e}")
                else:
                    self.logger.warning(f"[{name}] 执行异常（{err_name}），准备重试: {e}")
        if not_in_combat_retried:
            self.logger.error(f"[{name}] 重试用尽且期间发生过脱战，re-raise")
            self.task.raise_not_in_combat(f"{name} 重试用尽且期间发生过脱战")
        return False

    def wait_intro(self, time_out=-1, click=True):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)

        if stage in (STAGE_LOOP_BLACKBIRD_E_Q1, STAGE_LOOP_BLACKBIRD_Q2):
            self.logger.info(f"[黑羽] 循环轴入场({stage})，跳过 INTRO_WAIT，直接读 Q 状态")
            return

        if not self.has_intro:
            return
        if self.INTRO_WAIT > 0:
            self.logger.info(f"[砍量] 黑羽INTRO_WAIT 2.00→{self.INTRO_WAIT:.2f}s")
            diag_sleep(self, "黑羽援护入场", self.INTRO_WAIT)
        else:
            self.logger.info("[砍量] 黑羽INTRO_WAIT=0，跳过")

    def _charge_for_q(self):
        self.logger.info(
            f"[黑羽] 循环轴 Q 不满，开始攒能（上限 {self.Q_CHARGE_TIMEOUT}s）"
        )
        start = self.clock.now()
        attacks = 0
        stamp = sound_action_stamp()
        while True:
            if self.is_dead:
                return False
            if self._ultimate_ready():
                try:
                    self.task.next_frame()
                except Exception:
                    pass
                if self._ultimate_ready():
                    self.logger.info(
                        f"[黑羽] 攒能成功（双确认，普攻 {attacks} 次，"
                        f"耗时 {self.clock.now() - start:.2f}s）"
                    )
                    return True
                self.logger.info("[黑羽] 攒能临界态：双确认失败，继续攒能")
            if self.clock.now() - start > self.Q_CHARGE_TIMEOUT:
                self.logger.warning(
                    f"[黑羽] 攒能 {self.Q_CHARGE_TIMEOUT}s 超时（普攻 {attacks} 次），强制放弃"
                )
                return False
            if sound_action_changed(stamp):
                self.logger.info("[黑羽] 攒能检测到声音打断，补一次普攻保持段数")
                self.click(interval=self.CHARGE_ATTACK_INTERVAL)
                stamp = sound_action_stamp()
                continue
            self.click(interval=self.CHARGE_ATTACK_INTERVAL)
            stamp = sound_action_stamp()
            attacks += 1

    def _heavy_transition(self, tag):
        if self.is_dead:
            return
        if self.HEAVY_ATTACK_HOLD > 0:
            self.heavy_attack(self.HEAVY_ATTACK_HOLD)
        if self.HEAVY_POST_SLEEP > 0:
            diag_sleep(self, f"黑羽{tag}后重击缓冲", self.HEAVY_POST_SLEEP)

    def _block_e_q1(self, is_loop=False):
        if self.is_dead:
            return False

        if is_loop:
            self.logger.info("[黑羽] 循环轴进场，next_frame 刷新一帧后读 Q 状态")
            self.task.next_frame()
            if not self._ultimate_ready():
                self.logger.info("[黑羽] 循环轴入场 Q 不满，进入攒能")
                self._charge_for_q()
            else:
                self.logger.info("[黑羽] 循环轴入场 Q 已满，直接 E-Q1")

        e_start = self.clock.now()
        e_ok = self.click_skill(down_time=0.05)
        e_actual = self.clock.now() - e_start
        self.logger.info(f"[诊断·黑羽E] click_skill 返回={e_ok} 耗时={e_actual:.2f}s")

        if self.is_dead:
            return False

        if self._ultimate_ready():
            send_ultimate_with_diag(
                self, "黑羽Q1", self.Q1_POST_TIMEOUT, self.Q1_POST_SEND_SLEEP
            )
            self._heavy_transition("Q1")
        else:
            self.logger.warning("[黑羽] Q1 能量不足，跳过 Q1 直接切走")
        return not self.is_dead

    def _block_q2(self):
        if self.is_dead:
            return False

        self.logger.info("[黑羽] Q2 释放前 next_frame 刷新 UI 状态")
        self.task.next_frame()
        diag_sleep(self, "黑羽Q2前稳定", 0.1)

        if not self._ultimate_ready():
            self.logger.warning(
                "[黑羽] Q2 能量不足，跳过本次爆发（不视为阶段失败）"
            )
            return True

        send_ultimate_with_diag(
            self, "黑羽Q2", self.Q2_POST_TIMEOUT, self.Q2_POST_SEND_SLEEP, retry=True, max_attempts=3
        )
        self._heavy_transition("Q2")
        return True

    def combat_plan(self):
        rotation = get_rotation(self.task)

        def entry():
            stage = rotation.stage_for(self)
            self.logger.info(f"[黑羽入场] 阶段={stage}")
            if self.is_dead:
                self.logger.warning("[黑羽] 阵亡，重置轴到启动轴")
                rotation.reset()
                return

            for attempt in range(1, self.MAX_STAGE_ATTEMPTS + 1):
                if self.is_dead:
                    self.logger.warning("[黑羽] 角色阵亡，中断")
                    rotation.reset()
                    return
                try:
                    if stage == STAGE_OPEN_BLACKBIRD_E_Q1:
                        if attempt == 1:
                            self.logger.info("[黑羽] E-Q1（启动轴）")
                        ok = self._retry_block(
                            "黑羽E-Q1", lambda: self._block_e_q1(False), 0
                        )
                    elif stage == STAGE_LOOP_BLACKBIRD_E_Q1:
                        if attempt == 1:
                            self.logger.info("[黑羽] E-Q1（循环轴）")
                        ok = self._retry_block(
                            "黑羽E-Q1", lambda: self._block_e_q1(True), 0
                        )
                    elif stage in (STAGE_OPEN_BLACKBIRD_Q2, STAGE_LOOP_BLACKBIRD_Q2):
                        if attempt == 1:
                            self.logger.info("[黑羽] Q2")
                        ok = self._retry_block("黑羽Q2", self._block_q2, 0)
                    else:
                        self.logger.warning(f"[黑羽异常] 阶段={stage}，直接切人")
                        advance_rotation(self, rotation)
                        return
                except Exception as e:
                    err_name = type(e).__name__
                    if err_name == "TaskDisabledException":
                        raise
                    if err_name == "NotInCombatException":
                        self.logger.warning("[黑羽] 脱战，向外抛出")
                        raise
                    self.logger.error(f"[黑羽异常] {e}")
                    ok = False

                if ok:
                    if self.is_dead:
                        self.logger.warning("[黑羽] 完成后阵亡，重置轴")
                        rotation.reset()
                        return
                    advance_rotation(self, rotation)
                    return

                self.logger.warning(
                    f"[黑羽] 阶段 {stage} 第 {attempt}/{self.MAX_STAGE_ATTEMPTS} 次失败"
                )
                if attempt < self.MAX_STAGE_ATTEMPTS:
                    diag_sleep(self, "黑羽阶段重试前", self.STAGE_RETRY_SLEEP, checks=self.SleepChecks.COMBAT)

            self.logger.error(
                f"[黑羽] 阶段 {stage} 达到最大重试次数，重置轴避免死锁"
            )
            rotation.reset()

        return self.plan(entry=entry)