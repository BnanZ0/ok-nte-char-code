import sys


def _load_team_module():
    import importlib.util
    from pathlib import Path

    key = "_zankou_wheelchair_team_module"
    team_path = Path(__file__).resolve().with_name("zankou.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_OPEN_DAFFODILL_QE = _team.STAGE_OPEN_DAFFODILL_QE
STAGE_OPEN_DAFFODILL_R = _team.STAGE_OPEN_DAFFODILL_R
STAGE_LOOP_DAFFODILL_QRE = _team.STAGE_LOOP_DAFFODILL_QRE
get_rotation = _team.get_rotation
advance_rotation = _team.advance_rotation
diag_sleep = _team.diag_sleep
diag_read_q = _team.diag_read_q
wait_sound_idle = _team.wait_sound_idle
sound_action_stamp = _team.sound_action_stamp
sound_action_changed = _team.sound_action_changed

from src.char.Daffodill import Daffodill as StockDaffodill
from src.combat.planner import Planner, RoleProfile


class Daffodill(StockDaffodill):
    cn_name = "达芙蒂尔（轮椅轴）"
    en_name = "Daffodill (Wheelchair)"

    INTRO_WAIT = 0.3
    R_POST_SLEEP = 0.5
    E_POST_SLEEP = 0.1
    LOOP_R_TO_E_WAIT = 0.3
    Q_CHARGE_TIMEOUT = 5
    CHARGE_ATTACK_INTERVAL = 0.05
    MAX_STAGE_ATTEMPTS = 3
    STAGE_RETRY_SLEEP = 0.2

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.planner_handles_arc = True

    def send_skill_key(self, after_sleep=0, interval=-1, down_time=0.01, action_name=None, **_):
        wait_sound_idle(self, label="达芙·E发键")
        return super().send_skill_key(
            after_sleep=after_sleep, interval=interval, down_time=down_time, action_name=action_name
        )

    def send_ultimate_key(self, after_sleep=0, interval=-1, down_time=0.01, action_name=None, **_):
        wait_sound_idle(self, label="达芙·Q发键")
        return super().send_ultimate_key(
            after_sleep=after_sleep, interval=interval, down_time=down_time, action_name=action_name
        )

    def send_arc_key(self, after_sleep=0, interval=-1, down_time=0.01, **_):
        wait_sound_idle(self, label="达芙·R发键")
        return super().send_arc_key(after_sleep=after_sleep, interval=interval, down_time=down_time)

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUB_DPS,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def _ultimate_ready(self):
        value = self.ultimate_available()
        return bool(value) if value is not None else False

    def _retry_block(self, name, block_func, max_attempts=2, not_in_combat_retry=True):
        not_in_combat_retried = False
        for attempt in range(max_attempts + 1):
            if attempt > 0:
                self.logger.warning(f"[{name}] 第 {attempt} 次重试")
                if (
                    not self.is_current_char
                    or getattr(self.task, "combat_detect_uncertain", False)
                ):
                    self.logger.info(
                        f"[{name}] 重试前等待状态落定"
                        f"（is_current_char={self.is_current_char}）"
                    )
                    diag_sleep(self, f"{name}重试前(COMBAT)", 0.1, checks=self.SleepChecks.COMBAT)
                else:
                    diag_sleep(self, f"{name}重试前(NONE)", 0.15, checks=self.SleepChecks.NONE)
            if self.is_dead:
                self.logger.warning(f"[{name}] 角色阵亡，终止")
                return False
            try:
                if block_func():
                    return True
            except Exception as e:
                err_name = type(e).__name__
                if err_name == "TaskDisabledException":
                    raise
                if err_name == "NotInCombatException":
                    if not not_in_combat_retry:
                        self.logger.warning(f"[{name}] 脱战（快速失败，不重试），直接抛出: {e}")
                        raise
                    if not_in_combat_retried:
                        self.logger.warning(f"[{name}] 连续脱战，终止（NotInCombatException）")
                        raise
                    not_in_combat_retried = True
                    self.logger.warning(f"[{name}] 瞬时脱战，允许重试一次: {e}")
                else:
                    self.logger.warning(f"[{name}] 执行异常（{err_name}），准备重试: {e}")
        if not_in_combat_retried:
            self.logger.error(f"[{name}] 重试用尽且期间发生过脱战，re-raise")
            self.task.raise_not_in_combat(f"{name} 重试用尽且期间发生过脱战")
        self.logger.error(f"[{name}] 达到最大重试次数，放弃")
        return False

    def _click_ultimate_with_retry(self, tag):
        q_ok = self.click_ultimate()
        if not q_ok and not self.is_dead:
            self.logger.warning(f"[达芙Q{tag}] 首次释放失败，重试1次")
            wait_sound_idle(self, label=f"达芙·Q重试前{tag}")
            diag_sleep(self, f"达芙Q重试前{tag}", 0.1)
            if self._ultimate_ready() and not self.is_dead:
                q_ok = self.click_ultimate()
        if not q_ok and not self.is_dead:
            self.logger.warning(f"[达芙Q{tag}] 重试后仍失败，跳过Q")
        return q_ok

    def wait_intro(self, time_out=-1, click=True):
        if not self.has_intro:
            diag_sleep(self, "达芙无intro", 0.1)
            return
        if self.INTRO_WAIT > 0:
            self.logger.info(f"[砍量] 达芙蒂尔INTRO_WAIT 1.00→{self.INTRO_WAIT:.2f}s")
            diag_sleep(self, "达芙蒂尔援护入场", self.INTRO_WAIT)
        else:
            self.logger.info("[砍量] 达芙蒂尔INTRO_WAIT=0，跳过")

    def _charge_for_q(self):
        self.logger.info(
            f"[达芙蒂尔] 循环轴 Q 不满，开始攒能（上限 {self.Q_CHARGE_TIMEOUT}s）"
        )
        start = self.clock.now()
        attacks = 0
        stamp = sound_action_stamp()
        while True:
            if self.is_dead:
                return False
            if self._ultimate_ready():
                self.logger.info(
                    f"[达芙蒂尔] 攒能成功（普攻 {attacks} 次，"
                    f"耗时 {self.clock.now() - start:.2f}s）"
                )
                return True
            if self.clock.now() - start > self.Q_CHARGE_TIMEOUT:
                self.logger.warning(
                    f"[达芙蒂尔] 攒能 {self.Q_CHARGE_TIMEOUT}s 超时（普攻 {attacks} 次），强制放弃"
                )
                return False
            if sound_action_changed(stamp):
                self.logger.info("[达芙蒂尔] 攒能检测到声音打断，补一次普攻保持段数")
                self.click(interval=self.CHARGE_ATTACK_INTERVAL)
                stamp = sound_action_stamp()
                continue
            self.click(interval=self.CHARGE_ATTACK_INTERVAL)
            stamp = sound_action_stamp()
            attacks += 1

    def _block_q_e(self):
        if self.is_dead:
            return False
        if self._ultimate_ready():
            q_start = self.clock.now()
            self._click_ultimate_with_retry("启动")
            self.logger.info(f"[诊断·达芙Q] click_ultimate 总耗时={self.clock.now()-q_start:.2f}s")
            if self.is_dead:
                return False
        else:
            self.logger.warning("[达芙蒂尔] Q 能量不足，跳过 Q 只打 E")

        if self.skill_available():
            e_start = self.clock.now()
            self.click_skill(down_time=0.05)
            self.logger.info(f"[诊断·达芙E] click_skill 耗时={self.clock.now()-e_start:.2f}s")
        if self.E_POST_SLEEP > 0:
            self.logger.info(f"[砍量] 达芙蒂尔E_POST_SLEEP 0.40→{self.E_POST_SLEEP:.2f}s")
            diag_sleep(self, "达芙蒂尔E后缓冲", self.E_POST_SLEEP)
        else:
            self.logger.info("[砍量] 达芙蒂尔E_POST_SLEEP=0，跳过E后缓冲")
        return not self.is_dead

    def _block_q_r_e(self):
        if self.is_dead:
            return False
        if not self._ultimate_ready():
            if not self._ultimate_ready():
                self._charge_for_q()

        if self._ultimate_ready():
            q_start = self.clock.now()
            self._click_ultimate_with_retry("循环")
            self.logger.info(f"[诊断·达芙Q(循环)] click_ultimate 总耗时={self.clock.now()-q_start:.2f}s")
            if self.is_dead:
                return False
            # v10.77 循环轴 R 同步 down_time=0.1（与启动轴一致，避免吞键）
            r_start = self.clock.now()
            self.send_arc_key(down_time=0.1)
            self.logger.info(f"[诊断·达芙R] send_arc_key 耗时={self.clock.now()-r_start:.2f}s")
            if self.LOOP_R_TO_E_WAIT > 0:
                diag_sleep(self, "达芙蒂尔循环R→E", self.LOOP_R_TO_E_WAIT)
            else:
                self.logger.info("[砍量] 达芙蒂尔LOOP_R_TO_E_WAIT=0，跳过R→E缓冲")
        else:
            self.logger.warning("[达芙蒂尔] Q 攒能失败，跳过 Q 继续 R-E")
            r_start = self.clock.now()
            self.send_arc_key(down_time=0.1)
            self.logger.info(f"[诊断·达芙R(无Q)] send_arc_key 耗时={self.clock.now()-r_start:.2f}s")
            if self.LOOP_R_TO_E_WAIT > 0:
                diag_sleep(self, "达芙蒂尔循环R→E", self.LOOP_R_TO_E_WAIT)
            else:
                self.logger.info("[砍量] 达芙蒂尔LOOP_R_TO_E_WAIT=0，跳过R→E缓冲")

        if self.is_dead:
            return False

        if self.skill_available():
            e_start = self.clock.now()
            self.click_skill(down_time=0.05)
            self.logger.info(f"[诊断·达芙E(循环)] click_skill 耗时={self.clock.now()-e_start:.2f}s")
        if self.E_POST_SLEEP > 0:
            self.logger.info(f"[砍量] 达芙蒂尔E_POST_SLEEP 0.40→{self.E_POST_SLEEP:.2f}s")
            diag_sleep(self, "达芙蒂尔E后缓冲", self.E_POST_SLEEP)
        else:
            self.logger.info("[砍量] 达芙蒂尔E_POST_SLEEP=0，跳过E后缓冲")
        return not self.is_dead

    def _block_r(self):
        if self.is_dead:
            return False
        wait_sound_idle(self, label="达芙·R发键前")

        # v10.77 定版：R 前稳定 1.0（用户实机验证，切换后给游戏层足够时间接收 R）
        diag_sleep(self, "达芙R前稳定", 1.0)

        for i in range(3):
            try:
                self.task.next_frame()
            except Exception:
                pass
            self.sleep(0.05, checks=self.SleepChecks.NONE)

        try:
            in_team = self.task.is_in_team()
        except Exception as e:
            in_team = f"err:{e}"
        self.logger.info(
            f"[诊断·达芙R状态] is_current_char={self.is_current_char} "
            f"is_in_team={in_team} has_intro={self.has_intro}"
        )

        # v10.77 根因修复：down_time 0.01→0.1（0.01 卡在游戏层识别临界点，偶发丢弃）
        r_start = self.clock.now()
        self.send_arc_key(down_time=0.1)
        self.logger.info(f"[诊断·达芙R(启动)] send_arc_key 耗时={self.clock.now()-r_start:.2f}s")
        if self.R_POST_SLEEP > 0:
            diag_sleep(self, "达芙蒂尔启动R后缓冲", self.R_POST_SLEEP)
        return True

    def combat_plan(self):
        rotation = get_rotation(self.task)

        def entry():
            stage = rotation.stage_for(self)
            self.logger.info(f"[达芙蒂尔入场] 阶段={stage}")
            if self.is_dead:
                self.logger.warning("[达芙蒂尔] 阵亡，重置轴到启动轴")
                rotation.reset()
                return

            for attempt in range(1, self.MAX_STAGE_ATTEMPTS + 1):
                if self.is_dead:
                    self.logger.warning("[达芙蒂尔] 角色阵亡，中断")
                    rotation.reset()
                    return
                try:
                    if stage == STAGE_OPEN_DAFFODILL_QE:
                        if attempt == 1:
                            self.logger.info("[达芙蒂尔] Q-E（启动轴）")
                        ok = self._retry_block("达芙蒂尔Q-E", self._block_q_e, 0)
                    elif stage == STAGE_OPEN_DAFFODILL_R:
                        if attempt == 1:
                            self.logger.info("[达芙蒂尔] R")
                        ok = self._retry_block("达芙蒂尔R", self._block_r, 2)
                    elif stage == STAGE_LOOP_DAFFODILL_QRE:
                        if attempt == 1:
                            self.logger.info("[达芙蒂尔] Q-R-E（循环轴）")
                        ok = self._retry_block(
                            "达芙蒂尔Q-R-E", self._block_q_r_e, 0
                        )
                    else:
                        self.logger.warning(
                            f"[达芙蒂尔异常] 阶段={stage}，直接切人"
                        )
                        advance_rotation(self, rotation)
                        return
                except Exception as e:
                    err_name = type(e).__name__
                    if err_name == "TaskDisabledException":
                        raise
                    if err_name == "NotInCombatException":
                        self.logger.warning("[达芙蒂尔] 脱战，向外抛出")
                        raise
                    self.logger.error(f"[达芙蒂尔异常] {e}")
                    ok = False

                if ok:
                    if self.is_dead:
                        self.logger.warning("[达芙蒂尔] 完成后阵亡，重置轴")
                        rotation.reset()
                        return
                    advance_rotation(self, rotation)
                    return

                self.logger.warning(
                    f"[达芙蒂尔] 阶段 {stage} 第 {attempt}/{self.MAX_STAGE_ATTEMPTS} 次失败"
                )
                if attempt < self.MAX_STAGE_ATTEMPTS:
                    diag_sleep(
                        self, "达芙阶段重试前", self.STAGE_RETRY_SLEEP, checks=self.SleepChecks.COMBAT
                    )

            self.logger.error(
                f"[达芙蒂尔] 阶段 {stage} 达到最大重试次数，重置轴避免死锁"
            )
            rotation.reset()

        return self.plan(entry=entry)