import sys

from src.char.BaseChar import BaseChar
from src.char.Zankou import Zankou as StockZankou
from src.combat.planner import Planner, RoleProfile
from src.Labels import Labels
from src.utils import clock

STAGE_OPEN_ZANKOU_PASS = "open_zankou_pass"
STAGE_OPEN_DAFFODILL_QE = "open_daffodill_qe"
STAGE_OPEN_BLACKBIRD_E_Q1 = "open_blackbird_e_q1"
STAGE_OPEN_DAFFODILL_R = "open_daffodill_r"
STAGE_OPEN_BLACKBIRD_Q2 = "open_blackbird_q2"
STAGE_OPEN_LINKO_QE = "open_linko_qe"
STAGE_OPEN_ZANKOU_COMBO = "open_zankou_combo"

STAGE_LOOP_LINKO_PASS = "loop_linko_pass"
STAGE_LOOP_BLACKBIRD_E_Q1 = "loop_blackbird_e_q1"
STAGE_LOOP_DAFFODILL_QRE = "loop_daffodill_qre"
STAGE_LOOP_BLACKBIRD_Q2 = "loop_blackbird_q2"
STAGE_LOOP_LINKO_QE = "loop_linko_qe"
STAGE_LOOP_ZANKOU_COMBO = "loop_zankou_combo"

STAGE_OWNER = {
    STAGE_OPEN_ZANKOU_PASS: "Zankou", STAGE_OPEN_DAFFODILL_QE: "Daffodill",
    STAGE_OPEN_BLACKBIRD_E_Q1: "Blackbird", STAGE_OPEN_DAFFODILL_R: "Daffodill",
    STAGE_OPEN_BLACKBIRD_Q2: "Blackbird", STAGE_OPEN_LINKO_QE: "Linko",
    STAGE_OPEN_ZANKOU_COMBO: "Zankou",
    STAGE_LOOP_LINKO_PASS: "Linko", STAGE_LOOP_BLACKBIRD_E_Q1: "Blackbird",
    STAGE_LOOP_DAFFODILL_QRE: "Daffodill", STAGE_LOOP_BLACKBIRD_Q2: "Blackbird",
    STAGE_LOOP_LINKO_QE: "Linko", STAGE_LOOP_ZANKOU_COMBO: "Zankou",
}

OPENING_STAGES = [
    STAGE_OPEN_ZANKOU_PASS, STAGE_OPEN_DAFFODILL_QE, STAGE_OPEN_BLACKBIRD_E_Q1,
    STAGE_OPEN_DAFFODILL_R, STAGE_OPEN_BLACKBIRD_Q2, STAGE_OPEN_LINKO_QE,
    STAGE_OPEN_ZANKOU_COMBO,
]
LOOP_STAGES = [
    STAGE_LOOP_LINKO_PASS, STAGE_LOOP_BLACKBIRD_E_Q1, STAGE_LOOP_DAFFODILL_QRE,
    STAGE_LOOP_BLACKBIRD_Q2, STAGE_LOOP_LINKO_QE,
    STAGE_LOOP_ZANKOU_COMBO,
]

WINDOW_RE_CLAIM_TIMEOUT = 3.0
WINDOW_RE_CLAIM_POLL = 0.1
SWITCH_RETRY_WINDOW = 2.0
MAX_STAGE_ATTEMPTS = 3

ROTATION_VERSION = "v10.77"

_LAST_SWITCH_FAIL_TIME = 0.0


def _switch_just_failed():
    if _LAST_SWITCH_FAIL_TIME <= 0:
        return False
    return (clock.now() - _LAST_SWITCH_FAIL_TIME) < SWITCH_RETRY_WINDOW


def _record_switch_fail():
    global _LAST_SWITCH_FAIL_TIME
    _LAST_SWITCH_FAIL_TIME = clock.now()


def _clear_switch_fail():
    global _LAST_SWITCH_FAIL_TIME
    _LAST_SWITCH_FAIL_TIME = 0.0


def diag_sleep(char, label, duration, checks=None):
    if duration <= 0:
        return
    start = char.clock.now()
    check_sound = duration >= 0.3
    stamp_before = sound_action_stamp() if check_sound else None
    if checks is not None:
        char.sleep(duration, checks=checks)
    else:
        char.sleep(duration, checks=char.SleepChecks.NONE)
    actual = char.clock.now() - start
    interrupted = ""
    if check_sound:
        if sound_action_stamp() != stamp_before:
            interrupted = " ⚡sound"
    diff = actual - duration
    tag = ""
    if diff < -0.1:
        tag = " 提前"
    elif diff > 0.15:
        tag = " 超时"
    char.logger.info(f"[诊断·sleep] {label} 设{duration:.2f} 实{actual:.2f}{interrupted}{tag}")


def diag_normal_attack(char, label=""):
    start = char.clock.now()
    char.normal_attack()
    actual = char.clock.now() - start
    if actual > 0.15:
        char.logger.info(f"[诊断·普攻] {label} 耗时 {actual:.2f}s（偏长）")
    return actual


def diag_read_q(char, label):
    try:
        return bool(char.ultimate_available())
    except Exception as e:
        char.logger.warning(f"[诊断·Q读取异常] {label}: {e}")
        return None


def wait_sound_idle(char, max_wait=0.3, poll=0.03, label=""):
    try:
        from src.sound_trigger.SoundCombatContext import SoundCombatContext
        ctx = SoundCombatContext()
    except Exception:
        return

    def _active():
        try:
            return bool(SoundCombatContext.should_interrupt_combat())
        except TypeError:
            try:
                return bool(ctx.should_interrupt_combat())
            except Exception:
                return False
        except Exception:
            return False

    if not _active():
        return
    try:
        if hasattr(ctx, "is_bound_to") and not ctx.is_bound_to(char.task):
            return
    except Exception:
        pass

    start = char.clock.now()
    waited = False
    while char.clock.now() - start < max_wait:
        if not _active():
            if waited:
                char.logger.info(f"[诊断·sound静默] {label} 等{char.clock.now()-start:.2f}s")
            return
        waited = True
        char.sleep(poll, checks=char.SleepChecks.SOUND)
    char.logger.warning(f"[诊断·sound静默超时] {label} 等{char.clock.now()-start:.2f}s仍活跃")


def wait_is_in_team_then_sleep(
    char,
    label,
    timeout,
    post_sleep=0.06,
    enter_anim_timeout=1.0,
    sample_interval=0.05,
):
    enter_start = char.clock.now()
    entered_anim = False
    phase1_elapsed = 0.0
    while True:
        elapsed = char.clock.now() - enter_start
        if elapsed >= enter_anim_timeout:
            break
        try:
            char.task.next_frame()
        except Exception:
            pass
        try:
            state = bool(char.task.is_in_team())
        except Exception:
            state = None
        if state is False:
            entered_anim = True
            phase1_elapsed = elapsed
            break
        remain = enter_anim_timeout - elapsed
        char.sleep(min(sample_interval, remain), checks=char.SleepChecks.NONE)

    if not entered_anim:
        char.logger.info(f"[{label}] 阶段1 {enter_anim_timeout}s 内未进入脱队动画")
        if post_sleep > 0:
            diag_sleep(char, f"{label} post", post_sleep)
        return

    char.logger.info(f"[{label}] 阶段1 进入脱队动画 @ {phase1_elapsed:.2f}s")

    end_start = char.clock.now()
    detected_at = None
    while True:
        try:
            char.task.next_frame()
        except Exception:
            pass
        try:
            state = bool(char.task.is_in_team())
        except Exception:
            state = None
        if state is True:
            detected_at = char.clock.now() - end_start
            break
        remain = timeout - (char.clock.now() - end_start)
        if remain <= 0:
            break
        char.sleep(min(sample_interval, remain), checks=char.SleepChecks.NONE)

    total = char.clock.now() - enter_start
    if detected_at is not None:
        char.logger.info(
            f"[{label}] 阶段2 脱队动画结束（总 {total:.2f}s，动画段 {detected_at:.2f}s，timeout {timeout}s）"
        )
    else:
        char.logger.warning(
            f"[{label}] 阶段2 is_in_team 超时 {total:.2f}s（timeout {timeout}s），继续"
        )
    if post_sleep > 0:
        diag_sleep(char, f"{label} post", post_sleep)


def send_ultimate_with_diag(char, label, timeout, post_sleep, retry=False, max_attempts=2):
    attempt = 0
    accepted = False
    while attempt < max_attempts:
        attempt += 1
        before = diag_read_q(char, f"{label} 发前#{attempt}")
        char.logger.info(f"[诊断·Q] {label} 发前#{attempt} available={before}")

        char.send_ultimate_key(down_time=0.05, action_name=f"ultimate_send_{label}")
        char.sleep(0.05, checks=char.SleepChecks.NONE)

        after = diag_read_q(char, f"{label} 发后50ms#{attempt}")
        char.logger.info(f"[诊断·Q] {label} 发后50ms#{attempt} available={after}")

        if after is False:
            accepted = True
            break
        elif after is True:
            if retry and attempt < max_attempts:
                char.logger.warning(
                    f"[吞Q诊断] {label} 第 {attempt} 次发键后50ms仍亮，准备重试"
                )
                wait_sound_idle(char, label=f"{label}重试前")
                diag_sleep(char, f"{label}重试前", 0.1)
                continue
            else:
                if retry:
                    char.logger.warning(
                        f"[吞Q诊断] {label} 第 {attempt} 次发键后50ms仍亮，重试用尽"
                    )
                else:
                    char.logger.warning(
                        f"[吞Q诊断] {label} 发键后50ms仍亮（未启用重试）"
                    )
                break
        else:
            char.logger.warning(f"[诊断·Q] {label} 发后50ms#{attempt} 读取异常")
            break

    wait_is_in_team_then_sleep(char, f"{label} POST", timeout=timeout, post_sleep=post_sleep)

    if char.is_dead:
        return
    try:
        char.task.next_frame()
    except Exception:
        return
    post = diag_read_q(char, f"{label} 发后POST")
    char.logger.info(f"[诊断·Q] {label} 发后POST available={post}")

    if accepted and post is True:
        char.logger.info(f"[吞Q] {label} 已接收，POST 时 CD 已恢复（非吞Q）")


def sound_action_stamp():
    try:
        from src.sound_trigger.SoundCombatContext import SoundCombatContext
        ctx = SoundCombatContext()
        listener = getattr(ctx, "listener", None)
        if listener is None:
            return (0.0,)
        return (getattr(listener, "_last_trigger_time", 0.0),)
    except Exception:
        return (0.0,)


def sound_action_changed(stamp):
    return sound_action_stamp() != stamp


class ZankouWheelchairRotation:
    VERSION = ROTATION_VERSION

    def __init__(self):
        self.queue = []
        self._battle_end_time = 0.0
        self._battle_end_session = None
        self._boss_approached = False
        self.reset()

    def reset(self, new_battle=False):
        self.queue = list(OPENING_STAGES)
        self._battle_end_time = 0.0
        self._battle_end_session = None
        if new_battle:
            self._boss_approached = False

    def current_stage(self):
        return self.queue[0] if self.queue else None

    def current_owner(self):
        return STAGE_OWNER.get(self.current_stage(), "") if self.current_stage() else ""

    def stage_for(self, char):
        stage = self.current_stage()
        if stage and STAGE_OWNER.get(stage) == type(char).__name__:
            return stage
        return None

    def advance(self):
        if self.queue:
            self.queue.pop(0)
        if not self.queue:
            self.queue = list(LOOP_STAGES)


ROTATION_ATTR = "zankou_wheelchair_rotation"


def get_rotation(task):
    rotation = getattr(task, ROTATION_ATTR, None)
    if rotation is None or getattr(rotation, "VERSION", None) != ROTATION_VERSION:
        if rotation is not None:
            try:
                task.logger.info(
                    f"[排轴] 检测到旧版本排轴实例 "
                    f"(version={getattr(rotation, 'VERSION', 'unknown')})，重建为 {ROTATION_VERSION}"
                )
            except Exception:
                pass
        rotation = ZankouWheelchairRotation()
        setattr(task, ROTATION_ATTR, rotation)
        task.find_element_reaction_target = lambda source_char: None
    return rotation


def find_teammate(char, owner_name):
    for t in char.task.chars:
        if t is not None and type(t).__name__ == owner_name:
            return t
    return None


def advance_rotation(char, rotation):
    old_stage = rotation.current_stage()

    if old_stage == STAGE_OPEN_ZANKOU_PASS and type(char).__name__ != "Zankou":
        zankou = find_teammate(char, "Zankou")
        if zankou is not None and not zankou.is_dead:
            char.logger.info(
                f"[排轴] 首切残虹过场：{type(char).__name__} 请求切到 Zankou（不推进阶段）"
            )
            char.combat_context.request_switch(zankou, reason="首切残虹过场")
            _clear_switch_fail()
            return
        char.logger.warning(
            f"[排轴] 首切残虹过场：Zankou 已死，跳过 {old_stage}"
        )

    rotation.advance()

    max_skip = len(OPENING_STAGES) + len(LOOP_STAGES)
    for _ in range(max_skip):
        target_name = rotation.current_owner()
        target = find_teammate(char, target_name) if target_name else None
        if target is not None and not target.is_dead:
            break
        char.logger.warning(
            f"[排轴跳过] {rotation.current_stage()} owner={target_name} "
            f"已死或不存在，跳过该阶段"
        )
        try:
            target_is_dead = getattr(target, "is_dead", None) if target is not None else None
            chars_info = []
            for t in char.task.chars:
                if t is None:
                    continue
                chars_info.append(
                    f"{type(t).__name__}(dead={getattr(t, 'is_dead', None)})"
                )
            char.logger.warning(
                f"[排轴跳过诊断] target_name={target_name} "
                f"target={'存在' if target is not None else 'None'} "
                f"is_dead={target_is_dead} "
                f"chars_count={len(chars_info)} chars={chars_info}"
            )
        except Exception as e:
            char.logger.warning(f"[排轴跳过诊断] 诊断异常：{e}")
        rotation.advance()

    target_name = rotation.current_owner()
    target = find_teammate(char, target_name) if target_name else None
    char.logger.info(
        f"[排轴推进] {type(char).__name__} 完成 {old_stage} -> 推进至 {rotation.current_stage()}"
    )

    if target is None:
        char.logger.warning(
            f"[排轴警告] 找不到活着的队友 {target_name}，重置轴到启动轴"
        )
        rotation.reset()
        _record_switch_fail()
        return

    if target is char:
        char.logger.info(f"[排轴推进] 下一阶段仍为 {target_name}，原地继续")
        _clear_switch_fail()
        return

    if _switch_just_failed():
        char.logger.warning(
            f"[排轴回退] 切换 {target_name} 近期失败，回退 {old_stage} 避免 not in team 死锁"
        )
        rotation.queue.insert(0, old_stage)
        _clear_switch_fail()
        return

    char.combat_context.request_switch(target, reason=f"wheelchair -> {rotation.current_stage()}")
    _clear_switch_fail()


class Zankou(StockZankou):
    cn_name = "残虹"
    en_name = "Zankou (Wheelchair)"
    element = BaseChar.ElementType.RED

    INTRO_WAIT = 0
    HEAVY_ATTACK_HOLD = 1.5
    YELLOW_E_POLL_TIMEOUT = 4
    E_POLL_TIMEOUT = 7
    PURPLE_E_POST_SLEEP = 1.2
    Q2_POLL_TIMEOUT = 4.5
    Q2_POST_TIMEOUT = 4.5
    Q2_POST_SEND_SLEEP = 0.05
    Q2_POST_SLEEP = 1
    MAX_YELLOW_E_MISS_TIME = 12
    ENABLE_APPROACH_BOSS = True
    APPROACH_W_PRESS_WAIT = 0.1
    APPROACH_DODGE_INTERVAL = 0.2
    APPROACH_DODGE_DOWN_TIME = 0.1
    APPROACH_DODGE_KEY = "lshift"
    APPROACH_FORWARD_KEY = "w"
    APPROACH_FINAL_WAIT = 0.1
    APPROACH_MOUSE_RELEASE_WAIT = 0.05
    STAGE_RETRY_SLEEP = 0.2

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.planner_handles_arc = True
        self._last_bb_q_state = None
        self._last_bb_q_log_time = 0.0

    def send_skill_key(self, after_sleep=0, interval=-1, down_time=0.01, action_name=None, **_):
        wait_sound_idle(self, label="残虹·E发键")
        return super().send_skill_key(
            after_sleep=after_sleep, interval=interval, down_time=down_time, action_name=action_name
        )

    def send_ultimate_key(self, after_sleep=0, interval=-1, down_time=0.01, action_name=None, **_):
        wait_sound_idle(self, label="残虹·Q发键")
        return super().send_ultimate_key(
            after_sleep=after_sleep, interval=interval, down_time=down_time, action_name=action_name
        )

    def send_arc_key(self, after_sleep=0, interval=-1, down_time=0.01, **_):
        wait_sound_idle(self, label="残虹·R发键")
        return super().send_arc_key(after_sleep=after_sleep, interval=interval, down_time=down_time)

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.MAIN_DPS,
            field_preference=Planner.FieldPreference.MAIN_DPS,
            max_field_time=0,
            combat_start_priority=10,
        )

    def combat_policies(self):
        rotation = get_rotation(self.task)
        current_session = getattr(self.task, "combat_session", None)
        end_session = getattr(rotation, "_battle_end_session", None)
        battle_end_time = getattr(rotation, "_battle_end_time", 0.0)
        elapsed = self.clock.now() - battle_end_time if battle_end_time > 0 else -1

        self.logger.info(
            f"[排轴诊断] combat_session id={id(current_session)}, "
            f"end_session id={id(end_session) if end_session is not None else None}, "
            f"session_same={end_session is not None and current_session is end_session}, "
            f"elapsed={elapsed:.2f}s"
        )

        if end_session is not None and current_session is not end_session:
            rotation.reset(new_battle=True)
            self.logger.info(
                f"[排轴] 新战斗（session 变更，上次结束 {elapsed:.2f}s 前），重置到启动轴"
            )
        elif end_session is not None:
            self.logger.info(
                f"[排轴] 脱战重开（session 未变，间隔 {elapsed:.2f}s），"
                f"保持队列 stage={rotation.current_stage()}"
            )
        else:
            rotation.reset(new_battle=True)
            self.logger.info("[排轴] 首次加载，重置到启动轴")

        self.task.find_element_reaction_target = lambda source_char: None

    def on_combat_end(self, chars):
        rotation = get_rotation(self.task)
        rotation._battle_end_time = self.clock.now()
        rotation._battle_end_session = getattr(self.task, "combat_session", None)
        self.logger.info("[排轴] 战斗结束，记录时间戳和 session")
        super().on_combat_end(chars)

    def _retry_block(self, name, block_func, max_attempts=2, not_in_combat_retry=True):
        not_in_combat_retried = False
        for attempt in range(max_attempts + 1):
            if attempt > 0:
                self.logger.warning(f"[{name}] 第 {attempt} 次重试")
                if (
                    not self.is_current_char
                    or getattr(self.task, "combat_detect_uncertain", False)
                ):
                    self.logger.info(
                        f"[{name}] 重试前等待状态落定"
                        f"（is_current_char={self.is_current_char}，"
                        f"combat_detect_uncertain="
                        f"{getattr(self.task, 'combat_detect_uncertain', False)}）"
                    )
                    diag_sleep(self, f"{name}重试前(COMBAT)", 0.1, checks=self.SleepChecks.COMBAT)
                else:
                    diag_sleep(self, f"{name}重试前(NONE)", 0.15, checks=self.SleepChecks.NONE)
            if self.is_dead:
                self.logger.warning(f"[{name}] 角色阵亡，终止")
                return False
            try:
                if block_func():
                    return True
            except Exception as e:
                err_name = type(e).__name__
                if err_name == "TaskDisabledException":
                    raise
                if err_name == "NotInCombatException":
                    if not not_in_combat_retry:
                        self.logger.warning(f"[{name}] 脱战（快速失败，不重试），直接抛出: {e}")
                        raise
                    if not_in_combat_retried:
                        self.logger.warning(f"[{name}] 连续脱战，终止（NotInCombatException）")
                        raise
                    not_in_combat_retried = True
                    self.logger.warning(f"[{name}] 瞬时脱战，允许重试一次: {e}")
                else:
                    self.logger.warning(f"[{name}] 执行异常（{err_name}），准备重试: {e}")
        if not_in_combat_retried:
            self.logger.error(f"[{name}] 重试用尽且期间发生过脱战，re-raise")
            self.task.raise_not_in_combat(f"{name} 重试用尽且期间发生过脱战")
        self.logger.error(f"[{name}] 达到最大重试次数，放弃")
        return False

    def _approach_boss(self):
        if self.is_dead:
            return
        if not self.ENABLE_APPROACH_BOSS:
            self.logger.info("[残虹] 接近BOSS已禁用（ENABLE_APPROACH_BOSS=False），跳过")
            return
        rotation = get_rotation(self.task)
        if getattr(rotation, "_boss_approached", False):
            self.logger.info("[残虹] 本场战斗已接近过BOSS，跳过重复移动")
            return

        try:
            self.task.mouse_up("left")
            self.logger.info("[残虹] 清除鼠标左键残留状态")
        except Exception as e:
            self.logger.warning(f"[残虹] mouse_up('left') 失败：{e}")
        if self.APPROACH_MOUSE_RELEASE_WAIT > 0:
            diag_sleep(self, "首切·清残留", self.APPROACH_MOUSE_RELEASE_WAIT)

        self.logger.info(
            "[残虹] 首切接近BOSS：按住W（task.send_key_down/send_key_up）"
            f" + W预热 {self.APPROACH_W_PRESS_WAIT}s"
            f" + 2次闪避（按键{self.APPROACH_DODGE_KEY}，单套，"
            f"按下{self.APPROACH_DODGE_DOWN_TIME}s，间隔{self.APPROACH_DODGE_INTERVAL}s）"
            f" + 收尾{self.APPROACH_FINAL_WAIT}s"
        )
        try:
            self.task.send_key_down(self.APPROACH_FORWARD_KEY)
            self.logger.info(
                f"[残虹] W 已按住，等 {self.APPROACH_W_PRESS_WAIT}s 让游戏识别方向"
            )
        except Exception as e:
            self.logger.error(
                f"[残虹] task.send_key_down 失败，跳过接近BOSS移动：{e}"
            )
            return
        try:
            diag_sleep(self, "首切·W预热", self.APPROACH_W_PRESS_WAIT)
            if self.is_dead:
                return

            self.send_key(
                self.APPROACH_DODGE_KEY, down_time=self.APPROACH_DODGE_DOWN_TIME
            )
            diag_sleep(self, "首切·闪避1后", self.APPROACH_DODGE_INTERVAL)
            if self.is_dead:
                return

            self.send_key(
                self.APPROACH_DODGE_KEY, down_time=self.APPROACH_DODGE_DOWN_TIME
            )
            diag_sleep(self, "首切·闪避2后收尾", self.APPROACH_FINAL_WAIT)
        finally:
            try:
                self.task.send_key_up(self.APPROACH_FORWARD_KEY)
                self.logger.info("[残虹] W 已松开")
            except Exception as e:
                self.logger.error(f"[残虹] task.send_key_up 失败：{e}")
        rotation._boss_approached = True
        self.logger.info("[残虹] 接近BOSS移动完成（本场战斗标记已接近）")

    def _run_stage_with_retry(self, stage, func, label):
        for attempt in range(1, MAX_STAGE_ATTEMPTS + 1):
            if self.is_dead:
                self.logger.warning(f"[残虹] {label} 角色阵亡，中断")
                return False
            try:
                success = func()
            except Exception as e:
                err_name = type(e).__name__
                if err_name == "TaskDisabledException":
                    raise
                if err_name == "NotInCombatException":
                    self.logger.warning(f"[残虹{label}] 脱战，向外抛出")
                    raise
                self.logger.error(f"[残虹{label}异常] {e}")
                success = False
            if success:
                self.logger.info(f"[残虹] {label} 成功（第 {attempt} 次）")
                return True
            self.logger.warning(
                f"[残虹] {label} 第 {attempt}/{MAX_STAGE_ATTEMPTS} 次失败"
            )
            if attempt < MAX_STAGE_ATTEMPTS:
                diag_sleep(
                    self, f"{label}阶段重试前", self.STAGE_RETRY_SLEEP, checks=self.SleepChecks.COMBAT
                )
        self.logger.error(f"[残虹] {label} 达到最大重试次数 {MAX_STAGE_ATTEMPTS}")
        return False

    def combat_plan(self):
        rotation = get_rotation(self.task)

        def entry():
            stage = rotation.stage_for(self)
            self.logger.info(f"[残虹入场] 阶段={stage}")
            if self.is_dead:
                self.logger.warning("[残虹] 阵亡，重置轴到启动轴")
                rotation.reset()
                return
            if stage == STAGE_OPEN_ZANKOU_PASS:
                try:
                    self._approach_boss()
                except Exception as e:
                    self.logger.error(f"[残虹过场异常] {e}")
                if self.is_dead:
                    self.logger.warning("[残虹] 过场后阵亡，重置轴")
                    rotation.reset()
                    return
                advance_rotation(self, rotation)
            elif stage in (STAGE_OPEN_ZANKOU_COMBO, STAGE_LOOP_ZANKOU_COMBO):
                self.logger.info(
                    "[残虹动作] 大循环：前置Q1-Q2 → 循环(ZA-黄E-一直A-紫E)直到状态满足"
                )
                success = self._run_stage_with_retry(stage, self.perform_macro_loop, "大循环")
                if self.is_dead:
                    self.logger.warning("[残虹] 大循环后阵亡，重置轴")
                    rotation.reset()
                    return
                if not success:
                    self.logger.warning("[残虹] 大循环失败，推进后由后续段兜底")
                advance_rotation(self, rotation)
            else:
                self.logger.warning(f"[残虹异常] 阶段={stage}，直接切人")
                advance_rotation(self, rotation)

        return self.plan(entry=entry)

    def wait_intro(self, time_out=-1, click=True):
        if self.has_intro:
            if self.INTRO_WAIT > 0:
                self.logger.info(f"[砍量] 残虹INTRO_WAIT 1.00→{self.INTRO_WAIT:.2f}s")
                diag_sleep(self, "残虹援护入场", self.INTRO_WAIT)
            else:
                self.logger.info("[砍量] 残虹INTRO_WAIT=0，跳过")

    def _ultimate_ready(self):
        value = self.ultimate_available()
        return bool(value) if value is not None else False

    def _check_exit_condition(self):
        # v10.77 退出条件改为 环合 + 残虹紫Q（原黑羽Q）
        if self.is_cycle_full() and self._ultimate_ready():
            self.logger.info("[残虹大循环] 满足环合 + 残虹紫Q，强制打断并退出")
            return True
        return False

    def perform_macro_loop(self):
        self.logger.info("[残虹大循环] 开始")
        q12_done = self._block_q12()
        if not q12_done:
            self.logger.warning("[残虹大循环] 前置紫Q未亮，未放Q1-Q2")

        loop_start = self.clock.now()
        yellow_miss_start = None
        loop_count = 0
        MAX_MACRO_LOOP_TIME = 40.0

        while True:
            if self.is_dead:
                return False

            elapsed = self.clock.now() - loop_start
            if elapsed > MAX_MACRO_LOOP_TIME:
                self.logger.warning(f"[残虹大循环] 超时 {MAX_MACRO_LOOP_TIME}s，强制退出")
                break

            loop_count += 1
            self.logger.info(f"[残虹大循环] 开始第 {loop_count} 轮（已耗时 {elapsed:.1f}s）")

            if yellow_miss_start is None:
                yellow_miss_start = self.clock.now()

            yellow_ok = self._retry_block(
                "残虹大循环黄E", self._loop_za_until_yellow_e, 2, not_in_combat_retry=False
            )
            if not yellow_ok:
                miss_total = self.clock.now() - yellow_miss_start
                self.logger.warning(
                    f"[残虹大循环] 第 {loop_count} 轮黄E失败，累计黄E未亮 {miss_total:.1f}s"
                )
                if miss_total > self.MAX_YELLOW_E_MISS_TIME:
                    self.logger.warning(
                        f"[残虹大循环] 连续黄E未亮 {miss_total:.1f}s "
                        f"超过 {self.MAX_YELLOW_E_MISS_TIME:.1f}s，退出大循环交给队友"
                    )
                    break
                continue

            yellow_miss_start = None

            if not self._retry_block(
                "残虹大循环紫E", self._loop_until_purple_e, 2, not_in_combat_retry=False
            ):
                self.logger.warning(f"[残虹大循环] 第 {loop_count} 轮紫E失败，继续尝试")

            if loop_count == 1 and not q12_done:
                try:
                    self.task.next_frame()
                except Exception:
                    pass
                if self.find_ult_purple():
                    self.logger.info("[残虹大循环] 第 1 轮结束后紫Q亮起，释放 Q1-Q2")
                    if self._block_q12():
                        q12_done = True
                else:
                    self.logger.info("[残虹大循环] 第 1 轮结束后紫Q未亮，后续不再检查")

            if self._check_exit_condition():
                break

        return True

    def _loop_za_until_yellow_e(self):
        if self.is_dead:
            return False
        self.logger.info("[残虹大循环] ZA 连打查黄E")
        start = self.clock.now()
        attacks = 0

        while self.clock.now() - start < self.YELLOW_E_POLL_TIMEOUT:
            if self.is_dead:
                return False

            round_start = self.clock.now()

            h_start = self.clock.now()
            self.heavy_attack(self.HEAVY_ATTACK_HOLD)
            h_actual = self.clock.now() - h_start

            diag_sleep(self, f"ZA轮{attacks+1}·Z后", 0.0, checks=self.SleepChecks.COMBAT)
            if self._check_exit_condition(): return True

            a_actual = diag_normal_attack(self, f"ZA轮{attacks+1}·A")

            diag_sleep(self, f"ZA轮{attacks+1}·A后", 1.0, checks=self.SleepChecks.COMBAT)
            if self._check_exit_condition(): return True

            round_total = self.clock.now() - round_start
            is_yellow = self.find_zankou_skill() == Labels.zankou_skill_gold
            if round_total > 3.0 or is_yellow:
                self.logger.info(
                    f"[诊断·ZA轮{attacks+1}] heavy={h_actual:.2f}s A={a_actual:.2f}s "
                    f"总={round_total:.2f}s 黄E={'亮' if is_yellow else '否'}"
                )

            if is_yellow:
                self.logger.info(f"[残虹大循环] 检测到黄E（{self.clock.now() - start:.2f}s）")
                if self.click_skill(down_time=0.05, time_out=2.0):
                    if self._check_exit_condition(): return True
                    return True
                else:
                    self.logger.warning("[残虹大循环] 黄E释放失败")

            attacks += 1

        self.logger.warning(f"[残虹大循环] 查黄E超时（{attacks} 次 ZA）")
        return False

    def _loop_until_purple_e(self):
        if self.is_dead:
            return False
        self.logger.info("[残虹大循环] 一直A查紫E")
        start = self.clock.now()
        attacks = 0
        stamp = sound_action_stamp()
        last_progress_log = start
        while self.clock.now() - start < self.E_POLL_TIMEOUT:
            if self.is_dead:
                return False
            if not self.is_current_char:
                if not self._wait_on_field("查紫E"):
                    return False

            if self.find_zankou_skill() == Labels.zankou_skill_purple:
                self.logger.info(f"[残虹大循环] 检测到紫E（{self.clock.now() - start:.2f}s）")
                if self.click_skill(down_time=0.05, time_out=2.0):
                    if self.PURPLE_E_POST_SLEEP > 0:
                        diag_sleep(self, "残虹紫E后缓冲", self.PURPLE_E_POST_SLEEP)
                    if self._check_exit_condition(): return True
                    return True
                else:
                    self.logger.info("[残虹大循环] 紫E释放失败（下一帧重试）")

            now = self.clock.now()
            if now - last_progress_log >= 2.0:
                bb_ready = self._blackbird_q_ready_silent()
                self.logger.info(
                    f"[诊断·查紫E] elapsed={now-start:.2f}s attacks={attacks} 黑羽Q={bb_ready}"
                )
                last_progress_log = now

            if sound_action_changed(stamp):
                self.normal_attack()
                if self._check_exit_condition(): return True
                stamp = sound_action_stamp()
                continue

            self.normal_attack()
            if self._check_exit_condition(): return True
            stamp = sound_action_stamp()
            attacks += 1
        self.logger.warning(f"[残虹大循环] 查紫E超时（{attacks} 次普攻）")
        return False

    def _block_q12(self):
        if self.is_dead:
            return False

        self.logger.info("[残虹诊断] 开始诊断紫Q状态")
        has_purple = False
        for i in range(3):
            try:
                self.task.next_frame()
            except Exception:
                pass
            has_purple = self.find_ult_purple()
            self.logger.info(f"[残虹诊断] 第 {i+1}/3 次读紫Q: {'亮' if has_purple else '未亮'}")
            if has_purple:
                break
            diag_sleep(self, f"读紫Q{i+1}之间", 0.1, checks=self.SleepChecks.COMBAT)

        if not has_purple:
            self.logger.warning("[残虹] 紫Q未亮，跳过 Q1-Q2")
            return False

        self.logger.info("[残虹] Q1 释放")
        q1_start = self.clock.now()
        q1_ok = self.click_ultimate()
        self.logger.info(f"[诊断·残虹Q1] click_ultimate 返回={q1_ok} 耗时={self.clock.now()-q1_start:.2f}s")
        if not q1_ok:
            self.logger.warning("[残虹] Q1 释放失败")
            return True

        if self.is_dead:
            return True

        q2_start = self.clock.now()
        q2_success = False
        last_q2_check = q2_start
        while self.clock.now() - q2_start < self.Q2_POLL_TIMEOUT:
            if self.is_dead:
                return True
            now = self.clock.now()
            elapsed = now - q2_start
            if now - last_q2_check >= 0.3:
                ready = diag_read_q(self, "残虹Q2轮询")
                if ready:
                    self.logger.info(f"[残虹Q2轮询] elapsed={elapsed:.2f}s available=True → 发键")
                    send_ultimate_with_diag(
                        self, "残虹Q2", self.Q2_POST_TIMEOUT, self.Q2_POST_SEND_SLEEP
                    )
                    q2_success = True
                    break
                self.logger.info(f"[残虹Q2轮询] elapsed={elapsed:.2f}s available=False")
                last_q2_check = now
            diag_sleep(self, "残虹Q2轮询间隔", 0.1, checks=self.SleepChecks.COMBAT)

        if q2_success:
            self.logger.info(
                f"[残虹] Q2 send 完成（Q1 后轮询 {self.clock.now() - q2_start:.2f}s）"
            )
            self.logger.info(
                f"[残虹] Q2 后摇等待 {self.Q2_POST_SLEEP:.2f}s，确保收招硬直结束，防止 ZA 的 Z 被吞"
            )
            diag_sleep(self, "残虹Q2后缓冲", self.Q2_POST_SLEEP)
        else:
            self.logger.warning(
                f"[残虹] Q2 超时未就绪（轮询 {self.Q2_POLL_TIMEOUT}s 超时），跳过"
            )
        return True

    def _wait_on_field(self, desc):
        if self.is_current_char:
            return True
        self.logger.warning(f"[残虹空窗] {desc} 前不在场，等待切回")
        wait_start = self.clock.now()
        while self.clock.now() - wait_start < WINDOW_RE_CLAIM_TIMEOUT:
            diag_sleep(self, f"残虹空窗·{desc}轮询", WINDOW_RE_CLAIM_POLL, checks=self.SleepChecks.COMBAT)
            if self.is_dead:
                self.logger.warning("[残虹空窗] 等待切回期间阵亡")
                return False
            if self.is_current_char:
                self.logger.info("[残虹空窗] 切回成功")
                return True
        self.logger.warning(f"[残虹空窗] {desc} 切回超时")
        return False

    def _blackbird_q_ready(self):
        # v10.77 保留为诊断/备用，退出条件已改为残虹紫Q
        bb = find_teammate(self, "Blackbird")
        ok = bb is not None and bool(bb.ultimate_available())
        now = self.clock.now()
        state = "ready" if ok else "not_ready"
        if state != self._last_bb_q_state or (now - self._last_bb_q_log_time) >= 1.0:
            if ok:
                self.logger.info("[残虹空窗] 黑羽 Q 已满")
            else:
                self.logger.info("[残虹空窗] 黑羽 Q 未满，继续补打等后台回能")
            self._last_bb_q_state = state
            self._last_bb_q_log_time = now
        return ok

    def _blackbird_q_ready_silent(self):
        bb = find_teammate(self, "Blackbird")
        return bb is not None and bool(bb.ultimate_available())


TEAM_MODULE_KEY = "_zankou_wheelchair_team_module"
try:
    from pathlib import Path as _Path

    _TEAM_SOURCE_STAMP = _Path(__file__).resolve().stat().st_mtime_ns
except OSError:
    _TEAM_SOURCE_STAMP = None
sys.modules[TEAM_MODULE_KEY] = sys.modules[__name__]