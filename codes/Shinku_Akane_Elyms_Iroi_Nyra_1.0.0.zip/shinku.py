import sys
import dataclasses

from src.char.Shinku import Shinku as StockShinku
from src.combat.planner import Planner, RoleProfile

STAGE_OPEN_SHINKU_PASS = "open_shinku_pass"
STAGE_OPEN_AKANE_Q1 = "open_akane_q1"
STAGE_OPEN_ELYMS_EQ = "open_elyms_eq"
STAGE_OPEN_IROI_EQZ = "open_iroi_eqz"
STAGE_OPEN_AKANE_Q2 = "open_akane_q2"
STAGE_OPEN_SHINKU_BURST = "open_shinku_burst"

STAGE_LOOP_IROI_E = "loop_iroi_e"
STAGE_LOOP_AKANE_EQ = "loop_akane_eq"
STAGE_LOOP_ELYMS_EQ = "loop_elyms_eq"
STAGE_LOOP_IROI_QZ = "loop_iroi_qz"
STAGE_LOOP_AKANE_Q2 = "loop_akane_q2"
STAGE_LOOP_SHINKU_BURST = "loop_shinku_burst"

STAGE_OWNER = {
    STAGE_OPEN_SHINKU_PASS: "Shinku",
    STAGE_OPEN_AKANE_Q1: "Akane",
    STAGE_OPEN_ELYMS_EQ: "Elyms",
    STAGE_OPEN_IROI_EQZ: "Iroi",
    STAGE_OPEN_AKANE_Q2: "Akane",
    STAGE_OPEN_SHINKU_BURST: "Shinku",
    STAGE_LOOP_IROI_E: "Iroi",
    STAGE_LOOP_AKANE_EQ: "Akane",
    STAGE_LOOP_ELYMS_EQ: "Elyms",
    STAGE_LOOP_IROI_QZ: "Iroi",
    STAGE_LOOP_AKANE_Q2: "Akane",
    STAGE_LOOP_SHINKU_BURST: "Shinku",
}

OPENING_STAGES = [
    STAGE_OPEN_SHINKU_PASS,
    STAGE_OPEN_AKANE_Q1,
    STAGE_OPEN_ELYMS_EQ,
    STAGE_OPEN_IROI_EQZ,
    STAGE_OPEN_AKANE_Q2,
    STAGE_OPEN_SHINKU_BURST,
]

LOOP_STAGES = [
    STAGE_LOOP_IROI_E,
    STAGE_LOOP_AKANE_EQ,
    STAGE_LOOP_ELYMS_EQ,
    STAGE_LOOP_IROI_QZ,
    STAGE_LOOP_AKANE_Q2,
    STAGE_LOOP_SHINKU_BURST,
]

EXPECTED_ROLES = ("Shinku", "Akane", "Elyms", "Iroi")
ROTATION_VERSION = "v1.0.52"  # +1：4 个 entry 加 stage is None 早退 + Q3-Q5 pacing


def diag_sleep(char, label, duration, checks=None):
    if duration <= 0:
        return
    start = char.clock.now()
    if checks is not None:
        char.sleep(duration, checks=checks)
    else:
        char.sleep(duration, checks=char.SleepChecks.NONE)
    actual = char.clock.now() - start
    if actual - duration > 0.15:
        char.logger.info(f"[诊断·sleep] {label} 设{duration:.2f} 实{actual:.2f} 超时")


def wait_sound_idle(char, max_wait=0.1, poll=0.03, label=""):
    try:
        from src.sound_trigger.SoundCombatContext import SoundCombatContext
    except Exception:
        return

    def _active():
        try:
            return bool(SoundCombatContext.should_interrupt_combat())
        except Exception:
            return False

    if not _active():
        return

    start = char.clock.now()
    waited = False
    while char.clock.now() - start < max_wait:
        if not _active():
            return
        waited = True
        char.sleep(poll, checks=char.SleepChecks.SOUND)
    if waited:
        char.logger.warning(f"[诊断·sound静默超时] {label} 等{char.clock.now()-start:.2f}s仍活跃")


def sound_action_stamp():
    try:
        from src.sound_trigger.SoundCombatContext import SoundCombatContext
        ctx = SoundCombatContext()
        listener = getattr(ctx, "listener", None)
        return (getattr(listener, "_last_trigger_time", 0.0),) if listener else (0.0,)
    except Exception:
        return (0.0,)


def sound_action_changed(stamp):
    return sound_action_stamp() != stamp


def _log_send_state(char, label, phase, kind):
    try:
        avail = char.ultimate_available() if kind == "ultimate" else char.skill_available()
    except Exception:
        avail = "err"
    char.logger.info(f"[诊断·{phase}] {label} avail={avail}")


def diag_send_skill(char, label, down_time=0.05, after_sleep=0.05, check_time_out=0.5):
    _log_send_state(char, label, "E发前", "skill")
    char.send_skill_key(down_time=down_time, action_name=f"diag_{label}")
    if after_sleep > 0:
        char.sleep(after_sleep, checks=char.SleepChecks.NONE)
    unavailable = False
    try:
        unavailable = bool(char.task.wait_until(
            lambda: not char.skill_available(),
            time_out=check_time_out,
            raise_if_not_found=False,
        ))
    except Exception as e:
        err_name = type(e).__name__
        if err_name in ("TaskDisabledException", "NotInCombatException"):
            raise
        char.logger.warning(f"[诊断·吞] {label} 等待技能状态异常: {e}")
    _log_send_state(char, label, "E发后", "skill")
    if not unavailable:
        char.logger.warning(f"[诊断·吞] {label} E 发键后 {check_time_out}s 仍可用，可能被吞")
        return False
    return True


def log_before_click(char, label, kind):
    _log_send_state(char, label, f"{kind.upper()}点击前", kind)


def log_after_click(char, label, kind):
    _log_send_state(char, label, f"{kind.upper()}点击后", kind)


def _detect_missing_roles(task):
    present = {type(c).__name__ for c in task.chars if c is not None}
    return [r for r in EXPECTED_ROLES if r not in present]


class ShinkuRotation:
    VERSION = ROTATION_VERSION

    def __init__(self):
        self.queue = []
        self._boss_approached = False
        self._battle_end_session = None
        self.reset()

    def reset(self, new_battle=False):
        self.queue = list(OPENING_STAGES)
        self._battle_end_session = None
        if new_battle:
            self._boss_approached = False

    def current_stage(self):
        return self.queue[0] if self.queue else None

    def current_owner(self):
        return STAGE_OWNER.get(self.current_stage(), "") if self.current_stage() else ""

    def stage_for(self, char):
        stage = self.current_stage()
        if stage and STAGE_OWNER.get(stage) == type(char).__name__:
            return stage
        return None

    def advance(self):
        if self.queue:
            self.queue.pop(0)
        if not self.queue:
            self.queue = list(LOOP_STAGES)


ROTATION_ATTR = "shinku_wheelchair_rotation"


def get_rotation(task):
    rotation = getattr(task, ROTATION_ATTR, None)
    if rotation is None or getattr(rotation, "VERSION", None) != ROTATION_VERSION:
        rotation = ShinkuRotation()
        setattr(task, ROTATION_ATTR, rotation)
        task.find_element_reaction_target = lambda source_char: None
    return rotation


def find_teammate(char, owner_name):
    for t in char.task.chars:
        if t is not None and type(t).__name__ == owner_name:
            return t
    return None


def advance_rotation(char, rotation):
    old_stage = rotation.current_stage()

    if old_stage == STAGE_OPEN_SHINKU_PASS and type(char).__name__ != "Shinku":
        shinku = find_teammate(char, "Shinku")
        if shinku is not None and not shinku.is_dead:
            char.logger.info(f"[排轴] 首切真红过场：{type(char).__name__} 请求切到 Shinku（不推进阶段）")
            try:
                char.task.next_frame()
            except Exception:
                pass
            char.combat_context.request_switch(shinku, reason="首切真红过场")
            return
        char.logger.warning(f"[排轴] 首切真红过场：Shinku 已死，跳过 {old_stage}")

    rotation.advance()

    max_skip = len(OPENING_STAGES) + len(LOOP_STAGES)
    for _ in range(max_skip):
        target_name = rotation.current_owner()
        target = find_teammate(char, target_name) if target_name else None
        if target is not None and not target.is_dead:
            break
        if target is None and target_name in EXPECTED_ROLES:
            char.logger.warning(f"[排轴跳过] {rotation.current_stage()} owner={target_name} 找不到，跳过")
        else:
            char.logger.warning(f"[排轴跳过] {rotation.current_stage()} owner={target_name} 已死或不存在，跳过")
        rotation.advance()
    else:
        char.logger.warning("[排轴警告] 所有阶段 owner 都已死亡或缺失，重置轴到启动轴")
        rotation.reset()
        return

    target_name = rotation.current_owner()
    target = find_teammate(char, target_name)
    char.logger.info(f"[排轴推进] {type(char).__name__} 完成 {old_stage} -> 推进至 {rotation.current_stage()}")

    if target is char:
        char.logger.info(f"[排轴推进] 下一阶段仍为 {target_name}，原地继续")
        return

    try:
        char.task.next_frame()
    except Exception:
        pass
    char.combat_context.request_switch(target, reason=f"wheelchair -> {rotation.current_stage()}")


class RotationInput:
    E_TO_Q_SLEEP = 0.3
    AKANE_E_TO_Q_SLEEP = 0.5
    IROI_E_TO_Q_SLEEP = 0.5
    INTRO_SETTLE_SLEEP = 1.0
    ULTIMATE_FREEZE_MAX = 1.5

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.planner_handles_arc = True

    def _on_self_dead(self, rotation):
        """默认阵亡处理：跳过当前 stage，由下一个活着的角色接手。
        主C（真红）会重写为 reset 行为。"""
        self.logger.warning(
            f"[{type(self).__name__}] 阵亡于 {rotation.current_stage()}，跳过该 stage"
        )
        advance_rotation(self, rotation)

    def wait_intro(self, time_out=-1, click=False):
        if not self.has_intro:
            return
        self.sleep(self.INTRO_SETTLE_SLEEP, checks=self.SleepChecks.COMBAT)

    def _wait_ultimate_unfreeze(self, start, click=False):
        from src.Labels import Labels
        from src.utils import game_filters as gf

        post_action = (lambda: self.click(action_name="ultimate_click", interval=0.25)) if click else None

        if self.ultimate_freeze_wait is not None:
            wait = self.ultimate_freeze_wait
            if click:
                self.continues_normal_attack(wait)
            else:
                self.sleep(wait, checks=self.SleepChecks.NONE)
            duration = self.clock.now() - start
            self.add_freeze_duration(start, duration)
            return duration

        self.task.wait_until(lambda: self.has_cd("ultimate"), post_action=post_action, time_out=1)
        box_ultimate = self.task.get_box_by_name(Labels.box_ultimate)
        snapshot = box_ultimate.crop_frame(self.task.frame)
        processed_snapshot = gf.isolate_text_to_black(snapshot)

        def condition():
            if not self.task.find_one(
                Labels.box_ultimate, template=processed_snapshot, box=box_ultimate.scale(1.1, 1.1),
                frame_processor=gf.isolate_text_to_black, threshold=0.9
            ):
                self.logger.info("ultimate unfreeze cause cd changed")
                return True
            elif not self.available("ultimate", check_cd=False):
                self.logger.info("ultimate unfreeze cause ultimate not available")
                return True

        self.task.wait_until(condition, time_out=2, post_action=post_action)
        duration = self.clock.now() - start
        self.add_freeze_duration(start, min(duration, self.ULTIMATE_FREEZE_MAX))
        return duration

    def click_with_interval(self, interval=0.1):
        return False

    def refresh_frame(self):
        try:
            self.task.next_frame()
        except Exception:
            pass

    def _ensure_in_combat(self, is_burst=False):
        if getattr(self.task, "in_animation", False):
            return
        if not getattr(self.task, "_in_combat", True):
            if is_burst:
                self.logger.warning("爆发期检测到脱战，但允许继续执行当前动作")
                return
            self.task.raise_not_in_combat("wheelchair loop detected not in combat")

    def _install_switch_diag(self):
        task = self.task
        if getattr(task, "_wheelchair_switch_diag_installed", False):
            return
        task._wheelchair_switch_diag_installed = True

        logger = self.logger
        stats = {
            "next_frame_count": 0, "next_frame_total": 0.0,
            "health_changed_count": 0, "health_changed_total": 0.0,
            "index_check_count": 0, "index_check_total": 0.0,
            "is_in_team_count": 0, "is_in_team_total": 0.0,
        }

        original_next_frame = task.next_frame
        def timed_next_frame(*args, **kwargs):
            start = task.clock.now()
            try:
                return original_next_frame(*args, **kwargs)
            finally:
                stats["next_frame_count"] += 1
                stats["next_frame_total"] += task.clock.now() - start
        task.next_frame = timed_next_frame

        original_health_changed = getattr(task, "is_health_changed", None)
        if original_health_changed is not None:
            def timed_health_changed(*args, **kwargs):
                start = task.clock.now()
                try:
                    return original_health_changed(*args, **kwargs)
                finally:
                    stats["health_changed_count"] += 1
                    stats["health_changed_total"] += task.clock.now() - start
            task.is_health_changed = timed_health_changed

        original_index_check = getattr(task, "is_char_at_index", None)
        if original_index_check is not None:
            def timed_index_check(*args, **kwargs):
                start = task.clock.now()
                try:
                    return original_index_check(*args, **kwargs)
                finally:
                    stats["index_check_count"] += 1
                    stats["index_check_total"] += task.clock.now() - start
            task.is_char_at_index = timed_index_check

        original_is_in_team = task.is_in_team
        def timed_is_in_team(*args, **kwargs):
            start = task.clock.now()
            try:
                return original_is_in_team(*args, **kwargs)
            finally:
                stats["is_in_team_count"] += 1
                stats["is_in_team_total"] += task.clock.now() - start
        task.is_in_team = timed_is_in_team

        original_switch = task._switch_to_char

        def patched_switch(*args, **kwargs):
            for k in list(stats.keys()):
                stats[k] = 0 if "count" in k else 0.0
            start = task.clock.now()
            decision = kwargs.get("decision") or (args[0] if args else None)
            target = getattr(decision, "target", None)
            target_name = getattr(target, "ufn_name", "?") if target else "?"
            try:
                return original_switch(*args, **kwargs)
            finally:
                duration = task.clock.now() - start
                if duration > 0.8:
                    logger.warning(
                        f"[切换诊断] -> {target_name} 耗时 {duration:.2f}s "
                        f"next_frame={stats['next_frame_count']}次/{stats['next_frame_total']:.2f}s "
                        f"health_changed={stats['health_changed_count']}次/{stats['health_changed_total']:.2f}s "
                        f"index_check={stats['index_check_count']}次/{stats['index_check_total']:.2f}s "
                        f"is_in_team={stats['is_in_team_count']}次/{stats['is_in_team_total']:.2f}s"
                    )

        task._switch_to_char = patched_switch

    def switch_next_char(self, post_action=None, free_intro=False):
        task = self.task
        self._install_switch_diag()
        original_click = task.click
        had_override = "click" in vars(task)

        def switch_click(*args, **kwargs):
            if kwargs.get("action_name") == "switch_char_click":
                return False
            return original_click(*args, **kwargs)

        def after_switch(target, has_intro):
            target.has_intro = has_intro and task.can_element_react(self, target)
            if post_action:
                post_action(target, target.has_intro)

        task.click = switch_click
        try:
            return super().switch_next_char(post_action=after_switch, free_intro=free_intro)
        finally:
            if had_override:
                task.click = original_click
            else:
                try:
                    del task.click
                except AttributeError:
                    pass

    def _retry_block(self, name, block_func, max_attempts=2, not_in_combat_retry=True):
        not_in_combat_retried = False
        for attempt in range(max_attempts + 1):
            if attempt > 0:
                self.logger.warning(f"[{name}] 第 {attempt} 次重试")
                if not self.is_current_char or getattr(self.task, "combat_detect_uncertain", False):
                    diag_sleep(self, f"{name}重试前", 0.1, checks=self.SleepChecks.COMBAT)
                else:
                    diag_sleep(self, f"{name}重试前", 0.15, checks=self.SleepChecks.NONE)
            if self.is_dead:
                self.logger.warning(f"[{name}] 角色阵亡，终止")
                return False
            try:
                if block_func():
                    return True
            except Exception as e:
                err_name = type(e).__name__
                if err_name == "TaskDisabledException":
                    raise
                if err_name == "NotInCombatException":
                    if not not_in_combat_retry:
                        raise
                    if not_in_combat_retried:
                        self.logger.warning(f"[{name}] 重试后再次脱战，向外抛出: {e}")
                        raise
                    not_in_combat_retried = True
                    self.logger.warning(f"[{name}] 瞬时脱战，尝试等待战斗恢复（Boss 飞天/转阶段）: {e}")
                    try:
                        recovered = self.task.wait_until(
                            self.task.in_combat, time_out=3.0, raise_if_not_found=False
                        )
                    except Exception as we:
                        self.logger.warning(f"[{name}] 等待战斗恢复异常: {we}")
                        recovered = False
                    if not recovered:
                        self.logger.warning(f"[{name}] 战斗未恢复，向外抛出")
                        raise
                    self.logger.info(f"[{name}] 战斗已恢复，准备重试")
                else:
                    self.logger.warning(f"[{name}] 执行异常（{err_name}），准备重试: {e}")
        if not_in_combat_retried:
            self.task.raise_not_in_combat(f"{name} 重试用尽且期间发生过脱战")
        return False


class Shinku(RotationInput, StockShinku):
    cn_name = "真红"
    en_name = "Shinku"

    ENABLE_APPROACH_BOSS = True
    APPROACH_W_PRESS_WAIT = 0.1
    APPROACH_DODGE_INTERVAL = 0.2
    APPROACH_DODGE_DOWN_TIME = 0.1
    APPROACH_DODGE_KEY = "lshift"
    APPROACH_FORWARD_KEY = "w"
    APPROACH_FINAL_WAIT = 0.1
    APPROACH_MOUSE_RELEASE_WAIT = 0.05

    ENGAGE_TIMEOUT = 10.0
    ENGAGE_INITIAL_SETTLE = 0.3
    LOOP_ENGAGE_TIMEOUT = 12.0
    BURST_WINDOW = 16.0

    BURST_E_MAX_COUNT = 5
    BURST_E_MAX_RETRY = 2
    BURST_E_FAIL_LIMIT = 2
    BURST_E_POST_SLEEP = 0.3
    BURST_E_RETRY_DELAY = 0.1
    BURST_ATTACK_INTERVAL = 0.15
    BURST_ATTACK_SLEEP = 0.05

    Q1_ANIMATION_WAIT = 1.2
    Q2_ANIMATION_WAIT = 0.3
    QREST_ANIMATION_WAIT = 0.3
    Q2_SETTLE = 0.5
    Q2_RETRY = 1

    ENGAGE_FULL_STREAK_REQUIRED = 3
    ENGAGE_FULL_DIAG_INTERVAL = 0.2

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.MAIN_DPS,
            field_preference=Planner.FieldPreference.MAIN_DPS,
            max_field_time=0,
            combat_start_priority=100,
        )

    def _on_self_dead(self, rotation):
        """主C阵亡：重置轴到启动阶段；下一个进场的角色会通过 advance 跳过死去的真红。"""
        self.logger.warning(
            f"[真红] 阵亡于 {rotation.current_stage()}，主C重置轴到启动阶段"
        )
        rotation.reset()

    def _wait_ultimate_unfreeze(self, start, click=False):
        if getattr(self, "_is_q1", False):
            self.sleep(self.Q1_ANIMATION_WAIT, checks=self.SleepChecks.NONE)
            duration = self.clock.now() - start
            self.add_freeze_duration(start, duration)
            return duration
        if getattr(self, "_is_q2", False):
            self.sleep(self.Q2_ANIMATION_WAIT, checks=self.SleepChecks.NONE)
            duration = self.clock.now() - start
            self.add_freeze_duration(start, duration)
            return duration
        if getattr(self, "_is_q_rest", False):
            self.sleep(self.QREST_ANIMATION_WAIT, checks=self.SleepChecks.NONE)
            duration = self.clock.now() - start
            self.add_freeze_duration(start, duration)
            return duration
        return super()._wait_ultimate_unfreeze(start=start, click=click)

    def _install_start_hooks(self):
        task = self.task
        if getattr(task, "_wheelchair_hooks_installed", False):
            return
        task._wheelchair_hooks_installed = True

        original_click = task.click
        def patched_click(*args, **kwargs):
            if getattr(task, "_wheelchair_skip_start_click", False):
                self.logger.info("[首切] 拦截开场多余点击，防止普攻")
                return False
            return original_click(*args, **kwargs)
        task.click = patched_click

        original_begin = task.begin_combat_session
        def patched_begin():
            if task.combat_session.start_char is not None:
                return original_begin()
            task._wheelchair_skip_start_click = True
            try:
                return original_begin()
            finally:
                task._wheelchair_skip_start_click = False
        task.begin_combat_session = patched_begin

        original_switch = task.switch_to_combat_start_char
        logger = self.logger
        def patched_switch():
            if not task.combat_session.switch_enabled:
                return original_switch()
            try:
                current_char = task.get_current_char(raise_exception=False)
                decision = task.combat_planner.decide_combat_start_char(current_char)
                switch_to = decision.target
                if switch_to is None or current_char == switch_to:
                    return

                new_decision = decision
                if dataclasses.is_dataclass(decision) and not isinstance(decision, type):
                    new_decision = dataclasses.replace(decision, has_intro=False)
                else:
                    try:
                        object.__setattr__(decision, "has_intro", False)
                    except Exception:
                        decision.has_intro = False

                logger.info(f"[首切] 强制无援护 -> {switch_to} (原 has_intro={decision.has_intro})")
                task._switch_to_char(
                    new_decision,
                    current_char=current_char,
                    log_prefix="planner combat start (no-intro)",
                )
            except Exception as e:
                logger.warning(f"[首切] hook 异常回退: {e}")
                return original_switch()

        task.switch_to_combat_start_char = patched_switch

    def _approach_boss(self):
        if self.is_dead or not self.ENABLE_APPROACH_BOSS:
            return
        rotation = get_rotation(self.task)
        if getattr(rotation, "_boss_approached", False):
            return

        try:
            self.task.mouse_up("left")
        except Exception:
            pass
        if self.APPROACH_MOUSE_RELEASE_WAIT > 0:
            diag_sleep(self, "首切·清残留", self.APPROACH_MOUSE_RELEASE_WAIT)

        self.logger.info("[真红] 首切接近BOSS：按住W + 闪避")
        try:
            self.task.send_key_down(self.APPROACH_FORWARD_KEY)
        except Exception as e:
            self.logger.error(f"[真红] send_key_down 失败：{e}")
            return
        try:
            diag_sleep(self, "首切·W预热", self.APPROACH_W_PRESS_WAIT)
            if self.is_dead: return
            self.send_key(self.APPROACH_DODGE_KEY, down_time=self.APPROACH_DODGE_DOWN_TIME)
            diag_sleep(self, "首切·闪避1后", self.APPROACH_DODGE_INTERVAL)
            if self.is_dead: return
            self.send_key(self.APPROACH_DODGE_KEY, down_time=self.APPROACH_DODGE_DOWN_TIME)
            diag_sleep(self, "首切·闪避2后收尾", self.APPROACH_FINAL_WAIT)
        finally:
            try:
                self.task.send_key_up(self.APPROACH_FORWARD_KEY)
            except Exception:
                pass
        rotation._boss_approached = True

    def _open_engage(self):
        if self.is_dead:
            return False
        self._ensure_in_combat()
        if self.skill_available():
            log_before_click(self, "真红首切E", "skill")
            self.click_skill(send_click=False, down_time=0.05)
            log_after_click(self, "真红首切E", "skill")

        if self.ENGAGE_INITIAL_SETTLE > 0:
            self.sleep(self.ENGAGE_INITIAL_SETTLE, checks=self.SleepChecks.COMBAT)

        start = self.clock.now()
        full_streak = 0
        last_diag_time = start
        while self.clock.now() - start < self.ENGAGE_TIMEOUT:
            if self.is_dead:
                return False
            self._ensure_in_combat()
            full = self.is_cycle_full()
            if full:
                full_streak += 1
            else:
                full_streak = 0
            elapsed = self.clock.now() - start
            if self.clock.now() - last_diag_time >= self.ENGAGE_FULL_DIAG_INTERVAL:
                self.logger.info(
                    f"[首切诊断] {elapsed:.2f}s cycle_full={full} streak={full_streak}"
                )
                last_diag_time = self.clock.now()
            if full_streak >= self.ENGAGE_FULL_STREAK_REQUIRED:
                self.logger.info(f"[首切诊断] 确认满环合 耗时={elapsed:.2f}s")
                return True
            self.check_combat()
            self.click(interval=self.BURST_ATTACK_SLEEP)
            if self.is_dead:
                return False
            self.sleep(self.BURST_ATTACK_SLEEP, checks=self.SleepChecks.COMBAT)
        self.logger.warning(f"[真红首切] 打满环合超时 {self.ENGAGE_TIMEOUT}s")
        return False

    def _send_e_burst(self):
        for attempt in range(1, self.BURST_E_MAX_RETRY + 1):
            if attempt > 1 and self.ultimate_available():
                self.logger.warning("[真红爆发] E 补发前 Q2 已亮，放弃 E，转 Q2")
                return False
            label = "真红爆发E" if attempt == 1 else f"真红爆发E补发{attempt-1}"
            ok = diag_send_skill(self, label, down_time=0.05, after_sleep=self.BURST_E_POST_SLEEP)
            if ok:
                return True
            self.logger.warning(f"[真红爆发] {label} 被吞，等 {self.BURST_E_RETRY_DELAY}s")
            self.sleep(self.BURST_E_RETRY_DELAY, checks=self.SleepChecks.NONE)
        return False

    def _open_burst(self):
        if self.is_dead:
            return False
        self._ensure_in_combat(is_burst=True)
        if not self.ultimate_available():
            self.logger.warning("[真红爆发] Q 能量不足，跳过")
            return False

        # --- Q1：click_ultimate + _is_q1 固定 1.2s ---
        log_before_click(self, "真红爆发Q1", "ultimate")
        self._is_q1 = True
        try:
            self.click_ultimate(send_click=False)
        finally:
            self._is_q1 = False
        log_after_click(self, "真红爆发Q1", "ultimate")

        # --- E 连发到 Q2 亮：AEAEAEAEAEA，E 没好就高频普攻 ---
        start = self.clock.now()
        e_count, e_fail_streak, q2_ready = 0, 0, False
        e_max_logged = False

        while self.clock.now() - start < self.BURST_WINDOW:
            if self.is_dead: return False
            self._ensure_in_combat(is_burst=True)

            if self.ultimate_available():
                self.logger.info(f"[真红爆发] Q2 亮（{self.clock.now() - start:.2f}s），转 Q2-Q5（E={e_count}）")
                q2_ready = True
                break

            if e_count >= self.BURST_E_MAX_COUNT:
                if not e_max_logged:
                    self.logger.info(f"[真红爆发] E 已打满（E={e_count}），Q2 未亮，转为普攻等待")
                    e_max_logged = True
                self.click(interval=self.BURST_ATTACK_INTERVAL)
                self.sleep(self.BURST_ATTACK_INTERVAL, checks=self.SleepChecks.NONE)
                continue

            if e_fail_streak >= self.BURST_E_FAIL_LIMIT:
                if e_count > 0:
                    if not e_max_logged:
                        self.logger.info(f"[真红爆发] E 连续失败 {e_fail_streak} 次且已打出 {e_count} 个，视为打满，转为普攻等待")
                        e_max_logged = True
                    self.click(interval=self.BURST_ATTACK_INTERVAL)
                    self.sleep(self.BURST_ATTACK_INTERVAL, checks=self.SleepChecks.NONE)
                    continue
                else:
                    self.logger.warning(
                        f"[真红爆发] E 连续失败 {e_fail_streak} 次且 E=0，可能是 Q1 后摇导致，重置失败计数重试"
                    )
                    e_fail_streak = 0
                    self.click(interval=self.BURST_ATTACK_INTERVAL)
                    self.sleep(0.3, checks=self.SleepChecks.NONE)
                    continue

            if self.skill_available():
                if self._send_e_burst():
                    e_count += 1
                    e_fail_streak = 0
                    self.logger.info(f"[真红爆发] E #{e_count}/{self.BURST_E_MAX_COUNT}")
                else:
                    e_fail_streak += 1
                    self.logger.warning(f"[真红爆发] E 未放出，连续失败={e_fail_streak}，实际 E={e_count}")
                    self.sleep(0.1, checks=self.SleepChecks.NONE)
                continue

            self.click(interval=self.BURST_ATTACK_SLEEP)
            self.sleep(self.BURST_ATTACK_SLEEP, checks=self.SleepChecks.NONE)

        if not q2_ready:
            self.logger.warning(f"[真红爆发] 窗口 {self.BURST_WINDOW}s 结束 Q2 仍未亮，E={e_count}")
            return False

        # --- Q2 前稳定 ---
        if self.Q2_SETTLE > 0:
            diag_sleep(self, "真红Q2前稳定", self.Q2_SETTLE, checks=self.SleepChecks.NONE)

        # --- Q2：click_ultimate + _is_q2 固定 0.3s + 重试 ---
        self._is_q2 = True
        try:
            attempt = 0
            while attempt <= self.Q2_RETRY:
                attempt += 1
                log_before_click(self, "真红Q2", "ultimate")
                self.click_ultimate(send_click=False)
                log_after_click(self, "真红Q2", "ultimate")
                try:
                    avail_after = self.ultimate_available()
                except Exception:
                    avail_after = None
                if avail_after is False or avail_after is None:
                    break
                if attempt <= self.Q2_RETRY:
                    diag_sleep(self, "真红Q2重试前", 0.1, checks=self.SleepChecks.NONE)
                else:
                    self.logger.warning("[真红爆发] Q2 重试用尽仍可用，跳过")
                    break
        finally:
            self._is_q2 = False

        # --- Q3-Q5：click_ultimate + _is_q_rest 固定 0.3s ---
        self._is_q_rest = True
        try:
            for q_index in range(3, 6):
                if self.is_dead: return False
                self._ensure_in_combat(is_burst=True)
                log_before_click(self, f"真红Q{q_index}", "ultimate")
                self.click_ultimate(send_click=False)
                log_after_click(self, f"真红Q{q_index}", "ultimate")
                self.sleep(0.05, checks=self.SleepChecks.NONE)
        finally:
            self._is_q_rest = False

        self.logger.info(f"[真红爆发] 完成 E={e_count} Q2-Q5 已发 耗时={self.clock.now() - start:.2f}s")
        return True

    def _loop_burst(self):
        if self.is_dead:
            return False
        self._ensure_in_combat()

        # 先判断 Q：就绪直接爆发，不放站场 E，避免浪费 E CD
        if self.ultimate_available():
            return self._open_burst()
    
        if self.skill_available():
            log_before_click(self, "真红站场E", "skill")
            self.click_skill(send_click=False, down_time=0.05)
            log_after_click(self, "真红站场E", "skill")

        start = self.clock.now()
        def _ready():
            return self.ultimate_available()

        while self.clock.now() - start < self.LOOP_ENGAGE_TIMEOUT:
            if self.is_dead: return False
            self._ensure_in_combat()
            if _ready(): return self._open_burst()
            self.check_combat()
            self.click(interval=self.BURST_ATTACK_SLEEP)
            self.sleep(self.BURST_ATTACK_SLEEP, checks=self.SleepChecks.COMBAT)
            if self.is_dead: return False
            if _ready(): return self._open_burst()
            if self.skill_available():
                log_before_click(self, "真红站场E再发", "skill")
                self.click_skill(send_click=False, down_time=0.05)
                log_after_click(self, "真红站场E再发", "skill")
                if _ready(): return self._open_burst()
        self.logger.warning(f"[真红站场] 等待Q可用超时 {self.LOOP_ENGAGE_TIMEOUT}s")
        return False

    def combat_policies(self):
        rotation = get_rotation(self.task)
        current_session = getattr(self.task, "combat_session", None)
        end_session = getattr(rotation, "_battle_end_session", None)

        if end_session is not None and current_session is not end_session:
            rotation.reset(new_battle=True)
            self.logger.info("[排轴] 新战斗（session 变更），重置到启动轴")
        elif end_session is not None:
            self.logger.info(f"[排轴] 脱战重开（session 未变），保持 stage={rotation.current_stage()}")
        else:
            rotation.reset(new_battle=True)
            self.logger.info("[排轴] 无上次战斗记录，重置到启动轴")

        missing = _detect_missing_roles(self.task)
        if missing:
            self.logger.warning(f"[排轴警告] 队伍缺失角色 {missing}，可能识别为 BaseChar，对应阶段将被跳过")

        self._install_start_hooks()
        self.task.find_element_reaction_target = lambda source_char: None

    def on_combat_end(self, chars):
        rotation = get_rotation(self.task)
        rotation._battle_end_session = getattr(self.task, "combat_session", None)
        self.logger.info("[排轴] 战斗结束，记录 session")
        super().on_combat_end(chars)

    def combat_plan(self):
        rotation = get_rotation(self.task)

        def entry():
            stage = rotation.stage_for(self)
            self.logger.info(f"[真红入场] 阶段={stage}")
            if self.is_dead:
                self._on_self_dead(rotation)
                return

            # 非本角色阶段：队列头是别人，等待切人，不推进队列
            if stage is None:
                current_owner_name = rotation.current_owner()
                current_owner = find_teammate(self, current_owner_name) if current_owner_name else None
                if current_owner is None or current_owner.is_dead:
                    self.logger.warning(
                        f"[真红] 队列头 {current_owner_name} 已死或不存在，跳过"
                    )
                    advance_rotation(self, rotation)
                else:
                    self.logger.info(
                        f"[真红] 当前非本角色阶段"
                        f"（{rotation.current_stage()}），等待切人"
                    )
                return

            try:
                if stage == STAGE_OPEN_SHINKU_PASS:
                    self._approach_boss()
                    if not self.is_dead:
                        self._retry_block("真红首切E+打满环合", self._open_engage, max_attempts=2)
                elif stage == STAGE_OPEN_SHINKU_BURST:
                    self._retry_block("真红启动爆发", self._open_burst, max_attempts=2)
                elif stage == STAGE_LOOP_SHINKU_BURST:
                    self._retry_block("真红循环爆发", self._loop_burst, max_attempts=2)
                else:
                    self.logger.warning(f"[真红异常] 阶段={stage}，直接切人")
            except Exception as e:
                err_name = type(e).__name__
                if err_name == "TaskDisabledException":
                    raise
                if err_name == "NotInCombatException":
                    self.logger.warning("[真红] 脱战，向外抛出")
                    raise
                self.logger.error(f"[真红异常] {err_name}: {e}")

            if self.is_dead:
                self._on_self_dead(rotation)
                return
            advance_rotation(self, rotation)

        return self.plan(entry=entry)


TEAM_MODULE_KEY = "_shinku_wheelchair_team_module"
try:
    from pathlib import Path as _Path
    _TEAM_SOURCE_STAMP = _Path(__file__).resolve().stat().st_mtime_ns
except OSError:
    _TEAM_SOURCE_STAMP = None
sys.modules[TEAM_MODULE_KEY] = sys.modules[__name__]