import sys


def _load_team_module():
    import importlib.util
    from pathlib import Path
    key = "_shinku_wheelchair_team_module"
    team_path = Path(__file__).resolve().with_name("shinku.py")
    try: stamp = team_path.stat().st_mtime_ns
    except OSError: stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_OPEN_AKANE_Q1 = _team.STAGE_OPEN_AKANE_Q1
STAGE_OPEN_AKANE_Q2 = _team.STAGE_OPEN_AKANE_Q2
STAGE_LOOP_AKANE_EQ = _team.STAGE_LOOP_AKANE_EQ
STAGE_LOOP_AKANE_Q2 = _team.STAGE_LOOP_AKANE_Q2
get_rotation = _team.get_rotation
advance_rotation = _team.advance_rotation
find_teammate = _team.find_teammate
wait_sound_idle = _team.wait_sound_idle
RotationInput = _team.RotationInput
log_before_click = _team.log_before_click
log_after_click = _team.log_after_click

from src.char.Akane import Akane as StockAkane
from src.combat.planner import Planner, RoleProfile


class Akane(RotationInput, StockAkane):
    cn_name = "明音凛"
    en_name = "Akane"

    Q2_ENTRY_SETTLE = 0.1
    # E 等待就绪的最长时间 / 轮询间隔（修复"E 没放就 Q1"）
    AKANE_E_WAIT_TIMEOUT = 0.6
    AKANE_E_WAIT_POLL = 0.05

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_policies(self):
        self.in_ult_start = self.clock.UNSET
        self.skill_2_count = 0

    def _cast_e(self):
        if self.is_dead: return False
        # 轮询等待 E 就绪（入场首帧未就绪 / 上轮 CD 差一点 / 发键被吞）
        start = self.clock.now()
        while True:
            self.refresh_frame()
            if self.skill_available():
                break
            if self.clock.now() - start >= self.AKANE_E_WAIT_TIMEOUT:
                self.logger.warning(
                    f"[明音凛] E 等待 {self.AKANE_E_WAIT_TIMEOUT}s 仍不可用，跳过 E（仍会放 Q1）"
                )
                return False
            self.sleep(self.AKANE_E_WAIT_POLL, checks=self.SleepChecks.NONE)

        wait_sound_idle(self, label="明音凛·E发键前", max_wait=0.1)
        log_before_click(self, "明音凛E", "skill")
        ok = self.click_skill(send_click=False, down_time=0.05)
        log_after_click(self, "明音凛E", "skill")
        return ok

    def _cast_q1(self):
        if self.is_dead or not self.ultimate_available(): return False
        wait_sound_idle(self, label="明音凛·Q1发键前", max_wait=0.1)
        log_before_click(self, "明音凛Q1", "ultimate")
        ok = self.click_ultimate(send_click=False)
        log_after_click(self, "明音凛Q1", "ultimate")
        if ok:
            self.in_ult_start = self.clock.now()
        return ok

    def _cast_q2(self):
        if self.is_dead: return False
        self.refresh_frame()
        if self.Q2_ENTRY_SETTLE > 0:
            self.sleep(self.Q2_ENTRY_SETTLE, checks=self.SleepChecks.NONE)
            self.refresh_frame()

        if not self.in_ult():
            self.logger.warning("[明音凛] Q2 时已不在华彩连段")
        if not self.ultimate_available():
            return False

        wait_sound_idle(self, label="明音凛·Q2发键前", max_wait=0.1)
        log_before_click(self, "明音凛Q2", "ultimate")
        ok = self.click_ultimate(send_click=False)
        log_after_click(self, "明音凛Q2", "ultimate")
        if ok:
            self.in_ult_start = self.clock.UNSET
        return ok

    def _stage_e_q1(self):
        # E 失败也放 Q1（用户确认：Q1 双段第一段先放不吃亏，E 下轮补）
        self._cast_e()
        self.sleep(self.AKANE_E_TO_Q_SLEEP, checks=self.SleepChecks.COMBAT)
        return self._cast_q1()

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        if self.is_dead:
            self._on_self_dead(rotation)
            return

        # 非本角色阶段：队列头是别人，等待切人，不推进队列
        if stage is None:
            current_owner_name = rotation.current_owner()
            current_owner = find_teammate(self, current_owner_name) if current_owner_name else None
            if current_owner is None or current_owner.is_dead:
                self.logger.warning(
                    f"[明音凛] 队列头 {current_owner_name} 已死或不存在，跳过"
                )
                advance_rotation(self, rotation)
            else:
                self.logger.info(
                    f"[明音凛] 当前非本角色阶段"
                    f"（{rotation.current_stage()}），等待切人"
                )
            return

        try:
            if stage in (STAGE_OPEN_AKANE_Q1, STAGE_LOOP_AKANE_EQ):
                self._retry_block("明音凛E+Q1", self._stage_e_q1, max_attempts=2)
            elif stage in (STAGE_OPEN_AKANE_Q2, STAGE_LOOP_AKANE_Q2):
                self._retry_block("明音凛Q2", self._cast_q2, max_attempts=2)
        except Exception as e:
            err_name = type(e).__name__
            if err_name in ("TaskDisabledException", "NotInCombatException"):
                raise
            self.logger.error(f"[明音凛异常] {err_name}: {e}")

        advance_rotation(self, rotation)

    def combat_plan(self):
        return self.plan(entry=self.perform_entry)