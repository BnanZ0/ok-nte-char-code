import sys


def _load_team_module():
    import importlib.util
    from pathlib import Path
    key = "_shinku_wheelchair_team_module"
    team_path = Path(__file__).resolve().with_name("shinku.py")
    try: stamp = team_path.stat().st_mtime_ns
    except OSError: stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_OPEN_IROI_EQZ = _team.STAGE_OPEN_IROI_EQZ
STAGE_LOOP_IROI_E = _team.STAGE_LOOP_IROI_E
STAGE_LOOP_IROI_QZ = _team.STAGE_LOOP_IROI_QZ
get_rotation = _team.get_rotation
advance_rotation = _team.advance_rotation
find_teammate = _team.find_teammate
wait_sound_idle = _team.wait_sound_idle
RotationInput = _team.RotationInput
log_before_click = _team.log_before_click
log_after_click = _team.log_after_click

from src.char.Iroi import Iroi as StockIroi
from src.combat.planner import Planner, RoleProfile


class Iroi(RotationInput, StockIroi):
    cn_name = "伊洛伊"
    en_name = "Iroi"

    HEAVY_HOLD_DURATION = 0.8
    CANNON_ATTACK_COUNT = 1
    CANNON_SETTLE_TIME = 0.1
    Q_POST_SLEEP = 0.2
    Q_TO_Z_SLEEP = 0.15
    INTRO_SETTLE_SLEEP = 0.3

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def wait_intro(self, time_out=-1, click=False):
        self.sleep(self.INTRO_SETTLE_SLEEP, checks=self.SleepChecks.COMBAT)

    def click_ultimate(self, send_click=True, wait_if_no_cd=0):
        try:
            ret = super(StockIroi, self).click_ultimate(send_click=send_click, wait_if_no_cd=wait_if_no_cd)
            if ret: self.sleep(self.Q_POST_SLEEP)
            return ret
        finally:
            if self._mouse_pressed:
                self.task.mouse_up()
            self._mouse_pressed = False

    def _wait_ultimate_unfreeze(self, start, click=False):
        self.task.mouse_down()
        self._mouse_pressed = True
        return super()._wait_ultimate_unfreeze(start=start, click=click)

    def _cast_e(self):
        if self.is_dead: return False
        self.refresh_frame()
        if not self.skill_available(): return False
        wait_sound_idle(self, label="伊洛伊·E发键前", max_wait=0.1)
        log_before_click(self, "伊洛伊E", "skill")
        ok = self.click_skill(send_click=False, down_time=0.05)
        log_after_click(self, "伊洛伊E", "skill")
        return ok

    def _cast_q(self):
        if self.is_dead or not self.ultimate_available(): return False
        for attempt in range(1, 3):
            wait_sound_idle(self, label=f"伊洛伊·Q{attempt}发键前", max_wait=0.1)
            log_before_click(self, "伊洛伊Q", "ultimate")
            ok = self.click_ultimate(send_click=False)
            log_after_click(self, "伊洛伊Q", "ultimate")
            self.last_ultimate_time = self.clock.now()
            if ok: return True
            self.sleep(0.1, checks=self.SleepChecks.COMBAT)
        return False

    def _cast_z(self):
        if self.is_dead: return False
        wait_sound_idle(self, label="伊洛伊·Z开始前", max_wait=0.05)
        try:
            with self.task.skip_sleep_checks() as skip:
                skip.sound_combat_context = True
                self.task.mouse_down()
                self.sleep(self.HEAVY_HOLD_DURATION)
        finally:
            self.task.mouse_up()
        self.sleep(0.05, checks=self.SleepChecks.NONE)
        for i in range(self.CANNON_ATTACK_COUNT):
            if self.is_dead: return False
            self.logger.info(f"[伊洛伊] Z 浮空炮 {i+1}/{self.CANNON_ATTACK_COUNT}")
            self.check_combat()
            self.click(interval=self.CANNON_SETTLE_TIME)
            self.sleep(self.CANNON_SETTLE_TIME, checks=self.SleepChecks.NONE)
        return True

    def on_combat_end(self, chars):
        if getattr(self, "_mouse_pressed", False):
            try: self.task.mouse_up()
            except Exception: pass
            self._mouse_pressed = False
        super().on_combat_end(chars)

    def _stage_e_only(self):
        return self._cast_e()

    def _stage_e_q_z(self):
        self._cast_e()
        self.sleep(self.IROI_E_TO_Q_SLEEP, checks=self.SleepChecks.COMBAT)
        if not self._cast_q(): return False
        self.sleep(self.Q_TO_Z_SLEEP, checks=self.SleepChecks.NONE)
        return self._cast_z()

    def _stage_q_z(self):
        if not self._cast_q(): return False
        self.sleep(self.Q_TO_Z_SLEEP, checks=self.SleepChecks.NONE)
        return self._cast_z()

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        if self.is_dead:
            self._on_self_dead(rotation)
            return

        # 非本角色阶段：队列头是别人，等待切人，不推进队列
        if stage is None:
            current_owner_name = rotation.current_owner()
            current_owner = find_teammate(self, current_owner_name) if current_owner_name else None
            if current_owner is None or current_owner.is_dead:
                self.logger.warning(
                    f"[伊洛伊] 队列头 {current_owner_name} 已死或不存在，跳过"
                )
                advance_rotation(self, rotation)
            else:
                self.logger.info(
                    f"[伊洛伊] 当前非本角色阶段"
                    f"（{rotation.current_stage()}），等待切人"
                )
            return

        try:
            if stage == STAGE_OPEN_IROI_EQZ:
                self._retry_block("伊洛伊E-Q-Z", self._stage_e_q_z, max_attempts=2)
            elif stage == STAGE_LOOP_IROI_E:
                self._retry_block("伊洛伊E", self._stage_e_only, max_attempts=2)
            elif stage == STAGE_LOOP_IROI_QZ:
                self._retry_block("伊洛伊Q-Z", self._stage_q_z, max_attempts=2)
        except Exception as e:
            err_name = type(e).__name__
            if err_name in ("TaskDisabledException", "NotInCombatException"):
                raise
            self.logger.error(f"[伊洛伊异常] {err_name}: {e}")

        advance_rotation(self, rotation)

    def combat_plan(self):
        return self.plan(entry=self.perform_entry)