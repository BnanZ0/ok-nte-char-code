"""Community shield rotation for Adler."""

from src.char.Adler import Adler
from src.combat.planner import Planner, RoleProfile


class CommunityAdler(Adler):
    """优先部署护盾，按情况释放 Q，然后把前台交还给残虹。"""

    cn_name = "阿德勒（社区版）"
    en_name = "Adler (Community)"

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan, add_tags=Planner.ActionTag.TEAM_BUFF)
        self.register_ultimate(plan)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        if self.skill_available() and self.combat_context.is_slot_available(self, Planner.ActionSlot.SKILL):
            self.continues_normal_attack(1.5)
        if self.click_skill():
            self.sleep(0.5)
            self.click_ultimate()
