"""Community setup rotation for Daffodill."""

from src.char.Daffodill import Daffodill
from src.combat.planner import Planner, RoleProfile


class CommunityDaffodill(Daffodill):
    """首个 Q 最多充能六秒，亮起后立即释放并快速离场。"""

    cn_name = "达芙蒂尔（社区版）"
    en_name = "Daffodill (Community)"
    FIRST_Q_CHARGE_SECONDS = 6.0
    HEAVY_ATTACK_TIME = 0.45
    ULT_BURST_DURATION = 0.5

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._charge_session = None

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def _first_charge_pending(self):
        return self._charge_session is not getattr(self.task, "combat_session", None)

    def combat_plan(self):
        plan = self.plan()
        plan.register(
            self._charge_first_q,
            tags={Planner.ActionTag.SUPPORT, Planner.ActionTag.TEAM_BUFF},
            slot=Planner.ActionSlot.CUSTOM,
            name="community_daffodill_first_q",
            reason="达芙首 Q：最多 6 秒重击充能，亮起立即释放",
            can_execute=lambda: self._first_charge_pending() and not self.ultimate_available(),
            priority_ready=lambda: self._first_charge_pending() and not self.ultimate_available(),
        )
        self.register_ultimate(plan)
        self.register_skill(plan)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        if self.ultimate_available():
            if self.click_ultimate():
                self._charge_session = getattr(self.task, "combat_session", None)
                self._perform_burst()
                return
        if self._first_charge_pending():
            self._charge_first_q()
            return
        self.click_skill()

    def _charge_first_q(self):
        self._charge_session = getattr(self.task, "combat_session", None)
        timer = self.clock.timer(timeout=self.FIRST_Q_CHARGE_SECONDS)
        while not timer.expired() and not self.ultimate_available():
            self.heavy_attack(duration=self.HEAVY_ATTACK_TIME)
            self.sleep(0.05)
        if not self.ultimate_available():
            self.logger.info("community Daffodill: first-Q charge timed out")
            return False
        q_result = self.click_ultimate()
        if q_result:
            self._perform_burst()
        return bool(q_result)
