"""灵可 Linko（1觉残安早灵合轴队）。

排轴定位：伊洛伊位的纯增益辅助。
    · 不做输出连段（伊洛伊的 qza 段已删掉），只上增益；
    · 每轮只在循环头上场一次（首轮安魂曲 QE 之后不再切回灵可），
      E/Q 一起放：「有 E 放 E → 有 Q 放 Q → 切人前复检一次」；
      E（12s CD）/ Q（20s CD）都在 CD 时直接切走，不站场空转；
    · 交替合轴段的增益插入仍可能把灵可叫上场（走兜底分支，放完切回）；
    · E、Q 都是时停动画（E≈2s、Q≈4s）：由框架 has_animation / click_ultimate
      自动挂起等待并记账冻结时长，脚本不 sleep 固定时长。

通过共享模块（zankou.py）获取全队排轴状态机；本文件自身不持有状态机定义。
"""

import sys


def _load_team_module():
    """加载同目录 zankou.py 内的全队共享排轴状态机（模块级共享实例）。

    外置角色文件之间无法直接 import（注册器把每个文件按独立模块加载），
    这里通过固定的 sys.modules key 共享 zankou.py 的一份模块实例；
    按文件 mtime 失效缓存，zankou.py 更新并重新扫描后自动取到新代码。
    """
    import importlib.util
    from pathlib import Path

    key = "_aczy_zankou_lingke_team_module"
    team_path = Path(__file__).resolve().with_name("zankou.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
LINGKE_STAGES = _team.LINGKE_STAGES
get_rotation = _team.get_rotation
make_rotation_next_action = _team.make_rotation_next_action

from src.char.Support import Support
from src.combat.planner import Planner


class Linko(Support):
    cn_name = "灵可（合轴队）"
    en_name = "Linko (Team Rotation)"
    element = Support.ElementType.GREEN

    # 排轴时值（可按实测微调）
    SKILL_DOWN_TIME = 0.05        # E 按键按下时长
    SKILL_POST_CAST_SLEEP = 2     # E 按下后额外等待（时停由框架动画检测处理；切不进时上调）
    ULT_POST_CAST_SLEEP = 0.3       # Q 按下后额外等待（同上）

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def combat_plan(self, context):
        rotation = get_rotation(self.task)
        # Q：走内置终结技动作（自动等时停动画结束 + 记账冻结时长）
        ultimate = self.click_ultimate_action(add_tags=Planner.ActionTag.TEAM_BUFF)
        # E：内置 click_skill_action 不支持 has_animation，用自定义动作包一层，
        #    让时停动画（≈2s）由框架检测等待，而不是脚本盲 sleep。
        skill = self.planner_action(
            tags={
                Planner.ActionTag.SKILL_ACTION,
                Planner.ActionTag.SUPPORT,
                Planner.ActionTag.TEAM_BUFF,
            },
            slot=Planner.ActionSlot.SKILL,
            execute=lambda _: self.cast_skill(),
            name="linko_skill",
            reason="linko E team buff (time-stop animation)",
            can_execute=lambda _: self.skill_available(),
            priority_ready=lambda _: self.skill_available(),
        )
        rotation_next = make_rotation_next_action(self, rotation)
        rotation_retry = make_rotation_next_action(self, rotation, advance=False, check_cycle=False)

        def entry():
            stage = rotation.stage_for(self)
            self.logger.info(
                f"[rotation] Linko entry stage={stage} current={rotation.current_stage()} "
                f"queue={rotation.queue} looping={rotation.looping}"
            )
            if stage in LINGKE_STAGES:
                # 每轮一次上场：有 E 放 E → 有 Q 放 Q → 切人前复检一次。
                # 复检是因为前一个技能的时停动画期间能量/CD 状态会变化
                # （E 打完可能刚好把 Q 的能量攒满）。
                if self.skill_available():
                    yield skill
                    self.sleep(self.SKILL_POST_CAST_SLEEP)
                if self.ultimate_available():
                    yield ultimate
                    self.sleep(self.ULT_POST_CAST_SLEEP)
                if self.ultimate_available():
                    yield ultimate.repeat_for_entry()
                if self.skill_available():
                    yield skill.repeat_for_entry()
                yield rotation_next
            else:
                # 非排轴期望的入场（交替段增益插入 / 意外入场）：
                # 兜底 E+Q 后请求切回排轴，不推进状态机。
                if self.skill_available():
                    yield skill
                if self.ultimate_available():
                    yield ultimate
                if self.ultimate_available():
                    yield ultimate.repeat_for_entry()
                if self.skill_available():
                    yield skill.repeat_for_entry()
                yield rotation_retry

        return self.plan(skill, ultimate, entry=entry)

    def cast_skill(self):
        """释放 E（时停动画约 2s）。

        has_animation=True：框架在检测到「不在队伍 UI」时挂起等待动画结束，
        回队后再确认 CD，并把这段时停记入冻结时长（不计入技能 CD）。
        若该技能实际不触发脱队时停，则退化为普通按 E + 等 CD 确认，同样安全。
        """
        clicked = self.click_skill(
            down_time=self.SKILL_DOWN_TIME,
            send_click=False,
            has_animation=True,
        )
        self.logger.info(f"[rotation] Linko E cast={bool(clicked)}")
        return bool(clicked)
