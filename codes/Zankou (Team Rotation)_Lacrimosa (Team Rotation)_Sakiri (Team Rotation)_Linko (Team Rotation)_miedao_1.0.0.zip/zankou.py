"""1觉（A觉）残安早灵合轴队 —— 共享排轴核心 + 残虹。

队伍：残虹（1觉）+ 安魂曲 + 早雾 + 灵可（Linko）。
排轴来源：以「残安早伊」确认稿 v3 为骨架，把伊洛伊位整体替换为灵可。

流程概览::

    战前     玩家手动按 G 把安魂曲切到远程模式（整场一次，脚本不按 G）
    0觉首轮 早雾qe → 灵可(援护)eq → 安魂曲QE(3s动画) → 残虹大连段
             → 残虹 Q1血宴（紫色图标解锁后直放，不再切安魂曲合轴）
             → 残虹 Q2焚天 + a1z
             → 安魂曲 QE + 远合轴（首次 alt 段入场，补一次合轴）
             → 残虹⇄安魂曲交替合轴循环（每次安魂曲上场都先 QE）
    环合满   切灵可(援护+eq) → 进入1觉循环
    1觉循环 灵可eq → 早雾qe → 安魂曲QE+远合轴（alr段每次安魂曲上场都先 QE）
             → 残虹⇄安魂曲交替合轴循环（残虹Q能量满先焚天再a1z）
             → 环合满 → 切灵可(援护+eq) → 循环

与残安早伊版的差异（灵可替换伊洛伊）::

    1. 灵可没有类似 qza 的连段，E/Q 每次上场一起放：首轮安魂曲 QE 之后不再切
       灵可，循环里也一样——灵可每轮只在循环头上场一次（援护 + eq 一次放完）。
       原「伊洛伊二次入场」的两个阶段已删除，安魂曲循环头改为一次入场做完
       QE + 远程合轴（STAGE_LACRI_FUSION），避免同角色连续两阶段空切自己。
    2. E/Q 都是时停动画（E≈2s、Q≈4s）：由框架 has_animation / click_ultimate
       自动挂起等待并记账冻结时长，脚本不再 sleep 固定时长。
    3. 增益插入候选从（早雾/伊洛伊）改为（早雾/灵可）；灵可的 E 也是核心
       增益（12s CD），大招都没转好时按 E 是否就绪插入。
    4. 残虹入场覆写 wait_intro 直接 return：默认实现会在入场动画期间补 1.5s
       普攻，污染后续 a1→z 的段数衔接，导致强化 E（金色图标）等不到而站桩。
    5. 等强化 E / 等 Q 图标一律改成"边打边等"（短等 + 补重击 + 普攻轮询），
       全程保持输入，不再出现干等 4s 的发呆窗口。
    6. 安魂曲每次上场都先 QE 再远合轴（包括 alt 段，不再区分 fusion / lacri_qe_fusion，
       合并为单一 STAGE_LACRI_FUSION 阶段）。
    7. 0 觉首轮大连段 + Q1 + Q2 + a1z 全部塞进 STAGE_ZERO_COMBO 单段 entry 里：
       大连段 `yield opening_combo` → `wait_until(find_ult_purple)` → `yield ultimate`（Q1）
       → `wait_until(ultimate_available)` → `yield ultimate.repeat_for_entry()`（Q2）
       → `yield fusion_az` → `yield rotation_next`。
       大连段→Q1→Q2→a1z 在同一 entry 内连续 yield，不跨 stage 切人；queue 推进
       只发生在 a1z 后，避免用户开 MIN_*=0 后被 buff 插入逻辑切到早雾。
    8. zero_q12 用残虹官方默认脚本的 Q 释放模式：
       `task.wait_until(find_ult_purple, post_action=click_with_interval, time_out=2)`
       → `yield ultimate`（Q1 血宴入梦，框架挂起等时停动画）
       → `task.wait_until(ultimate_available, post_action=click_with_interval, time_out=3)`
       → `yield ultimate.repeat_for_entry()`（Q2 焚天烬灭舞）
       → `yield fusion_az` + `yield rotation_next`
       Q1 → Q2 在同一 entry 生成器内连续 yield，generator 不 StopIteration 直到 Q2+a1z 完成。
       不再用自写的 `_wait_ult_quick` 零普攻预检——官方模式已经是最连贯的：
       wait_until 期间由 click_with_interval 持续输出，OCR 一抓到就立刻 yield ultimate。

工坊包文件结构（共 5 个文件，已达工坊上限）::

    team.json     方案元数据（名称 / 作者 / 版本 / 角色清单）
    zankou.py     本文件：全队共享排轴状态机 + 残虹角色
    sakiri.py     早雾（经共享模块取排轴状态机）
    lacrimosa.py  安魂曲（同上）
    lingke.py     灵可（同上）

外置角色文件之间无法直接 import（注册器把每个文件按独立模块加载）。
四个文件通过固定的 sys.modules key（_aczy_zankou_lingke_team_module）共享
zankou.py 的同一份模块实例；排轴状态机实例挂在本场战斗的
task.zankou_lingke_rotation 属性上，全队四个角色跨模块共享。

安装后绑定：在角色管理里把队内四个角色分别绑定到
[外置代码] 残虹（合轴队）/ 安魂曲（合轴队）/ 早雾（合轴队）/ 灵可（合轴队）。
"""

import sys
import time

from src.char.BaseChar import BaseChar
from src.char.Zankou import Zankou as StockZankou
from src.combat.planner import Planner, RoleProfile
from src.Labels import Labels

# ---------------------------------------------------------------------------
# 阶段定义（全队共享排轴状态机）
# ---------------------------------------------------------------------------

STAGE_OPEN_SAKIRI = "open_sakiri"        # 0觉开场: 早雾 q -> e
STAGE_OPEN_LINKO = "open_linko"          # 0觉开场: 灵可援护入场 -> eq（每轮唯一一次上场）
STAGE_OPEN_LACRI = "open_lacri"          # 0觉开场: 安魂曲 Q + E(番茄酱恶魔) → 切人
STAGE_ZERO_COMBO = "zero_combo"          # 0觉: 残虹大连段 → Q1血宴入梦 → Q2焚天烬灭舞 + a1z（同一 entry 单段闭环）
STAGE_LACRI_FUSION = "lacri_fusion"      # 1觉循环/alt段：安魂曲 Q + E + 远程合轴（QE 后立刻切人合轴）
STAGE_ZANKOU_FUSION = "zankou_fusion"    # 合轴循环: 残虹 [Q焚天] a1 -> z -> 预输入(a5后台)
STAGE_LINKO = "linko"                    # 1觉循环开头: 灵可援护入场 -> eq
STAGE_SAKIRI_QE = "sakiri_qe"            # 1觉循环: 早雾 q -> e

# 灵可的全部阶段（每次上场执行同一套「有E放E、有Q放Q」逻辑）
LINGKE_STAGES = (
    STAGE_OPEN_LINKO,
    STAGE_LINKO,
)

# 阶段 -> 归属角色类名（用于 entry 校验和切人目标解析）
STAGE_OWNER = {
    STAGE_OPEN_SAKIRI: "Sakiri",
    STAGE_OPEN_LINKO: "Linko",
    STAGE_OPEN_LACRI: "Lacrimosa",
    STAGE_ZERO_COMBO: "Zankou",
    STAGE_LACRI_FUSION: "Lacrimosa",
    STAGE_ZANKOU_FUSION: "Zankou",
    STAGE_LINKO: "Linko",
    STAGE_SAKIRI_QE: "Sakiri",
}

# 0觉开场固定序列（跑一次）：早雾 QE → 灵可援护+eq → 安魂曲 QE → 残虹大连段+Q1+Q2+a1z（单段闭环）。
# Q2 完成后队列清空，进入 alt loop，下一段是 STAGE_LACRI_FUSION（安魂曲做首次 QE+远合轴）。
OPENING_STAGES = [
    STAGE_OPEN_SAKIRI,
    STAGE_OPEN_LINKO,
    STAGE_OPEN_LACRI,
    STAGE_ZERO_COMBO,
]

# 1觉循环开头序列（每次环合满进入下一轮时重置）
# 灵可没有 qza 连段，E/Q 一次放完就走，因此循环头里灵可只出现一次；
# 安魂曲直接 QE + 远合轴（一次站场做完），alt 段后续每次安魂曲上场也是 QE + 远合轴。
LOOP_HEAD_STAGES = [
    STAGE_LINKO,
    STAGE_SAKIRI_QE,
    STAGE_LACRI_FUSION,
]


class ZankouRotation:
    """跨角色共享的排轴阶段状态机，挂在 task.zankou_lingke_rotation 上。"""

    # 每轮 1觉循环至少打 N 轮残虹 az 合轴后，才允许环合满进入下一轮。
    # 环合充满速度远快于排轴预期（早雾 QE 后数秒即满），不设下限会把
    # 交替合轴段整体跳过（残虹永远上不了场）。
    MIN_ALTERNATION_ROUNDS = 0

    # 交替合轴段每打满 N 轮，才允许插入一次"切辅助上增益"。
    # 交替段只排残虹与安魂曲，早雾/灵可要等下一轮循环头才上场，
    # 而增益的转好时机是动态的——不主动插入就会断档。
    MIN_ROUNDS_BETWEEN_BUFF = 0

    def __init__(self):
        self.reset()

    def reset(self):
        self.queue = list(OPENING_STAGES)
        # 交替合轴循环方向：queue 空后 lacri_fusion / zankou_fusion 交替。
        # 开场队列末尾是 ZERO_Q2（残虹 a1z+预输入），队列清空后下一段是
        # 安魂曲 LACRI_FUSION（残虹后台 a5 期间安魂曲先 QE+远程合轴），故初始为 False。
        self.next_is_zankou = False
        self.looping = False
        # 本轮已完成的残虹 az 合轴轮数（enter_loop 时清零）
        self.alternation_rounds = 0
        # 自上次辅助上增益以来的交替轮数（上增益时清零）
        self.rounds_since_buff = 0

    # ------------------------------------------------------------------
    # 阶段查询
    # ------------------------------------------------------------------

    def current_stage(self):
        """当前应执行阶段。"""
        if self.queue:
            return self.queue[0]
        return STAGE_ZANKOU_FUSION if self.next_is_zankou else STAGE_LACRI_FUSION

    def current_owner(self):
        return STAGE_OWNER.get(self.current_stage(), "")

    def stage_for(self, char):
        """返回当前阶段；若阶段不归属该角色则返回 None（走兜底）。"""
        if STAGE_OWNER.get(self.current_stage()) == type(char).__name__:
            return self.current_stage()
        return None

    # ------------------------------------------------------------------
    # 阶段推进
    # ------------------------------------------------------------------

    def advance(self):
        """完成当前阶段，推进到下一阶段。"""
        if self.queue:
            self.queue.pop(0)
        else:
            if self.next_is_zankou:
                # 刚完成的是残虹 az 合轴段，计一轮
                self.alternation_rounds += 1
                self.rounds_since_buff += 1
            self.next_is_zankou = not self.next_is_zankou

    # ------------------------------------------------------------------
    # 增益插入（交替段里补早雾/灵可的增益）
    # ------------------------------------------------------------------

    def can_insert_buff(self):
        """交替合轴段是否已打满轮数、允许插入一次辅助增益。"""
        return self.rounds_since_buff >= self.MIN_ROUNDS_BETWEEN_BUFF

    def mark_buff_used(self):
        """记录本次辅助增益已上，重新计轮。"""
        self.rounds_since_buff = 0

    def can_enter_loop(self):
        """交替合轴段打满下限轮数后才允许环合满进下一轮 1觉循环。"""
        return self.alternation_rounds >= self.MIN_ALTERNATION_ROUNDS

    def enter_loop(self):
        """环合值满：跳到灵可援护段，开启下一轮 1觉循环。"""
        self.queue = list(LOOP_HEAD_STAGES)
        self.next_is_zankou = True
        self.looping = True
        self.alternation_rounds = 0
        # 循环头里灵可 eq 与早雾 QE 会补上增益
        self.rounds_since_buff = 0


# ---------------------------------------------------------------------------
# 排轴 helper（角色代码使用）
# ---------------------------------------------------------------------------

ROTATION_ATTR = "zankou_lingke_rotation"


def get_rotation(task):
    """获取（或惰性创建）本场战斗的排轴状态机。"""
    rotation = getattr(task, ROTATION_ATTR, None)
    if rotation is None:
        rotation = ZankouRotation()
        setattr(task, ROTATION_ATTR, rotation)
    return rotation


def find_teammate(char, owner_name):
    """按角色类名在队伍里查找队友对象。"""
    for teammate in char.task.chars:
        if teammate is not None and type(teammate).__name__ == owner_name:
            return teammate
    return None


def find_ready_supporter(char, rotation):
    """找一个"增益已转好"的辅助（早雾/灵可），用于在交替段补增益。

    离场角色也能检测：BaseChar.available() 对离场的 ultimate 会走
    task.ultimate_available(index) 的槽位模板匹配，skill 走队伍栏 CD，
    都不需要角色在场。

    优先大招；大招都没好时再看灵可的 E（12s CD，是核心增益），
    避免灵可只有 E 转好却一直等不到上场。
    """
    for name in ("Sakiri", "Linko"):
        mate = find_teammate(char, name)
        if mate is None or type(mate).__name__ != name:
            continue
        if mate.ultimate_available():
            return mate
    linko = find_teammate(char, "Linko")
    if linko is not None and type(linko).__name__ == "Linko" and linko.skill_available():
        return linko
    return None


def request_rotation_next(char, context, rotation, check_cycle=True):
    """推进排轴后的切人请求（在收尾动作 execute 内调用）。

    环合值满时优先切灵可（触发援护 + eq 开启下一轮 1觉循环）；
    否则按状态机下一阶段的归属角色请求切入。

    调度优先级（交替合轴段，即固定阶段队列已清空时）：
      1. 环合满（仅残虹侧判定）→ 进下一轮 1觉循环，循环头内早雾/灵可会补增益
      2. 辅助增益已转好，且距上次增益已打满 MIN_ROUNDS_BETWEEN_BUFF 轮
         → 切辅助补增益，避免交替段过长导致增益断档
      3. 否则按状态机下一阶段的归属角色请求切入

    插入增益时不推进状态机：辅助走兜底分支（放 Q/E）后，用不推进的
    收尾动作请求切回当前阶段归属角色，交替合轴继续。

    环合检查只在**残虹自己的收尾**判定——排轴要求「检测残虹的环合值，
    残虹 a1za5 后切灵可」，安魂曲收尾时不检查（环合 UI 随在场角色变化，
    在安魂曲在场时检测到的是安魂曲的环合）。另外必须打满
    MIN_ALTERNATION_ROUNDS 轮残虹 az 才允许进循环。
    """
    target = None
    in_alternation = not rotation.queue

    # 1. 环合满 → 进下一轮 1觉循环
    if (
        check_cycle
        and in_alternation
        and rotation.can_enter_loop()
        and type(char).__name__ == "Zankou"
        and char.task.is_cycle_full()
    ):
        char.logger.debug("zankou rotation: cycle full, enter loop via Linko")
        rotation.enter_loop()
        target = find_teammate(char, rotation.current_owner())
    elif in_alternation and rotation.can_insert_buff():
        # 2. 交替段插入辅助增益（增益转好才插，避免空切打断合轴）
        supporter = find_ready_supporter(char, rotation)
        if supporter is not None:
            char.logger.info(
                f"[rotation] insert buff -> {type(supporter).__name__} "
                f"(ult={supporter.ultimate_available()} "
                f"skill={supporter.skill_available()}, "
                f"rounds_since_buff={rotation.rounds_since_buff})"
            )
            rotation.mark_buff_used()
            target = supporter

    # 3. 正常下一阶段归属角色
    if target is None:
        target = find_teammate(char, rotation.current_owner())

    if target is None:
        char.logger.warning(f"zankou rotation: teammate {rotation.current_owner()} not found")
        return
    char.logger.info(
        f"[rotation] {type(char).__name__} done -> next stage={rotation.current_stage()} "
        f"owner={rotation.current_owner()} queue={rotation.queue} "
        f"rounds={rotation.alternation_rounds}"
    )
    context.request_switch(target, reason=f"zankou rotation -> {rotation.current_stage()}")


def make_rotation_next_action(char, rotation, advance=True, check_cycle=True):
    """生成 entry 收尾动作：推进排轴并请求切到下一阶段归属角色。

    必须作为 entry 生成器的最后一个 yield 使用。planner 只在动作执行后
    回收请求；生成器结束（StopIteration）时发布的请求会被静默丢弃，
    因此 advance + request_switch 必须放在动作 execute 里，不能写在
    最后一个 yield 之后的生成器代码里。

    Args:
        char: 当前角色实例。
        rotation: 共享排轴状态机。
        advance: 是否推进当前阶段（兜底分支不推进，只请求切回排轴）。
        check_cycle: 是否检查环合满进 1觉循环（兜底分支不检查）。
    """
    from src.combat.planner import Planner

    def execute(context):
        if advance:
            rotation.advance()
        request_rotation_next(char, context, rotation, check_cycle=check_cycle)
        return True

    return char.planner_action(
        tags={Planner.ActionTag.DEFAULT_ACTION},
        slot=None,
        execute=execute,
        name=f"{type(char).__name__}_rotation_next",
        reason="rotation advance and request next char",
    )


# ---------------------------------------------------------------------------
# 残虹角色
# ---------------------------------------------------------------------------

class Zankou(StockZankou):
    cn_name = "残虹（合轴队）"
    en_name = "Zankou (Team Rotation)"
    element = BaseChar.ElementType.RED

    # 排轴时值（可按实测微调）
    HEAVY_ATTACK_DURATION = 0.8    # 开场大连段长按左键（自动衔接 a1→z绰影）
    FUSION_HEAVY_DURATION = 0.9    # 合轴段入场长按左键（自动衔接 a1z）
    FUSION_POST_HEAVY_SLEEP = 0.1  # 合轴段重击后等待
    FUSION_PREINPUT_SLEEP = 0.3    # 合轴段预输入普攻后等待再切人
    A5_BACKSTAGE_WAIT = 0.0        # 入场后等后台 a5 合轴收尾（「无」段）
    FORM_SWITCH_SLEEP = 0.1        # 绯影闪切幻境后的形态动画缓冲
    DANCE_INTERVAL = 0.2           # 幻境魇舞每段普攻间隔
    DANCE_PURPLE_TIMEOUT = 9.0     # 幻境内边打边等强化离魂错（紫色图标）的最长秒数
    ULT_WAIT_TIMEOUT = 4.0         # 等 Q 图标就绪超时（仅 wait_while_attacking 兜底用，
                                   # zero_q12 已改用 task.wait_until + click_with_interval）
    ULT_WAIT_INTERVAL = 0.08       # 兜底边打边等的普攻间隔
    LIHUN_CUO_ANIMATION_WAIT = 0.8 # 离魂错动画等待时间，确保动画完整播放
    # 强化 E（金色图标）等待策略：短等 → 补重击 → 边打边等，杜绝站桩发呆
    GOLD_WAIT_TIMEOUT = 1.0        # 重击后短等金色图标
    GOLD_HEAVY_RETRY = 2           # 短等未出金色时的补重击次数
    GOLD_ACTIVE_TIMEOUT = 3.0      # 补重击后仍无金色 → 边普攻边等的上限
    GOLD_ACTIVE_INTERVAL = 0.25    # 边打边等的普攻间隔

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.MAIN_DPS,
            field_preference=Planner.FieldPreference.MAIN_DPS,
        )

    def combat_plan(self, context):
        rotation = get_rotation(self.task)
        ultimate = self.click_ultimate_action()
        opening_combo = self.planner_action(
            tags={Planner.ActionTag.DEFAULT_ACTION},
            slot=Planner.ActionSlot.SKILL,
            execute=lambda _: self.perform_opening_combo(),
            name="zankou_opening_combo",
            reason="zankou 0-awaken dot combo",
        )
        fusion_az = self.planner_action(
            tags={Planner.ActionTag.DEFAULT_ACTION},
            slot=None,
            execute=lambda _: self.perform_fusion_az(),
            name="zankou_fusion_az",
            reason="zankou a1 + z + pre-input",
        )
        # 收尾动作：推进排轴 + 请求切人（必须放在 execute 里，见 make_rotation_next_action）
        rotation_next = make_rotation_next_action(self, rotation)
        rotation_retry = make_rotation_next_action(self, rotation, advance=False, check_cycle=False)

        def entry():
            stage = rotation.stage_for(self)
            self.logger.info(
                f"[rotation] Zankou entry stage={stage} current={rotation.current_stage()} "
                f"queue={rotation.queue} looping={rotation.looping}"
            )
            if stage == STAGE_ZERO_COMBO:
                # 0觉开场单段闭环：大连段 → Q1 → Q2 → a1z 全部在同一 entry 里连续 yield，
                # 不跨 stage 切人。模式同残虹官方默认脚本——
                # 大连段 yield 后 wait_until 等紫色图标，OCR 抓到即 yield ultimate（Q1），
                # 再 wait_until 等 Q2 就绪、yield ultimate.repeat_for_entry()（Q2）。
                #
                # 之前拆成 zero_combo + zero_q12 两段、中间走 yield rotation_next 推进队列，
                # 会被 buff 插入逻辑（用户把 MIN_*=0 全开了触发条件）切到早雾普攻几下再切回。
                # 合并后 queue 推进只发生在 a1z 后，没有"同角色相邻两阶段"间隙。
                yield opening_combo
                # 大连段末尾「强化 e 离魂错」激活血宴，Q 应已变紫；动画刚结束 OCR 可能
                # 一帧延迟，用 task.wait_until + click_with_interval 边普攻边等就绪。
                if not self.find_ult_purple():
                    self.task.wait_until(
                        self.find_ult_purple,
                        post_action=self.click_with_interval,
                        time_out=2,
                    )
                if self.find_ult_purple():
                    yield ultimate
                    # Q1 血宴入梦（时停动画由框架挂起等待，动画结束 generator 才继续）。
                    # 动画结束时 Q2 图标通常已转金色，再 wait_until 等一次再亮。
                    self.task.wait_until(
                        self.ultimate_available,
                        post_action=self.click_with_interval,
                        time_out=3,
                    )
                    yield ultimate.repeat_for_entry()
                else:
                    self.logger.warning("zankou Q1 skipped: ult icon not purple")
                yield fusion_az
                yield rotation_next
            elif stage == STAGE_ZANKOU_FUSION:
                # 合轴循环：入场（等后台 a5 收尾「无」）→ [Q能量满先焚天] → a1 z
                self.sleep(self.A5_BACKSTAGE_WAIT)
                if self.ultimate_available():
                    yield ultimate
                yield fusion_az
                yield rotation_next
            else:
                # 非排轴期望的意外入场（脱轴）：不放大招，只做 a1z 后请求切回排轴。
                # 此处绝不做 Q：脱轴状态下无法判断血宴是否激活，按 Q 会误放焚天。
                self.logger.warning(
                    f"[rotation] Zankou unexpected entry, rotation expects "
                    f"{rotation.current_stage()} (owner {rotation.current_owner()})"
                )
                yield fusion_az
                yield rotation_retry

        return self.plan(ultimate, opening_combo, fusion_az, entry=entry)

    # ------------------------------------------------------------------
    # 0觉大连段
    # ------------------------------------------------------------------

    def wait_intro(self, time_out=-1, click=True):
        """残虹入场不等援护动画、不补普攻。

        默认实现会 sleep 1.5s 并 continues_normal_attack 补十来下普攻，把普攻
        段数推进到 a2/a3 之后。开场大连段第一步是「长按自动衔接 a1→z 绰影」，
        段数被污染后长按接上的不是 a1，z 绰影打不出来 → 强化 E（金色图标）
        等不到 → 站在原地干等。这里直接 return，让入场后段数干净。
        """
        return

    def wait_while_attacking(self, condition, timeout, interval=None):
        """边普攻边等条件成立（超时返回 False）。

        干等（task.wait_until）期间角色站着不动，实测里表现为"残虹呆住"。
        等待期间保持普攻，既不浪费输出也不会被判定为罚站。
        """
        interval = self.ULT_WAIT_INTERVAL if interval is None else interval
        deadline = time.time() + timeout
        while True:
            if condition():
                return True
            if time.time() > deadline:
                return False
            self.click()
            self.sleep(interval)

    def perform_opening_combo(self):
        """0觉大连段（约 7.2s）上满 dot。

        长按左键自动衔接 a1→z 绰影（解锁强化 e）→ 强化 e 绯影闪（金色图标，进幻境）
        → 幻境魇舞 a1 a2 a3 a4 a1 a2（边打边等强化离魂错紫色窗口）
        → 强化 e 离魂错（回现实并激活血宴入梦）
        """
        # 1. a1z：长按左键（自动衔接 a1→z 绰影），解锁强化 e。
        #    声音反击/闪避会在长按的 sleep 里插入左键点击，把衔接打断，
        #    这里短等 + 补重击 + 边打边等，全程有输入。
        gold_ok = self.unlock_gold_skill()
        self.logger.info(f"zankou opening: skill gold detected={gold_ok}")
        # 2. 强化 e 绯影闪：金色图标出现后按 e，进入幻境形态；
        #    没等到（绰影被打断等）也照常按 e，普通绯影闪同样能进幻境
        self.click_skill(send_click=False)
        self.sleep(self.FORM_SWITCH_SLEEP)
        # 3. 幻境魇舞 + 等强化离魂错：保底打满 6 段（a1a2a3a4a1a2），
        #    之后持续普攻并轮询紫色图标（幻境即将结束的强化窗口），
        #    直到检测到或超时——必须等到强化离魂错才切人，否则无法激活血宴。
        #    只有强化离魂错才触发「灭」激活血宴入梦，普通离魂错不解锁 Q1
        purple_ok = False
        attacks = 0
        deadline = time.time() + self.DANCE_PURPLE_TIMEOUT
        while True:
            if attacks >= 6 and self.find_zankou_skill() == Labels.zankou_skill_purple:
                purple_ok = True
                break
            if time.time() > deadline:
                break
            self.click()
            self.sleep(self.DANCE_INTERVAL)
            attacks += 1
        self.logger.info(
            f"zankou opening: skill purple detected={purple_ok} after {attacks} dance attacks"
        )
        # 4. e 离魂错：回现实形态（动画期间切安魂曲合轴）
        self.click_skill(send_click=False, time_out=3)
        # 等待离魂错动画完整播放，确保动画不被后续操作打断
        self.sleep(self.LIHUN_CUO_ANIMATION_WAIT)
        return True

    # ------------------------------------------------------------------
    # 合轴段
    # ------------------------------------------------------------------

    def unlock_gold_skill(self):
        """长按重击解锁强化 E（金色图标），被打断就补，不站着干等。

        实测里出现过重击后被声音反击/闪避打断（日志伴随 Counter/Dodge），
        a1→z 没衔接上，接着干等金色图标 4s 超时——表现为残虹发呆。
        处理：短等 → 没出金色补一次重击（最多 GOLD_HEAVY_RETRY 次）
        → 仍没有就边普攻边等，任何一步都在出招。
        """
        for attempt in range(self.GOLD_HEAVY_RETRY + 1):
            if attempt:
                self.logger.info(f"zankou opening: retry heavy attack #{attempt}")
            self.heavy_attack(self.HEAVY_ATTACK_DURATION)
            if self.task.wait_until(
                lambda: self.find_zankou_skill() == Labels.zankou_skill_gold,
                time_out=self.GOLD_WAIT_TIMEOUT,
            ):
                return True
        self.logger.warning("zankou opening: gold still missing, attack while waiting")
        return self.wait_while_attacking(
            lambda: self.find_zankou_skill() == Labels.zankou_skill_gold,
            self.GOLD_ACTIVE_TIMEOUT,
            interval=self.GOLD_ACTIVE_INTERVAL,
        )

    def perform_fusion_az(self):
        """合轴段：入场直接长按左键（游戏自动衔接 a1z）→ 预输入普攻切人（后台自动 a5）。

        重击后普攻段数保持在第 4/5 段衔接状态，切人后台自动释放的
        普攻即 a5（吸附 + 扩散 dot）。
        """
        self.heavy_attack(self.FUSION_HEAVY_DURATION)
        self.sleep(self.FUSION_POST_HEAVY_SLEEP)
        # 预输入普攻：切人后由残虹后台自动释放 a5
        self.click()
        self.sleep(self.FUSION_PREINPUT_SLEEP)
        return True

    # ------------------------------------------------------------------
    # 图标识别（与内置残虹一致的模板匹配）
    # ------------------------------------------------------------------

    def find_zankou_skill(self):
        to_find = [Labels.zankou_skill_gold, Labels.zankou_skill_purple]
        for feature_name in to_find:
            if self.task.find_one(feature_name):
                return feature_name

    def find_ult_purple(self):
        return self.task.find_one(Labels.zankou_ult_purple)


# ---------------------------------------------------------------------------
# 共享模块注册
# ---------------------------------------------------------------------------
# 外置角色文件之间无法直接 import（注册器把每个文件按独立模块加载）。
# sakiri.py / lacrimosa.py / lingke.py 通过 TEAM_MODULE_KEY 加载本文件获取
# 排轴状态机；本文件无论被注册器还是被队友文件加载，执行完毕时都把自己
# 登记为共享模块（后执行的覆盖先执行的，保证编辑后重新扫描拿到最新代码）。
# 状态机实例本身挂在本场战斗的 task 属性上，
# 即使注册器与队友文件各持有一份模块副本，实例也全局唯一（鸭子类型访问）。

TEAM_MODULE_KEY = "_aczy_zankou_lingke_team_module"

try:
    from pathlib import Path as _Path

    _TEAM_SOURCE_STAMP = _Path(__file__).resolve().stat().st_mtime_ns
except OSError:
    _TEAM_SOURCE_STAMP = None

sys.modules[TEAM_MODULE_KEY] = sys.modules[__name__]
