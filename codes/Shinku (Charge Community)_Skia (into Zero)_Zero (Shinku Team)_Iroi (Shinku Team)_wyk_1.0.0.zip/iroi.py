"""真红盈蓄社区方案的伊洛伊辅助轮转。"""

from src.char.Iroi import Iroi
from src.char.Shinku import Shinku
from src.combat.planner import CombatContext, Planner, RoleProfile, SwitchDecision


class CommunityIroiShinku(Iroi):
    """快速释放 R/E/Q, 接重击+浮空炮, 然后指定切回真红合轴。

    动作顺序: R(弧盘) -> E(技能) -> Q(终结技) -> 重击 -> 浮空炮 -> 交人。

    E 之后留出短暂治疗结算时间; Q 成功后长按普攻出重击, 松开再点一次普攻放浮空炮,
    最后把站场交给真红。交人用 ``task._switch_to_char()`` 指定目标切人, 保证轮转
    不会被打乱, 同时在连招内完成, 因此 ``perform()`` 末尾不再重复切人 (见
    ``switch_next_char()``)。

    弧盘用 ``click_arc_action()`` 声明成 plan 里的正式动作, 让它进入 entry flow:

    - ``BaseChar.perform()`` 的默认 ``click_arc()`` 在 ``perform_current_char()``
      之前触发, 不受 planner 调度, 成败和被切人都看不出来; 声明成 action 后它受
      ``can_execute`` 硬限制 (伊洛伊已下场/阵亡就跳过) 约束, 并出现在 planner 日志里。
    - ``click_arc_action()`` 自带 ``priority_ready=False`` 且 ``ARC_ACTION`` 评分为 0,
      所以 R 不会让伊洛伊为了放弧盘而抢占站场, 只在已经进场时按流程释放。

    这里保留 ``planner_handles_arc = False``: 弧盘冷却没有 UI 可查, 一旦交出默认
    兜底, plan 里这一下没成功就整轮都不会再按 R。默认兜底 + plan 动作各按一次,
    多出来的那次落在冷却里没有代价, 换来的是弧盘一定会被尝试。
    """

    cn_name = "伊洛伊（真红队）"
    en_name = "Iroi (Shinku Team)"
    HEAL_SKILL_SETTLE_TIME = 0.8
    # 合轴: Q 结束后长按普攻出重击, 松开后点一次普攻放浮空炮, 然后立刻切真红。
    # 长按时长参考白藏的重击长按 (0.9s) 取短, 需实机校准。
    HEAVY_HOLD_DURATION = 0.6
    CANNON_ATTACK_COUNT = 1
    # 只留出松手后的点击间隔, 不额外等浮空炮动画: 打完这一下就交人。
    CANNON_SETTLE_TIME = 0.1

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._handoff_requested = False
        # 交人已在连招内完成, perform() 末尾不再让 planner 决策一次。
        self._skip_final_switch = False

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self, context: CombatContext):
        arc = self.click_arc_action(
            reason="arc available, press R before handing off",
            can_execute=lambda _: self.is_current_char and not self.is_dead,
        )
        skill = self.click_skill_action(add_tags=Planner.ActionTag.TEAM_BUFF)
        ultimate = self.click_ultimate_action()
        # Q 之后的合轴段 (重击 -> 浮空炮) 声明成一个动作: 它是连招尾部的一段,
        # 不是需要独立判定的技能, 所以不设 slot, 也不参与切人评分。
        followup = self.planner_action(
            tags={Planner.ActionTag.DAMAGE},
            execute=self._perform_followup,
            name=f"{self}_followup",
            reason="heavy attack into floating cannon before handoff",
            can_execute=lambda _: self.is_current_char and not self.is_dead,
            priority_ready=lambda _: False,
        )

        def entry():
            # 每轮进场都从头开始: 上一轮的交人状态不能影响本轮 (否则本轮交人失败时
            # 会误以为已经切过, 跳过 perform() 末尾的兜底切人)。
            self._handoff_requested = False
            self._skip_final_switch = False

            # 连招: R -> E -> Q -> 重击 -> 浮空炮 -> 交人。
            # 每段都尝试; 缺冷却/已被切人时 planner 给出失败 result, 流程继续往下,
            # 不会卡住轮转。R 打完直接接 E, 不等结算。
            yield arc

            yield skill
            if (yield ultimate):
                yield followup

            self._request_handoff(context)

        return self.plan(arc, skill, ultimate, followup, entry=entry)

    def click_skill(self, *args, **kwargs):
        kwargs.setdefault("post_sleep", self.HEAL_SKILL_SETTLE_TIME)
        return super().click_skill(*args, **kwargs)

    def _perform_followup(self, context: CombatContext = None):
        """Q 之后的合轴段: 长按普攻出重击, 松开后点普攻放浮空炮。

        只有严格返回 True 才算成功。长按用 `mouse_down`/`mouse_up` (与
        `BaseChar.heavy_attack` 相同的手法), 放在 finally 里保证任何异常都不会
        把鼠标留在按下状态。

        动作许可由 planner 统一检查 (该动作没有 slot, 因此没有 reservation 可挡),
        这里只做在场/存活检查。
        """
        if not self.is_current_char or self.is_dead:
            return False

        self.logger.info("followup: heavy attack")
        self._perform_heavy_attack()

        if not self.is_current_char or self.is_dead:
            return False

        for _ in range(self.CANNON_ATTACK_COUNT):
            self.logger.info("followup: floating cannon")
            self.normal_attack()
            self.sleep(self.CANNON_SETTLE_TIME)
            if not self.is_current_char or self.is_dead:
                return False

        return True

    def _perform_heavy_attack(self):
        """长按普攻释放重击; 无论成功失败都保证松开鼠标。"""
        try:
            self.task.mouse_down()
            self.sleep(self.HEAVY_HOLD_DURATION)
        finally:
            self.task.mouse_up()

    def switch_next_char(self, post_action=None, free_intro=False):
        """交人已经在连招里完成后, 跳过 perform() 末尾的第二次切人。

        `BaseChar.perform()` 结束时会无条件调用 `switch_next_char()`。伊洛伊在
        entry flow 里已经把站场交给了真红, 所以这里再让 planner 决策一次会切给
        **已经在场的真红**: `CombatPlanner._can_switch_to()` 只看 `is_dead`, 不排除
        在场角色, 而 `decide_switch()` 排除的只是传入的 `current_char` (伊洛伊)。
        结果是给真红重复发一次切人键, 靠血量变化被误判成"切换成功"; 若一直没检测
        到, `_switch_to_char` 会在 10s 超时后把真红 mark_dead, 直接踢出轮转。

        只跳过这一种情况: 交人失败 (或本来就没交人) 时仍走正常流程, 保留兜底。
        """
        if self._skip_final_switch and self.is_current_char is False:
            self.logger.info("handoff already done in combo, skip final switch_next_char")
            self.has_intro = False
            self._ultimate_available = self.ultimate_available()
            return
        super().switch_next_char(post_action=post_action, free_intro=free_intro)

    def _request_handoff(self, context: CombatContext) -> None:
        """把站场交还真红; 她阵亡或不在队伍时退化为按定位找主C。"""
        if self._handoff_requested:
            return
        self._handoff_requested = True

        target = self.shinku_teammate()
        if target is not None:
            self.logger.info(f"handoff: switch to {target.ufn_name}")
            self.switch_to_teammate(target)
            # 交人已经完成切人, 不再让 perform() 末尾的 switch_next_char 决策一次。
            self._skip_final_switch = True
            return

        self.logger.info("no Shinku teammate, request next main dps")
        context.request_role(
            Planner.Role.MAIN_DPS,
            reason="伊洛伊打完连招, 队伍里没有真红, 交给下一个主C",
        )

    def switch_to_teammate(self, target) -> None:
        """指定目标切人, 绕过 planner 的环合反应优先级。"""
        self.task._switch_to_char(
            SwitchDecision(
                target=target,
                reason=f"{self.ufn_name} handoff",
                priority=0,
                has_intro=False,
            ),
            current_char=self,
        )

    def shinku_teammate(self):
        """返回队伍里的真红; 没有或已阵亡时返回 None。

        按 MRO 里的内置原型类(``Shinku``)匹配: 这样社区子类(如
        ``CommunityShinku``)也能命中, 同时不会把互为兄弟类的其他自定义角色
        误判进来 —— 直接用 ``isinstance`` 会把四个角色全部判成 True。
        """
        for teammate in self.task.chars:
            if teammate is None or teammate is self or teammate.is_dead:
                continue
            if Shinku in type(teammate).__mro__:
                return teammate
        return None

    def reset_state(self):
        super().reset_state()
        self._handoff_requested = False
        self._skip_final_switch = False

    def on_combat_end(self, chars):
        self._handoff_requested = False
        self._skip_final_switch = False
        super().on_combat_end(chars)
