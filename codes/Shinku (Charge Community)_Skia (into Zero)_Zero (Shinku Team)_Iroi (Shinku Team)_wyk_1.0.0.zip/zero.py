"""真红盈蓄社区方案的零环合轮转。"""

from src.char.Iroi import Iroi
from src.char.Zero import Zero
from src.combat.planner import CombatContext, Planner, SwitchDecision


class CommunityZeroShinku(Zero):
    """先打 Q(极轨终结) + E(变轨攻击), 然后指定切给伊洛伊。

    零的 Q 只有攒满能量才可用, 所以 ``click_ultimate_action`` 的 ``can_execute``
    会自己挡掉没就绪的大招, 流程直接落到 E —— 不会为了等大招卡住站场。E 打完后
    环合值通常是满的, 此时如果让 planner 自己选目标, 它会优先执行环合反应
    (优先级 999500), 把站场抢给环合对象(例如翳), 轮转就变成 零 -> 翳。

    交人用 ``task._switch_to_char()`` 指定目标切人 (``switch_next_char()`` 内部用的
    也是它, 但会先问 planner)。这样做是因为 planner 的环合反应(优先级 999500)会盖过
    普通切人请求(998000), 而 ``switch_other_char()`` 只会切索引最小的队友, 两者都
    保证不了目标。

    交人成功后还要跳过 ``BaseChar.perform()`` 末尾的第二次切人决策
    (``_skip_final_switch``): 直切只是"这一下把站场给伊洛伊", 末尾那次会让 planner
    重新选目标, 真红挂着的回场 claim(740) 等目标会把刚上场的伊洛伊换掉。条件与伊洛伊
    一致: 只有确认自己已经下场才跳过, 交人失败时保留兜底切人。
    """

    cn_name = "零（真红队）"
    en_name = "Zero (Shinku Team)"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 零没有弧盘技能, 关掉 `perform()` 开头的弧盘兜底按键。默认的
        # `planner_handles_arc = False` 会让每次上场先按一次 Q, 把第一下大招顶掉。
        self.planner_handles_arc = True
        self._handoff_requested = False
        # 交人已在 entry flow 内完成时, perform() 末尾不再让 planner 决策一次。
        self._skip_final_switch = False

    def combat_plan(self, context: CombatContext):
        # send_click=False: 大招和 E 的动画期间不再补普通点击(平A), 与翳一致。
        ultimate = self.click_ultimate_action(reason="opener ultimate", send_click=False)
        skill = self.click_skill_action(
            add_tags=Planner.ActionTag.TEAM_BUFF, send_click=False
        )

        def entry():
            # 每轮进场都从头开始: 上一轮的交人状态不能影响本轮 (否则本轮交人失败时
            # 会误以为已经切过, 跳过 perform() 末尾的兜底切人)。
            self._handoff_requested = False
            self._skip_final_switch = False

            # Q(极轨终结) -> E(变轨攻击) -> 交人, 与翳保持一致。
            # Q 没攒满时 `click_ultimate_action` 的 can_execute 会挡掉它, 流程直接
            # 落到 E, 所以不会为了等大招卡住站场。
            yield ultimate
            yield skill

            self._request_handoff(context)

        return self.plan(ultimate, skill, entry=entry)

    def switch_next_char(self, post_action=None, free_intro=False):
        """交人已经在 entry flow 里完成后, 跳过 perform() 末尾的第二次切人。

        ``BaseChar.perform()`` 结束时会无条件调用 ``switch_next_char()``。零已经在
        entry flow 里把站场指定交给了伊洛伊, 这里再让 planner 决策一次就可能改目标:
        planner 只看候选评分, 不知道"刚交完人"这件事, 于是会出现"零 -> 伊洛伊"这种
        重复切人, 或者被真红的回场 claim 直接换掉伊洛伊。

        只跳过这一种情况: 确认自己已经下场 (交人真的切成功了)。交人失败或没交人时
        仍然走正常流程, 保留兜底切人。
        """
        if self._skip_final_switch and self.is_current_char is False:
            self.logger.info("handoff already done in combo, skip final switch_next_char")
            self.has_intro = False
            self._ultimate_available = self.ultimate_available()
            return
        super().switch_next_char(post_action=post_action, free_intro=free_intro)

    def _request_handoff(self, context: CombatContext) -> None:
        """把站场交给伊洛伊; 她阵亡或不在队伍时退化为按定位找辅助。"""
        if self._handoff_requested:
            return
        self._handoff_requested = True

        target = self.iroi_teammate()
        if target is not None:
            self.logger.info(f"handoff: switch to {target.ufn_name}")
            self.switch_to_teammate(target)
            # 交人已经完成切人, 不再让 perform() 末尾的 switch_next_char 决策一次。
            self._skip_final_switch = True
            return

        self.logger.info("no Iroi teammate, request next support")
        context.request_role(
            Planner.Role.SUPPORT,
            reason="零打完技能, 队伍里没有伊洛伊, 交给下一个辅助",
        )

    def switch_to_teammate(self, target) -> None:
        """指定目标切人, 绕过 planner 的环合反应优先级。"""
        self.task._switch_to_char(
            SwitchDecision(
                target=target,
                reason=f"{self.ufn_name} handoff",
                priority=0,
                has_intro=False,
            ),
            current_char=self,
        )

    def iroi_teammate(self):
        """返回队伍里的伊洛伊; 没有或已阵亡时返回 None。

        按 MRO 里的内置原型类(``Iroi``)匹配: 这样社区子类(如
        ``CommunityIroiShinku``)也能命中, 同时不会把互为兄弟类的其他自定义角色
        误判进来 —— 直接用 ``isinstance`` 会把四个角色全部判成 True。
        """
        for teammate in self.task.chars:
            if teammate is None or teammate is self or teammate.is_dead:
                continue
            if Iroi in type(teammate).__mro__:
                return teammate
        return None

    def reset_state(self):
        super().reset_state()
        self._handoff_requested = False
        self._skip_final_switch = False

    def on_combat_end(self, chars):
        self._handoff_requested = False
        self._skip_final_switch = False
        super().on_combat_end(chars)
