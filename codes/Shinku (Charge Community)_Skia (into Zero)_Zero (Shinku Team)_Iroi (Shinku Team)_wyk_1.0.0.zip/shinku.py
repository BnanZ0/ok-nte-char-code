"""真红盈蓄社区方案的主场轮转。

首次进场优先 E; 满能量满环合 (Q 就绪) 时不立刻开大, 而是把站场交给环合队友,
等环合反应 (入场反应) 触发后再回到场上开大。
"""

import time

from src.char.Shinku import Shinku
from src.char.Skia import Skia
from src.combat.planner import (
    ActionSlot,
    CombatContext,
    ExpectedEntry,
    FieldClaim,
    Planner,
    SwitchDecision,
    SwitchInGuard,
)


class CommunityShinku(Shinku):
    """首次进场先 E, 环合反应触发后回场先 E 再开大, 然后执行大招窗口。

    真红自己掌握交人目标: 让出站场和大招窗口结束后都固定交给翳, 开始下一轮
    翳 -> 零 -> 伊洛伊 -> 真红。不能让 planner 自己挑 —— 框架的
    ``find_element_reaction_target`` 会在真红的两个相邻属性队友之间**轮流**选
    (按环合次数平衡), 于是同一轮里有时给翳、有时给伊洛伊; 而伊洛伊刚在上一轮
    末尾把站场交回真红, 技能全在冷却, 被切上来只能空转, 轮转就乱了。

    大招之后的站场窗口在 ``perform_in_ult`` 里覆写: 每上场一次, 第一发大招之后
    固定站满 ``ULT_HOLD`` 秒才交人。内置实现是 12 秒窗口, 而且窗口里补发大招
    成功时直接收工, 实测大招动画一结束就切人 (日志里 unfreeze 和 handoff 在
    同一毫秒)。
    """

    # 第一发大招之后的站场时长 (秒): 这段时间真红留在场上, 不会被切走。
    ULT_HOLD = 13.0
    # 站场期间大招再次就绪时, 从第几秒开始允许补发 (沿用内置真红的 9 秒)。
    ULT_REOPEN_AFTER = 9.0

    cn_name = "真红（盈蓄社区版）"
    en_name = "Shinku (Charge Community)"

    # 让出站场后, 队友至少站场这么久 (真实时间) 才允许真红按 claim 回场。
    REACTION_WINDOW_MIN = 1.2
    # 从让出站场算起, 超过这个时间就强制回场开大, 避免节奏停摆。
    REACTION_WINDOW_MAX = 3.0
    # 回场时等待环合反应结算的上限; 超时后仍会切入, 不会卡死换人。
    REACTION_SWITCH_IN_TIMEOUT = 2.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 真红没有弧盘技能, 关掉 `perform()` 开头的弧盘兜底按键。默认的
        # `planner_handles_arc = False` 会让每次上场先按一次 Q, 而这时 entry flow
        # 还没开始 —— 第一下 E 被它顶掉, 看起来就是"先平A/先放别的"。
        self.planner_handles_arc = True
        self.switch_deferred = False
        self.reaction_window_start = 0.0
        self.return_confirmed = False
        self._handoff_requested = False
        # 交人已在 entry flow 内完成时, perform() 末尾不再让 planner 决策一次。
        self._skip_final_switch = False

    def combat_plan(self, context: CombatContext):
        skill = self.click_skill_action(
            reason="first engage skill",
            can_execute=self._can_use_skill,
        )
        ultimate = self.click_ultimate_action(
            reason="ring reaction ultimate window",
            can_execute=self._can_use_ultimate,
        )

        claims = []
        if self._should_claim_return():
            claims.append(
                FieldClaim.high(
                    # 回场第一下必须是 E。入场动作期望写成 ULTIMATE 时, planner 会在
                    # 切入后直接执行 Q (日志: "planner entry expected action ... ->
                    # ..._ultimate"), entry flow 里的 E 被整个跳过, 真红回场就变成
                    # Q -> E。写成 SKILL 后回到 entry flow 的正常顺序 E -> Q:
                    # expected entry 先打 E, entry flow 的 `yield skill` 会收到这次
                    # 结果而不重复执行, 接着 `_should_cast_ultimate_now()` 再放大招。
                    # E 在冷却时期望匹配不到可用动作, planner 照旧直接开大, 不卡轮转。
                    reason="ring reaction triggered, return for skill then ultimate",
                    expected_entry=ExpectedEntry(slot=ActionSlot.SKILL),
                )
            )

        def entry():
            # 每轮进场都从头开始: 上一轮的交人状态不能影响本轮 (否则本轮交人失败时
            # 会误以为已经切过, 跳过 perform() 末尾的兜底切人)。
            self._handoff_requested = False
            self._skip_final_switch = False

            skill_result = yield skill

            if self._should_switch_out_for_reaction(skill_result):
                self._defer_for_reaction(context)
                return

            if self._should_cast_ultimate_now():
                self._clear_defer_state()
                ultimate_result = yield ultimate
                if ultimate_result:
                    self.perform_in_ult(context)
            elif skill_result:
                self.perform_in_ult(context)

            # 这一轮打完了 (大招窗口也走完), 固定交给翳开始下一轮。
            self._request_handoff(context)

        return self.plan(skill, ultimate, claims=claims, entry=entry)

    def perform_in_ult(self, context: CombatContext = None):
        """第一发大招之后的站场窗口: 站满 ``ULT_HOLD`` 秒才交人。

        内置 ``Shinku.perform_in_ult`` 只跑 12 秒, 而且窗口里补发大招成功时直接
        ``return True``, 窗口当场收尾 —— entry 紧接着就交人, 实测大招动画一结束
        (日志里 ``ultimate unfreeze`` 和 ``handoff`` 落在同一毫秒) 真红就被切下场。

        这里改成纯计时: 期间大招再次就绪就补发一发, 但补发不会缩短站场, 走满
        ``ULT_HOLD`` 秒才回去交人。窗口内被切下场或阵亡立刻退出, 不会卡住轮转。
        """
        start = time.time()
        while time.time() - start < self.ULT_HOLD:
            elapsed = time.time() - start
            if elapsed > self.ULT_REOPEN_AFTER and self.ultimate_available():
                self.click_ultimate()
            self.click_skill()
            self.sleep(0.1)
            self.normal_attack()
            self.sleep(0.1)
            if not self.is_current_char or self.is_dead:
                return False

        return True

    def switch_next_char(self, post_action=None, free_intro=False):
        """交人已经在 entry flow 里完成后, 跳过 perform() 末尾的第二次切人。

        ``BaseChar.perform()`` 结束时会无条件调用 ``switch_next_char()``。真红已经
        在 entry flow 里把站场指定交给了翳, 这里再让 planner 决策一次就可能改目标:
        环合反应(999500)会在真红的两个相邻属性队友之间轮流挑, 于是刚上场的翳被
        伊洛伊顶掉, 或者按普通评分切给零, 轮转顺序就散了。

        只跳过这一种情况: 确认自己已经下场 (交人真的切成功了)。交人失败或队伍里
        没有翳时仍然走正常流程, 保留 planner 的兜底切人。
        """
        if self._skip_final_switch and self.is_current_char is False:
            self.logger.info("handoff already done in combo, skip final switch_next_char")
            self.has_intro = False
            self._ultimate_available = self.ultimate_available()
            return
        super().switch_next_char(post_action=post_action, free_intro=free_intro)

    def _request_handoff(self, context: CombatContext) -> None:
        """把站场交给翳, 让下一轮从 翳 -> 零 -> 伊洛伊 开始。

        队伍里没有翳 (或她已阵亡) 时不指定目标, 让 planner 照常兜底。
        """
        if self._handoff_requested:
            return
        self._handoff_requested = True

        target = self.skia_teammate()
        if target is not None:
            self.logger.info(f"handoff: switch to {target.ufn_name}")
            self._switch_to_teammate(target)
            # 交人已经完成切人, 不再让 perform() 末尾的 switch_next_char 决策一次。
            self._skip_final_switch = True
            return

        self.logger.info("no Skia teammate, let planner decide next char")

    def _switch_to_teammate(self, target) -> None:
        """指定目标切人, 绕过 planner 的环合反应优先级。"""
        self.task._switch_to_char(
            SwitchDecision(
                target=target,
                reason=f"{self.ufn_name} handoff",
                priority=0,
                has_intro=False,
            ),
            current_char=self,
        )

    def skia_teammate(self):
        """返回队伍里的翳; 没有或已阵亡时返回 None。

        按 MRO 里的内置原型类(``Skia``)匹配: 这样社区子类(``CommunitySkia``)也能
        命中, 同时不会把互为兄弟类的其他自定义角色误判进来 —— 直接用 ``isinstance``
        会把四个角色全部判成 True。
        """
        for teammate in self.task.chars:
            if teammate is None or teammate is self or teammate.is_dead:
                continue
            if Skia in type(teammate).__mro__:
                return teammate
        return None

    def switch_in_guard(self, context: CombatContext, from_char, has_intro: bool):
        """回场前给队友留出触发环合反应的时间, 有上限, 不会否决切人。"""
        if not self.switch_deferred:
            return SwitchInGuard.allow()
        if self.return_confirmed or self.reaction_window_finished():
            return SwitchInGuard.allow()
        if self._on_reaction_target(from_char):
            # 环合队友已经在场, 这次切入就是回场开大的时机。
            self.return_confirmed = True
            return SwitchInGuard.allow()

        return SwitchInGuard.delay_until_ready(
            condition=self.reaction_ready,
            timeout=self.REACTION_SWITCH_IN_TIMEOUT,
            reason="waiting for ring reaction before ultimate",
            while_waiting=self.click_with_interval,
        )

    def reset_state(self):
        super().reset_state()
        self._clear_defer_state()
        self._handoff_requested = False
        self._skip_final_switch = False

    def on_combat_end(self, chars):
        self._clear_defer_state()
        self._handoff_requested = False
        self._skip_final_switch = False
        super().on_combat_end(chars)

    def _can_use_skill(self, context: CombatContext = None) -> bool:
        """首次进场必须先把 E 打出去。"""
        return self.is_first_engage() or self.skill_available()

    def _can_use_ultimate(self, context: CombatContext = None) -> bool:
        """环合反应触发前 (含首次进场) 不开大; 反应完成或窗口超时后解除限制。"""
        if not self.switch_deferred:
            return True
        return self.reaction_ready()

    def reaction_ready(self) -> bool:
        """环合反应是否已经触发, 现在可以开大。

        `switch_in_guard()` 放行回场时会置位 `return_confirmed`, 等价于
        “队友已经站够时间, 环合反应已经结算”。
        """
        if not self.switch_deferred or self.return_confirmed:
            return True
        if self.reaction_window_start <= 0:
            return True
        return self.out_field_elapsed() >= self.REACTION_WINDOW_MIN

    def out_field_elapsed(self) -> float:
        """距离让出站场已经过去多久 (秒)。

        用真实经过时间衡量, 所以真红已经回到场上时也能判断环合窗口是否走完。
        """
        if self.reaction_window_start <= 0:
            return 0.0
        elapsed = time.time() - self.reaction_window_start
        return elapsed if elapsed > 0 else 0.0

    def reaction_window_finished(self) -> bool:
        """环合窗口是否已经结束 (反应完成, 或队友站场超时强制回场)。"""
        if self.return_confirmed or self.reaction_window_start <= 0:
            return True
        return self.out_field_elapsed() >= self.REACTION_WINDOW_MAX

    def defer_switch_for_reaction(self, target, context: CombatContext = None) -> bool:
        """满能量满环合时让出站场, 等环合反应触发后再回场开大。

        用直切而不是 ``context.request_switch()``: 环合反应决策的优先级(999500)
        高于切人请求(998000), 走 planner 的话目标会被 ``find_element_reaction_target``
        改成它此刻更想平衡的那位队友。
        """
        if target is None:
            return False

        self.switch_deferred = True
        self.reaction_window_start = time.time()
        self.return_confirmed = False
        self.logger.info(f"defer ultimate, switch out to {target.ufn_name} for ring reaction")

        self._switch_to_teammate(target)
        # 让出站场已经切完, perform() 末尾不再让 planner 决策一次。
        self._skip_final_switch = True
        return True

    def _should_switch_out_for_reaction(self, skill_result) -> bool:
        if self.switch_deferred or not skill_result:
            return False
        if not self.is_first_engage():
            return False
        if not self.ultimate_available():
            return False
        target = self.skia_teammate() or self.find_element_reaction_target(self)
        if target is None:
            self.logger.info("ultimate ready but no ring reaction teammate, cast directly")
            return False
        return True

    def _should_cast_ultimate_now(self) -> bool:
        if not self.ultimate_available():
            return False
        if not self.switch_deferred:
            return True
        return self.reaction_ready()

    def _defer_for_reaction(self, context: CombatContext) -> None:
        """让出站场, 让翳的入场触发环合反应。

        目标固定为翳, 不问 ``find_element_reaction_target``: 框架会在真红的两个
        相邻属性队友之间轮流选(按环合次数平衡), 同一轮里可能给到伊洛伊 —— 而她刚
        在上一轮末尾把站场交回真红, 技能全在冷却, 切上来只能空转。
        队伍里没有翳时才退回框架的环合对象, 至少还能触发一次反应。
        """
        target = self.skia_teammate() or self.find_element_reaction_target(self)
        if target is None:
            self._clear_defer_state()
            return
        self.defer_switch_for_reaction(target, context)

    def _should_claim_return(self) -> bool:
        if not self.switch_deferred or self.is_current_char:
            return False
        if not self.ultimate_available():
            return False
        # 队友还没站够时间时先不提交 claim, 避免环合反应尚未触发就抢回场。
        return self.reaction_ready()

    def _on_reaction_target(self, from_char) -> bool:
        """当前在场的正是负责触发环合反应的队友(翳)时, 不再延迟回场。"""
        if from_char is None:
            return False
        target = self.skia_teammate() or self.find_element_reaction_target(self)
        return target is not None and target == from_char

    def _clear_defer_state(self) -> None:
        self.switch_deferred = False
        self.reaction_window_start = 0.0
        self.return_confirmed = False