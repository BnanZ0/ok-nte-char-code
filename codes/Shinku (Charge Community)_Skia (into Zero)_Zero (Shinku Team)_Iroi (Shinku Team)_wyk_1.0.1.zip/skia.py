"""翳的进场轮转: 只打 E(变轨攻击), 然后指定切给零。"""

from src.char.Skia import Skia
from src.char.Zero import Zero
from src.combat.planner import CombatContext, Planner, RoleProfile, SwitchDecision


class CommunitySkia(Skia):
    """进场后只放 E, 随后指定切给零。

    动作目录只有 E: 不放极轨终结, 不放弧盘, 也不站场普攻。E 在冷却时会被动作的
    ``can_execute`` 挡掉, entry 直接走到交人, 不空站场。E 只发一次按键就交人
    (见 ``_cast_skill_once``), 不等框架那套 CD 图标确认。

    交人用 ``task._switch_to_char()`` 指定目标切人 (``switch_next_char()`` 内部用的
    也是它, 但会先问 planner)。这样做是因为 planner 的环合反应(优先级 999500)会盖过
    普通切人请求(998000), 而 ``switch_other_char()`` 只会切索引最小的队友, 两者都
    保证不了"切给零"。

    直切只负责"这一下把站场交给零"; ``BaseChar.perform()`` 末尾还会无条件调用一次
    ``switch_next_char()``, 让 planner 重新选一次目标, 那时零只是普通候选, 会输给
    挂着的高优先目标 —— 真红的回场 claim(740) 就在其中。实测翳交人给零 0.2s 后就被
    真红抢走, 零连 E 都没放。所以交人成功后要跳过这次末尾决策(``_skip_final_switch``),
    条件与伊洛伊一致: 只有确认自己已经下场 (``is_current_char`` 为 False) 才跳过,
    交人失败时仍走正常流程, 保留兜底切人。
    """

    cn_name = "翳（进零队）"
    en_name = "Skia (into Zero)"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 翳不放弧盘, 关掉 `perform()` 开头的弧盘兜底按键。默认的
        # `planner_handles_arc = False` 会让每次上场先按一次 Q(弧盘键)。
        self.planner_handles_arc = True
        self._handoff_requested = False
        # 交人已在 entry flow 内完成时, perform() 末尾不再让 planner 决策一次。
        self._skip_final_switch = False

    def describe_role(self):
        """只做前场铺垫, 不站场, 也不使用内建站场兜底动作。"""
        return RoleProfile(
            role=Planner.Role.SUB_DPS,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self, context: CombatContext):
        """动作目录只有 E: 不放极轨终结, 也不碰弧盘。"""
        skill = self.planner_action(
            tags={Planner.ActionTag.SKILL_ACTION},
            slot=Planner.ActionSlot.SKILL,
            execute=self._cast_skill_once,
            name=f"{self}_skill",
            reason="opener skill",
            can_execute=lambda _: (
                self.is_current_char and not self.is_dead and self.skill_available()
            ),
            priority_ready=lambda _: self.skill_available(),
        )

        def entry():
            # 每轮进场都从头开始: 上一轮的交人状态不能影响本轮 (否则本轮交人失败时
            # 会误以为已经切过, 跳过 perform() 末尾的兜底切人)。
            self._handoff_requested = False
            self._skip_final_switch = False

            # 只放 E; E 在冷却时框架会跳过它, 流程直接走到交人。
            yield skill

            # 打完就交人, 交给零。
            self._request_handoff(context)

        return self.plan(skill, entry=entry)

    def _cast_skill_once(self, context: CombatContext = None):
        """按一次 E 就返回, 不等 CD 图标确认。

        框架的 ``click_skill`` 把这一次 E 交给 ``_try_available_action``: 它在 UI 还没
        画出 CD 之前**每轮循环都会重发一次按键**, 之后 ``_finish_skill_action`` 还要
        ``wait_until(get_cd("skill") > 0.3, time_out=1)`` 确认。实测翳"放完 E"到交人
        有 0.36~1.9 秒的反复按键和干等, 看起来就是在做别的事。这里只发一次键, 发完
        立刻回去交人。
        """
        if not self.is_current_char or self.is_dead or not self.skill_available():
            return False
        self.send_skill_key()
        return True

    def switch_next_char(self, post_action=None, free_intro=False):
        """交人已经在 entry flow 里完成后, 跳过 perform() 末尾的第二次切人。

        ``BaseChar.perform()`` 结束时会无条件调用 ``switch_next_char()``。翳已经在
        entry flow 里把站场指定交给了零, 这里再让 planner 决策一次就可能改目标:
        planner 只看候选评分, 不知道"刚交完人"这件事, 真红等角色的高优先 claim
        会立刻把零换下场, 轮转就被打乱成 翳 -> 真红。

        只跳过这一种情况: 确认自己已经下场 (交人真的切成功了)。交人失败或没交人时
        仍然走正常流程, 保留兜底切人。
        """
        if self._skip_final_switch and self.is_current_char is False:
            self.logger.info("handoff already done in combo, skip final switch_next_char")
            self.has_intro = False
            self._ultimate_available = self.ultimate_available()
            return
        super().switch_next_char(post_action=post_action, free_intro=free_intro)

    def _request_handoff(self, context: CombatContext) -> None:
        """把站场交给零; 零不在场或已阵亡时退化为按定位找队友。"""
        if self._handoff_requested:
            return
        self._handoff_requested = True

        target = self.zero_teammate()
        if target is not None:
            self.logger.info(f"handoff: switch to {target.ufn_name}")
            self.switch_to_teammate(target)
            # 交人已经完成切人, 不再让 perform() 末尾的 switch_next_char 决策一次。
            self._skip_final_switch = True
            return

        self.logger.info("no Zero teammate, request next sub dps")
        context.request_role(
            Planner.Role.SUB_DPS,
            reason="翳打完 E, 队伍里没有零, 交给下一个副C",
        )

    def switch_to_teammate(self, target) -> None:
        """指定目标切人, 绕过 planner 的环合反应优先级。"""
        self.task._switch_to_char(
            SwitchDecision(
                target=target,
                reason=f"{self.ufn_name} handoff",
                priority=0,
                has_intro=False,
            ),
            current_char=self,
        )

    def zero_teammate(self):
        """返回队伍里的零; 没有或已阵亡时返回 None。

        按 MRO 里的内置原型类(``Zero``)匹配: 这样社区子类(如
        ``CommunityZeroShinku``)也能命中, 同时不会把互为兄弟类的其他自定义角色
        误判进来 —— 直接用 ``isinstance`` 会把四个角色全部判成 True。
        """
        for teammate in self.task.chars:
            if teammate is None or teammate is self or teammate.is_dead:
                continue
            if Zero in type(teammate).__mro__:
                return teammate
        return None

    def reset_state(self):
        super().reset_state()
        self._handoff_requested = False
        self._skip_final_switch = False

    def on_combat_end(self, chars):
        self._handoff_requested = False
        self._skip_final_switch = False
        super().on_combat_end(chars)
