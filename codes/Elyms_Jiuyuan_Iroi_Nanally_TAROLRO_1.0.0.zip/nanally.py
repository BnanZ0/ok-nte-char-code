"""创生队 1234 轮切宝宝轴 - 4 号位娜娜莉(驻场).

排轴定位: E -> 等 E 段数伤害全部打出 -> Q -> 放空大脑站场普攻,
环合值打满(或到站场上限)就切回 1 号曳尔沐, 至此一轮循环结束.

视频原话: 娜娜莉进场以后先 e 再 q, 看到 e 技能所有段数的伤害都打出来
再开大, 接下来咱们就放空大脑, 该打闪避反击咱就打, 咱们血条左边的
环合值打满, 就可以切回 1 号曳尔沐, 1234 这样循环就可以了.

通过共享模块(elyms.py)获取全队排轴状态机, 本文件不持有状态机定义.
"""

import sys


def _load_team_module():
    """加载同目录 elyms.py 内的全队共享排轴核心(按 mtime 失效缓存)."""
    import importlib.util
    from pathlib import Path

    key = "_genesis_team_rotation_module"
    team_path = Path(__file__).resolve().with_name("elyms.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_NANALLY = _team.STAGE_NANALLY
get_rotation = _team.get_rotation
register_rotation_actions = _team.register_rotation_actions
log_stage = _team.log_stage

from src.char.BaseChar import BaseChar
from src.char.Nanally import Nanally as StockNanally
from src.combat.planner import Planner, RoleProfile


class GenesisNanally(_team.RotationMixin, StockNanally):
    cn_name = "创生队·娜娜莉"
    en_name = "Genesis · Nanally"
    element = BaseChar.ElementType.GREEN

    # 排轴时值(按实测微调)
    SKILL_ANIMATION_WAIT = 0.8
    FIELD_TIME = 6.0
    ATTACK_INTERVAL = 0.2

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.MAIN_DPS,
            max_field_time=3.0,
            combat_start_priority=0,
        )

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan)
        self.register_ultimate(plan)
        register_rotation_actions(plan, self)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        log_stage(self, rotation, stage)
        if stage == STAGE_NANALLY:
            self.click_skill()
            self.sleep(self.SKILL_ANIMATION_WAIT)
            self.click_ultimate()
            self.continues_normal_attack(
                self.FIELD_TIME,
                interval=self.ATTACK_INTERVAL,
                until_cycle_full=True,
            )
            self.rotation_next()
        else:
            self.logger.warning("[genesis] Nanally unexpected entry, fallback")
            if self.skill_available():
                self.click_skill()
            if self.ultimate_available():
                self.click_ultimate()
            self.rotation_retry()
