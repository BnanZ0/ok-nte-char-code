"""创生队 1234 轮切宝宝轴 - 2 号位九原.

排轴定位: E 挂致命玫约 -> Q 立即结算并回终结技能量 -> 立刻切 3 号伊洛伊.
通过共享模块(elyms.py)获取全队排轴状态机, 本文件不持有状态机定义.

视频原话: 切到 2 号九原, 就能直接打出创生反应, 这里先 e 再 q,
她的大招结算致命玫约, 并且回复她终结技能量.
"""

import sys


def _load_team_module():
    """加载同目录 elyms.py 内的全队共享排轴核心(按 mtime 失效缓存)."""
    import importlib.util
    from pathlib import Path

    key = "_genesis_team_rotation_module"
    team_path = Path(__file__).resolve().with_name("elyms.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_JIUYUAN = _team.STAGE_JIUYUAN
get_rotation = _team.get_rotation
register_rotation_actions = _team.register_rotation_actions
log_stage = _team.log_stage

from src.char.BaseChar import BaseChar
from src.char.Jiuyuan import Jiuyuan as StockJiuyuan
from src.combat.planner import Planner, RoleProfile


class GenesisJiuyuan(_team.RotationMixin, StockJiuyuan):
    cn_name = "创生队·九原"
    en_name = "Genesis · Jiuyuan"
    element = BaseChar.ElementType.GREEN

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUB_DPS,
            max_field_time=0.5,
            combat_start_priority=0,
        )

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan)
        self.register_ultimate(plan)
        register_rotation_actions(plan, self)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        log_stage(self, rotation, stage)
        if stage == STAGE_JIUYUAN:
            self.click_skill()
            self.click_ultimate()
            self.rotation_next()
        else:
            self.logger.warning("[genesis] Jiuyuan unexpected entry, fallback")
            self.click_skill()
            if self.ultimate_available():
                self.click_ultimate()
            self.rotation_retry()
