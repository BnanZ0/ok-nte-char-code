"""创生队 1234 轮切宝宝轴 - 全队共享排轴核心 + 1 号位曳尔沐.

教学来源: B 站 BV1o3xf6FEdc, UP 思考喵星人, 2026-11-05.
编队顺序: 1 曳尔沐(光) / 2 九原(灵) / 3 伊洛伊(灵) / 4 娜娜莉(灵).

轴(每轮一次, 闭着眼 1234 循环):
    1 曳尔沐: E -> E(强化变轨, 停表) -> 等光波伤害/环合满 -> Q -> 切 2
    2 九原  : E(挂致命玫约) -> Q(立即结算, 回能) -> 切 3
    3 伊洛伊: E -> Q -> Z(长按普攻出浮游炮) -> 点一下预输入 -> 切 4
             伊洛伊切走后会在后台打完剩余段数
    4 娜娜莉: E -> 等 E 段数伤害打完 -> Q -> 站场普攻到环合满 -> 切回 1

与内置通用脚本的差异:
    - 内置脚本各自按 CD 独立出招, 由 planner 评分自由切人.
      这里固定 1->2->3->4 顺序, 每个角色只在自己的阶段上场.
    - 通过 combat_policies 屏蔽元素反应自动改切, 否则创生反应会让
      planner 在 999500 优先级改切目标, 打断固定轮转.
    - 非排轴期望的入场(脱轴)走兜底分支, 不推进状态机并请求切回.

外置角色文件之间不能保证可靠 import, 四个文件通过固定的 sys.modules
key 共享本模块; 状态机实例挂在本场战斗的 task.genesis_rotation 属性上.

命名约定: 官方内置实现已占用角色本名(如 "Elyms" / "曳尔沐"), 自建出招表
必须换不同名字. UI 下拉显示为 "[外置代码] <目录> - <出招表名>", 内置则是
"[内置代码] 曳尔沐"; 为避免混淆, 搭配名前置: 本套统一为 "创生队·曳尔沐" /
"Genesis · Elyms", 开头即与内置及其他搭配不同. 脚本文件名仍沿用官方角色
英文名以便对照.

安装后绑定: 在队伍管理里把 "创生队 1234 轮切宝宝轴" 方案设为 [固定].
"""

import sys

from src.char.BaseChar import BaseChar
from src.char.Elyms import Elyms as StockElyms
from src.combat.planner import Planner, RoleProfile

# ---------------------------------------------------------------------------
# 阶段定义(全队共享)
# ---------------------------------------------------------------------------

STAGE_ELYMS = "elyms"
STAGE_JIUYUAN = "jiuyuan"
STAGE_IROI = "iroi"
STAGE_NANALLY = "nanally"

LOOP_STAGES = (
    STAGE_ELYMS,
    STAGE_JIUYUAN,
    STAGE_IROI,
    STAGE_NANALLY,
)

STAGE_OWNER = {
    STAGE_ELYMS: "GenesisElyms",
    STAGE_JIUYUAN: "GenesisJiuyuan",
    STAGE_IROI: "GenesisIroi",
    STAGE_NANALLY: "GenesisNanally",
}

ROTATION_ATTR = "genesis_rotation"


class GenesisRotation:
    """固定 1234 轮转的阶段指针, 挂在 task.genesis_rotation 上."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.cursor = 0
        self.rounds = 0

    def current_stage(self):
        return LOOP_STAGES[self.cursor]

    def current_owner(self):
        return STAGE_OWNER[self.current_stage()]

    def stage_for(self, char):
        """当前阶段归属该角色时返回阶段名, 否则返回 None(脱轴)."""
        if self.current_owner() == type(char).__name__:
            return self.current_stage()
        return None

    def advance(self):
        self.cursor = (self.cursor + 1) % len(LOOP_STAGES)
        if self.cursor == 0:
            self.rounds += 1


def get_rotation(task):
    """获取(或惰性创建)本场战斗的排轴状态机."""
    rotation = getattr(task, ROTATION_ATTR, None)
    if rotation is None:
        rotation = GenesisRotation()
        setattr(task, ROTATION_ATTR, rotation)
    return rotation


def find_teammate(char, owner_name):
    """按角色类名在队伍里查找队友对象."""
    for teammate in char.task.chars:
        if teammate is not None and type(teammate).__name__ == owner_name:
            return teammate
    return None


def request_rotation_next(char, rotation, reason):
    """请求切到下一阶段归属角色(必须在 action/entry 帧内调用)."""
    target = find_teammate(char, rotation.current_owner())
    if target is None:
        char.logger.warning(
            f"genesis rotation: teammate {rotation.current_owner()} not found"
        )
        return
    char.logger.info(
        f"[genesis] {type(char).__name__} done -> stage={rotation.current_stage()} "
        f"owner={rotation.current_owner()} rounds={rotation.rounds}"
    )
    char.combat_context.request_switch(target, reason=reason)


class RotationMixin:
    """收尾动作: 登记为 plan action, 在 action 帧内推进排轴并发布切人请求.

    planner 只在动作执行后回收请求; 生成器结束或 entry 末尾之后发布的请求
    可能被静默丢弃, 因此 advance + request_switch 必须放在已登记方法里.
    """

    def rotation_next(self):
        rotation = get_rotation(self.task)
        rotation.advance()
        request_rotation_next(self, rotation, "genesis rotation -> next slot")
        return True

    def rotation_retry(self):
        """脱轴兜底: 不推进状态机, 只请求切回当前阶段归属角色."""
        rotation = get_rotation(self.task)
        request_rotation_next(self, rotation, "genesis rotation -> retry current slot")
        return True


def register_rotation_actions(plan, char):
    """把两个收尾动作登记进 plan, 并让它们不参与切人评分."""
    plan.register(
        char.rotation_next,
        name=f"{type(char).__name__}_rotation_next",
        tags={Planner.ActionTag.DEFAULT_ACTION},
        reason="advance genesis rotation",
        priority_ready=lambda: False,
    )
    plan.register(
        char.rotation_retry,
        name=f"{type(char).__name__}_rotation_retry",
        tags={Planner.ActionTag.DEFAULT_ACTION},
        reason="retry genesis rotation without advancing",
        priority_ready=lambda: False,
    )


def log_stage(char, rotation, stage):
    char.logger.info(
        f"[genesis] {type(char).__name__} entry stage={stage} "
        f"current={rotation.current_stage()} rounds={rotation.rounds}"
    )


# ---------------------------------------------------------------------------
# 1 号位: 曳尔沐
# ---------------------------------------------------------------------------


class GenesisElyms(RotationMixin, StockElyms):
    cn_name = "创生队·曳尔沐"
    en_name = "Genesis · Elyms"
    element = BaseChar.ElementType.WHITE

    # 排轴时值(按实测微调)
    SKILL_RECHECK_TIMEOUT = 1.5
    CYCLE_WAIT_TIMEOUT = 1.0
    # 视频进阶版: 两个变轨技能之间穿插一套普攻攒信号, 宝宝轴默认关闭
    INSERT_ATTACK_BETWEEN_SKILLS = False
    INSERT_ATTACK_DURATION = 0.5

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUB_DPS,
            max_field_time=0.5,
            combat_start_priority=10,
        )

    def combat_policies(self):
        """每场战斗重置排轴, 并锁定固定切人(屏蔽元素反应自动改切)."""
        rotation = get_rotation(self.task)
        rotation.reset()
        self.logger.info("[genesis] rotation reset, element reaction retarget disabled")
        self.task.find_element_reaction_target = lambda source_char: None

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan, add_tags=Planner.ActionTag.HIGH_PRIORITY)
        self.register_ultimate(plan)
        register_rotation_actions(plan, self)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)
        log_stage(self, rotation, stage)
        if stage == STAGE_ELYMS:
            self.perform_double_skill()
            self.click_ultimate()
            self.rotation_next()
        else:
            self.logger.warning("[genesis] Elyms unexpected entry, fallback")
            self.click_skill()
            if self.ultimate_available():
                self.click_ultimate()
            self.rotation_retry()

    def perform_double_skill(self):
        """E -> 强化 E -> 等光波伤害/环合满.

        视频: 连续释放两次变轨技能, 强化 E 是停表的, 不用着急;
        看到光波打出伤害(创生反应)后再开大.
        """
        self.click_skill()
        if self.INSERT_ATTACK_BETWEEN_SKILLS:
            self.continues_normal_attack(self.INSERT_ATTACK_DURATION)
        self.task.wait_until(
            self.skill_available,
            post_action=self.click_with_interval,
            time_out=self.SKILL_RECHECK_TIMEOUT,
        )
        if not self.click_special_skill():
            self.click_skill()
        if not self.is_cycle_full():
            self.task.wait_until(
                self.is_cycle_full,
                post_action=self.click_with_interval,
                time_out=self.CYCLE_WAIT_TIMEOUT,
            )
        return True


# ---------------------------------------------------------------------------
# 共享模块注册
# ---------------------------------------------------------------------------
# 外置角色文件之间不能保证可靠 import. jiuyuan.py / iroi.py / nanally.py
# 通过 TEAM_MODULE_KEY 加载本文件获取排轴状态机; 本文件无论被注册器还是被
# 队友文件加载, 执行完毕时都把自己登记为共享模块(后执行的覆盖先执行的,
# 保证编辑后重新扫描拿到最新代码). 状态机实例挂在 task 上, 全局唯一.

TEAM_MODULE_KEY = "_genesis_team_rotation_module"

try:
    from pathlib import Path as _Path

    _TEAM_SOURCE_STAMP = _Path(__file__).resolve().stat().st_mtime_ns
except OSError:
    _TEAM_SOURCE_STAMP = None

sys.modules[TEAM_MODULE_KEY] = sys.modules[__name__]
