import sys


def _load_team_module():
    import importlib.util
    from pathlib import Path

    key = "_zankou_wheelchair_team_module"
    team_path = Path(__file__).resolve().with_name("zankou.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
record_battle_end = _team.record_battle_end
STAGE_OPEN_LINKO_QE = _team.STAGE_OPEN_LINKO_QE
STAGE_LOOP_LINKO_PASS = _team.STAGE_LOOP_LINKO_PASS
STAGE_LOOP_LINKO_QE = _team.STAGE_LOOP_LINKO_QE
STAGE_OPEN_ZANKOU_COMBO = _team.STAGE_OPEN_ZANKOU_COMBO
STAGE_LOOP_ZANKOU_COMBO = _team.STAGE_LOOP_ZANKOU_COMBO
get_rotation = _team.get_rotation
advance_rotation = _team.advance_rotation
diag_sleep = _team.diag_sleep
wait_sound_idle = _team.wait_sound_idle
send_ultimate_with_diag = _team.send_ultimate_with_diag
sound_action_stamp = _team.sound_action_stamp
sound_action_changed = _team.sound_action_changed
make_stage_none_handler = _team.make_stage_none_handler
_reset_and_switch_to_alive = _team._reset_and_switch_to_alive
_bind_rotation_logger = _team._bind_rotation_logger
ensure_switched_to_owner = _team.ensure_switched_to_owner
_is_char_on_field = _team._is_char_on_field

from src.char.Support import Support
from src.combat.planner import Planner, RoleProfile


class Linko(Support):
    cn_name = "灵可"
    en_name = "Linko"
    element = Support.ElementType.GREEN

    INTRO_WAIT = 0.5
    Q_POST_TIMEOUT = 4
    Q_POST_SEND_SLEEP = 0.1
    E1_TO_E2_WAIT = 1.5
    E2_TO_E3_WAIT = 1.5
    E3_TO_E4_WAIT = 2
    E4_TO_E5_WAIT = 3.3
    E5_TO_SELECT_WAIT = 1.3
    POST_SELECT_WAIT = 1
    E_FALLBACK_POST_SLEEP = 1
    Q_CHARGE_TIMEOUT = 5
    CHARGE_ATTACK_INTERVAL = 0.1
    SKILL_AFTER_SLEEP = 0.1
    MAX_STAGE_ATTEMPTS = 3
    STAGE_RETRY_SLEEP = 0.1
    ENABLE_LINKO_RESWITCH = True
    LINKO_RESWITCH_KEY_1 = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bind_rotation_logger(self)
        self.planner_handles_arc = True
        self._wait_switch_since = None

    def on_combat_end(self, chars):
        record_battle_end(self)
        super().on_combat_end(chars)

    def send_skill_key(
        self,
        after_sleep=0,
        interval=-1,
        down_time=0.05,
        action_name=None,
        wait_sound=True,
    ):
        # 故意绕过父类 send_skill_key：E1~E5 连发需要在 skill_available()=False 时
        # 仍能发键（父类会做 CD 门控导致第二次起被拦），因此这里仅复用父类的副作用
        # （_skill_available = False）并直接 send_key。若父类新增其他必要逻辑需同步到此。
        if wait_sound:
            wait_sound_idle(self, label="灵可·E发键")
        self._skill_available = False  # 无条件置位，和父类一致
        return self.send_key(
            self.get_skill_key(),
            interval=interval,
            down_time=down_time,
            after_sleep=after_sleep,
            action_name=action_name,
        )

    def send_ultimate_key(
        self, after_sleep=0, interval=-1, down_time=0.05, action_name=None, **_
    ):
        wait_sound_idle(self, label="灵可·Q发键")
        return super().send_ultimate_key(
            after_sleep=after_sleep,
            interval=interval,
            down_time=down_time,
            action_name=action_name,
        )

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def wait_intro(self, time_out=-1, click=True):
        if not self.has_intro:
            return
        if self.INTRO_WAIT > 0:
            self.logger.info(f"[灵可] INTRO_WAIT={self.INTRO_WAIT:.2f}s")
            diag_sleep(self, "灵可援护入场", self.INTRO_WAIT)
        else:
            self.logger.info("[灵可] INTRO_WAIT=0，跳过")

    def _ultimate_ready(self):
        value = self.ultimate_available()
        return bool(value) if value is not None else False

    def _charge_for_q(self):
        self.logger.info(
            f"[灵可] 循环轴 Q 不满，开始攒能（上限 {self.Q_CHARGE_TIMEOUT}s）"
        )
        start = self.clock.now()
        attacks = 0
        stamp = sound_action_stamp()
        while self.clock.now() - start <= self.Q_CHARGE_TIMEOUT:
            if self.is_dead:
                return False
            if self._ultimate_ready():
                try:
                    self.task.next_frame()
                except Exception:
                    pass
                if self._ultimate_ready():
                    self.logger.info(
                        f"[灵可] 攒能成功（双确认，普攻 {attacks} 次，"
                        f"耗时 {self.clock.now() - start:.2f}s）"
                    )
                    return True
                self.logger.info("[灵可] 攒能临界态：双确认失败，继续攒能")
            if sound_action_changed(stamp):
                self.logger.info("[灵可] 攒能检测到声音打断，补一次普攻保持段数")
                self.check_combat()
                self.click(interval=self.CHARGE_ATTACK_INTERVAL)
                stamp = sound_action_stamp()
                continue
            self.check_combat()
            self.click(interval=self.CHARGE_ATTACK_INTERVAL)
            stamp = sound_action_stamp()
            attacks += 1
        self.logger.warning(
            f"[灵可] 攒能 {self.Q_CHARGE_TIMEOUT}s 超时（普攻 {attacks} 次），强制放弃"
        )
        return False

    def _send_linko_e(self, step_label):
        if self.is_dead:
            return False
        try:
            self.task.next_frame()
        except Exception:
            pass
        if not self.is_current_char:
            self.logger.warning(f"[灵可] {step_label} 前已不在场，跳过发键")
            return False

        e_start = self.clock.now()
        send_ret = self.send_skill_key(
            down_time=0.05, wait_sound=False, after_sleep=self.SKILL_AFTER_SLEEP
        )
        e_actual = self.clock.now() - e_start
        self.logger.info(
            f"[诊断·E发键] {step_label} 返回={send_ret!r} 耗时 {e_actual:.2f}s"
        )
        if send_ret is False:
            return False
        return not self.is_dead

    def _block_q_eeee_e_select(self, select_key: str, target_name: str, is_loop=False):
        if self.is_dead:
            self.logger.warning("[灵可] 角色阵亡，跳过本段")
            return False

        try:
            self.task.next_frame()
        except Exception:
            pass

        # 强校验：Q/合击发出前必须确认切人真正生效，避免在错误角色或错误目标上执行
        if not self.is_current_char:
            wait_start = self.clock.now()
            while not self.is_current_char and self.clock.now() - wait_start < 2.5:
                if self.is_dead:
                    return False
                self.sleep(0.1, checks=self.SleepChecks.COMBAT)
                try:
                    self.task.next_frame()
                except Exception:
                    pass
            if not self.is_current_char:
                self.logger.warning(
                    "[灵可] _block_q_eeee_e_select 入口 2.5s 内未切到本角色，"
                    "返回 False 触发重试"
                )
                return False

        wait_sound_idle(self, label="灵可·入场稳定")

        q_ready = self._ultimate_ready()

        # 循环轴入场 Q 不满时尝试攒能；攒能失败直接走 fallback，
        # 不在攒能超时后立刻做无刷帧复查，避免 UI 临界值带来 Q 空跳。
        if is_loop and not q_ready:
            self.logger.info("[灵可] 循环轴入场 Q 不满，尝试攒能")
            q_ready = self._charge_for_q()
            if not q_ready:
                self.logger.warning("[灵可] 攒能失败，走 fallback（E + 合击）")

        if not q_ready:
            self.logger.warning(
                "[灵可] Q 不可用（已重查），跳过 Q-EEEE-E5，放 E + 合击"
            )
            try:
                self.task.next_frame()
            except Exception:
                pass
            e_ready = self.skill_available()
            if e_ready:
                e_start = self.clock.now()
                self.click_skill(down_time=0.05, post_sleep=self.E_FALLBACK_POST_SLEEP)
                self.logger.info(
                    f"[诊断·灵可E(fallback)] click_skill 耗时={self.clock.now()-e_start:.2f}s"
                )
                if self.is_dead:
                    return False
            else:
                self.logger.warning("[灵可] E 也不可用（已重查），仅合击")

            # Q 未过载时轮盘不会弹出，select_key 会被当作普通切人键，可能误切到非预期角色
            try:
                self.task.next_frame()
            except Exception:
                pass
            if not self.is_current_char:
                self.logger.info("[灵可] fallback 时已不在场，跳过合击发键避免误切")
                return not self.is_dead

            wait_sound_idle(self, label="灵可·合击(fallback)")
            # 与正常路径对齐：刷帧 + 稳定 0.1s，避免轮盘状态读到旧帧或按键与刷帧过近
            try:
                self.task.next_frame()
            except Exception:
                pass
            diag_sleep(
                self, "灵可合击前稳定(fallback)", 0.1, checks=self.SleepChecks.NONE
            )
            self.logger.info(f"[灵可] 按 {select_key} 同频合击 {target_name}")
            sel_ret = self.send_key(select_key, down_time=0.1)
            if sel_ret is False:
                self.logger.warning("[灵可] 合击 send_key 返回 False，判定合击失败")
                if self.POST_SELECT_WAIT > 0:
                    diag_sleep(
                        self,
                        "灵可合击失败后落定（失败）",
                        self.POST_SELECT_WAIT,
                        checks=self.SleepChecks.NONE,
                    )
                return False
            self.logger.info(
                f"灵可POST_SELECT_WAIT(fallback) 耗时={self.POST_SELECT_WAIT:.2f}s"
            )
            diag_sleep(
                self,
                "灵可合击后（fallback）",
                self.POST_SELECT_WAIT,
                checks=self.SleepChecks.COMBAT,
            )
            return not self.is_dead

        self.logger.info("[灵可] Q 进入过载")
        q_accepted = send_ultimate_with_diag(
            self, "灵可Q", self.Q_POST_TIMEOUT, self.Q_POST_SEND_SLEEP, retry=True
        )
        if self.is_dead:
            return False
        if not q_accepted:
            self.logger.warning(
                "[灵可] Q 未确认释放（内部重试用尽），跳过 E1~E4，仅按 E5 兜底"
            )

        if q_accepted:
            e_intervals = [
                ("灵可E1→E2", self.E1_TO_E2_WAIT),
                ("灵可E2→E3", self.E2_TO_E3_WAIT),
                ("灵可E3→E4", self.E3_TO_E4_WAIT),
                ("灵可E4→E5", self.E4_TO_E5_WAIT),
            ]
            for i, (label, wait) in enumerate(e_intervals):
                step_name = f"灵可E{i + 1}"
                self.logger.info(f"[灵可] {step_name}")
                if not self._send_linko_e(step_name):
                    self.logger.warning(
                        f"[灵可] {step_name} 发键失败，中止 E1~E4 后续等待"
                    )
                    return False
                if wait > 0:
                    diag_sleep(self, label, wait)
                if self.is_dead:
                    return False

        # E5（弹轮盘）
        self.logger.info("[灵可] E5（弹轮盘）")
        if not self._send_linko_e("灵可E5"):
            self.logger.warning("[灵可] E5 发键失败或已不在场，跳过轮盘等待")
            return False
        diag_sleep(self, "灵可E5起手观察", 0.4, checks=self.SleepChecks.NONE)
        try:
            self.task.next_frame()
        except Exception:
            pass

        if not q_accepted and not self.is_current_char:
            self.logger.info(
                "[灵可] Q 未确认释放且 E5 后已不在场，跳过合击等待直接结束本段"
            )
            return not self.is_dead

        if (
            self.is_current_char
            and not self.is_dead
            and not getattr(self.task, "in_animation", False)
            and self.skill_available()
        ):
            self.logger.warning("[灵可] E5 后仍在场且技能仍可用，补发 1 次 E5")
            self._send_linko_e("灵可E5补发")
            try:
                self.task.next_frame()
            except Exception:
                pass
            if not q_accepted and not self.is_current_char:
                self.logger.info("[灵可] E5 补发后已不在场，跳过合击等待直接结束本段")
                return not self.is_dead

        if self.E5_TO_SELECT_WAIT > 0:
            diag_sleep(self, "灵可E5→合击", self.E5_TO_SELECT_WAIT)
        if self.is_dead:
            return False

        try:
            self.task.next_frame()
        except Exception:
            pass
        if not q_accepted and not self.is_current_char:
            self.logger.info("[灵可] 到达合击前已不在场，跳过合击发键避免误切")
            return not self.is_dead

        self.logger.info(f"[灵可] 按 {select_key} 同频合击 {target_name}")
        sel_ret = self.send_key(select_key, down_time=0.1)
        if sel_ret is False:
            self.logger.warning("[灵可] 合击 send_key 返回 False，判定合击失败")
            if self.POST_SELECT_WAIT > 0:
                diag_sleep(
                    self,
                    "灵可合击失败后落定（失败）",
                    self.POST_SELECT_WAIT,
                    checks=self.SleepChecks.NONE,
                )
            return False

        if self.POST_SELECT_WAIT > 0:
            self.logger.info(f"[灵可] POST_SELECT_WAIT={self.POST_SELECT_WAIT:.2f}s")
            diag_sleep(
                self,
                "灵可合击后",
                self.POST_SELECT_WAIT,
                checks=self.SleepChecks.COMBAT,
            )
        return not self.is_dead

    def combat_plan(self):
        rotation = get_rotation(self.task)
        handle_none = make_stage_none_handler(self, rotation)

        def entry():
            _bind_rotation_logger(self)
            stage = rotation.stage_for(self)
            self.logger.info(f"[灵可入场] 阶段={stage}")

            if stage is None:
                handle_none()
                return
            self._wait_switch_since = None

            if self.is_dead:
                self.logger.warning("[灵可] 阵亡，重置轴")
                _reset_and_switch_to_alive(self, rotation, "灵可阵亡")
                return

            # —— 入场切人确认（保留原逻辑，只做一次）——
            if not self.is_current_char:
                wait_start = self.clock.now()
                while not self.is_current_char and self.clock.now() - wait_start < 1:
                    if self.is_dead:
                        _reset_and_switch_to_alive(self, rotation, "灵可切人前阵亡")
                        return
                    diag_sleep(
                        self,
                        "灵可入场切人确认",
                        0.1,
                        checks=self.SleepChecks.COMBAT,
                    )
                    try:
                        self.task.next_frame()
                    except Exception:
                        pass

            if not self.is_current_char and not self.is_dead:
                self.logger.warning(
                    f"[灵可] 阶段 {stage} 入口仍不在场，主动补发切人请求"
                )
                ensure_switched_to_owner(
                    self,
                    rotation,
                    target_name="Linko",
                    reason_prefix="linko_entry",
                    settle_wait=0.15,
                    retry_wait=0.1,
                    poll_interval=0.05,
                )

            # —— 阶段执行 + 重试循环 ——
            ok = False
            for attempt in range(1, self.MAX_STAGE_ATTEMPTS + 1):
                if self.is_dead:
                    self.logger.warning("[灵可] 角色阵亡，中断")
                    _reset_and_switch_to_alive(self, rotation, "灵可阵亡")
                    return
                try:
                    if stage == STAGE_OPEN_LINKO_QE:
                        if attempt == 1:
                            self.logger.info("[灵可] Q-EEEE-E5（启动轴）")
                        ok = self._block_q_eeee_e_select("1", "残虹", is_loop=False)
                    elif stage == STAGE_LOOP_LINKO_QE:
                        if attempt == 1:
                            self.logger.info("[灵可] Q-EEEE-E5（循环轴）")
                        ok = self._block_q_eeee_e_select("2", "达芙蒂尔", is_loop=True)
                    elif stage == STAGE_LOOP_LINKO_PASS:
                        if attempt == 1:
                            self.logger.info("[灵可] 过场")
                        ok = True
                    else:
                        self.logger.error(
                            f"[灵可异常] 未处理的阶段 {stage}，等待人工排查"
                        )
                        return
                except Exception as e:
                    err_name = type(e).__name__
                    if err_name == "TaskDisabledException":
                        raise
                    if err_name == "NotInCombatException":
                        self.logger.warning("[灵可] 脱战，向外抛出")
                        raise
                    self.logger.error(
                        f"[灵可异常] 第 {attempt}/{self.MAX_STAGE_ATTEMPTS} 次: {e}"
                    )
                    ok = False

                if ok:
                    break

                self.logger.warning(
                    f"[灵可] 阶段 {stage} 第 {attempt}/{self.MAX_STAGE_ATTEMPTS} 次失败"
                )
                if attempt < self.MAX_STAGE_ATTEMPTS:
                    diag_sleep(
                        self,
                        "灵可阶段重试前",
                        self.STAGE_RETRY_SLEEP,
                        checks=self.SleepChecks.COMBAT,
                    )

            if not ok:
                self.logger.error(
                    f"[灵可] 阶段 {stage} 达到最大重试次数，推进跳过避免死锁"
                )

            try:
                self.task.next_frame()
            except Exception:
                pass

            if self.is_dead:
                self.logger.warning("[灵可] 阶段完成后阵亡，重置轴")
                _reset_and_switch_to_alive(self, rotation, "灵可完成后阵亡")
                return

            advance_rotation(self, rotation)

            if self.ENABLE_LINKO_RESWITCH:
                if (
                    rotation.current_stage()
                    in (
                        STAGE_OPEN_ZANKOU_COMBO,
                        STAGE_LOOP_ZANKOU_COMBO,
                    )
                    and not self.is_dead
                ):
                    try:
                        self.task.next_frame()
                    except Exception:
                        pass
                    if not _is_char_on_field(self, "Zankou"):
                        switched = ensure_switched_to_owner(
                            self,
                            rotation,
                            target_name="Zankou",
                            reason_prefix="linko_combo_to_zankou",
                        )
                        if not switched and self.LINKO_RESWITCH_KEY_1:
                            zankou_alive = False
                            for t in getattr(self.task, "chars", []):
                                if (
                                    t is not None
                                    and type(t).__name__ == "Zankou"
                                    and not getattr(t, "is_dead", False)
                                ):
                                    zankou_alive = True
                                    break
                            try:
                                self.task.next_frame()
                            except Exception:
                                pass
                            if (
                                zankou_alive
                                and not self.is_dead
                                and not _is_char_on_field(self, "Zankou")
                            ):
                                self.logger.warning(
                                    f"[灵可] 阶段 {rotation.current_stage()} 切残虹未到位，执行 1 键复切"
                                )
                                self.send_key("1", down_time=0.1)
                                diag_sleep(
                                    self,
                                    "灵可1键复切后等待",
                                    0.1,
                                    checks=self.SleepChecks.NONE,
                                )
                                ensure_switched_to_owner(
                                    self,
                                    rotation,
                                    target_name="Zankou",
                                    reason_prefix="linko_key1_reswitch",
                                    settle_wait=0.15,
                                    retry_wait=0.1,
                                    poll_interval=0.05,
                                )

        return self.plan(entry=entry)
