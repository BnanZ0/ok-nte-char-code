import sys

from src.char.BaseChar import BaseChar
from src.char.Zankou import Zankou as StockZankou
from src.combat.planner import Planner, RoleProfile
from src.Labels import Labels

STAGE_OPEN_ZANKOU_PASS = "open_zankou_pass"
STAGE_OPEN_DAFFODILL_QE = "open_daffodill_qe"
STAGE_OPEN_BLACKBIRD_E_Q1 = "open_blackbird_e_q1"
STAGE_OPEN_DAFFODILL_R = "open_daffodill_r"
STAGE_OPEN_BLACKBIRD_Q2 = "open_blackbird_q2"
STAGE_OPEN_LINKO_QE = "open_linko_qe"
STAGE_OPEN_ZANKOU_COMBO = "open_zankou_combo"

STAGE_LOOP_LINKO_PASS = "loop_linko_pass"
STAGE_LOOP_BLACKBIRD_E_Q1 = "loop_blackbird_e_q1"
STAGE_LOOP_DAFFODILL_QRE = "loop_daffodill_qre"
STAGE_LOOP_BLACKBIRD_Q2 = "loop_blackbird_q2"
STAGE_LOOP_LINKO_QE = "loop_linko_qe"
STAGE_LOOP_ZANKOU_COMBO = "loop_zankou_combo"

STAGE_OWNER = {
    STAGE_OPEN_ZANKOU_PASS: "Zankou",
    STAGE_OPEN_DAFFODILL_QE: "Daffodill",
    STAGE_OPEN_BLACKBIRD_E_Q1: "Blackbird",
    STAGE_OPEN_DAFFODILL_R: "Daffodill",
    STAGE_OPEN_BLACKBIRD_Q2: "Blackbird",
    STAGE_OPEN_LINKO_QE: "Linko",
    STAGE_OPEN_ZANKOU_COMBO: "Zankou",
    STAGE_LOOP_LINKO_PASS: "Linko",
    STAGE_LOOP_BLACKBIRD_E_Q1: "Blackbird",
    STAGE_LOOP_DAFFODILL_QRE: "Daffodill",
    STAGE_LOOP_BLACKBIRD_Q2: "Blackbird",
    STAGE_LOOP_LINKO_QE: "Linko",
    STAGE_LOOP_ZANKOU_COMBO: "Zankou",
}

OPENING_STAGES = [
    STAGE_OPEN_ZANKOU_PASS,
    STAGE_OPEN_DAFFODILL_QE,
    STAGE_OPEN_BLACKBIRD_E_Q1,
    STAGE_OPEN_DAFFODILL_R,
    STAGE_OPEN_BLACKBIRD_Q2,
    STAGE_OPEN_LINKO_QE,
    STAGE_OPEN_ZANKOU_COMBO,
]
LOOP_STAGES = [
    STAGE_LOOP_LINKO_PASS,
    STAGE_LOOP_BLACKBIRD_E_Q1,
    STAGE_LOOP_DAFFODILL_QRE,
    STAGE_LOOP_BLACKBIRD_Q2,
    STAGE_LOOP_LINKO_QE,
    STAGE_LOOP_ZANKOU_COMBO,
]

WINDOW_RE_CLAIM_TIMEOUT = 3
WINDOW_RE_CLAIM_POLL = 0.1
MAX_STAGE_ATTEMPTS = 3
WAIT_SWITCH_TIMEOUT = 3
CHAR_ULT_LOG_INTERVAL = 2
ROTATION_LOG_ENABLED = False
_MUTED_LOG_LEVELS = ("debug", "info", "warning")


class _NoopLogger:
    def __init__(self, wrapped):
        self._wrapped = wrapped

    def __getattr__(self, name):
        if not ROTATION_LOG_ENABLED and name in _MUTED_LOG_LEVELS:
            return lambda *args, **kwargs: None
        return getattr(self._wrapped, name)


def _bind_rotation_logger(char):
    logger = getattr(char, "logger", None)
    if logger is None or getattr(logger, "_is_rotation_noop_logger", False):
        return
    wrapped = _NoopLogger(logger)
    try:
        wrapped._is_rotation_noop_logger = True
        char.logger = wrapped
    except Exception:
        pass


def _install_ult_poll_log_throttle(task, min_interval=CHAR_ULT_LOG_INTERVAL):
    if task is None or getattr(task, "_zankou_ult_log_throttled", False):
        return
    orig_ult_available = getattr(task, "ultimate_available", None)
    if not callable(orig_ult_available):
        return

    last_logged = {}

    def _wrapped_ultimate_available(index, *args, **kwargs):
        orig_log_info = getattr(task, "log_info", None)
        now = 0
        try:
            now = task.clock.now()
        except Exception:
            pass

        def _filtered_log_info(msg, *l_args, **l_kwargs):
            text = str(msg)
            if text.startswith("char:") and "ult:" in text and "conf:" in text:
                is_ready = "ult:True" in text
                prev = last_logged.get(index, -1e9)
                if not is_ready and (now - prev) < min_interval:
                    return
                last_logged[index] = now
            if callable(orig_log_info):
                return orig_log_info(msg, *l_args, **l_kwargs)

        try:
            if callable(orig_log_info):
                task.log_info = _filtered_log_info
            return orig_ult_available(index, *args, **kwargs)
        finally:
            if callable(orig_log_info):
                task.log_info = orig_log_info

    try:
        task.ultimate_available = _wrapped_ultimate_available
        task._zankou_ult_log_throttled = True
    except Exception:
        pass


def diag_sleep(char, label, duration, checks=None):
    if duration <= 0:
        return
    start = char.clock.now()
    check_sound = duration >= 0.3
    stamp_before = sound_action_stamp() if check_sound else None
    if checks is not None:
        char.sleep(duration, checks=checks)
    else:
        char.sleep(duration, checks=char.SleepChecks.NONE)
    actual = char.clock.now() - start
    interrupted = ""
    if check_sound:
        if sound_action_stamp() != stamp_before:
            interrupted = " ⚡sound"
    diff = actual - duration
    tag = ""
    if diff < -0.1:
        tag = " 提前"
    elif diff > 0.15:
        tag = " 超时"
    char.logger.info(
        f"[诊断·sleep] {label} 设{duration:.2f} 实{actual:.2f}{interrupted}{tag}"
    )


def diag_normal_attack(char, label="", interval=0.1):
    start = char.clock.now()
    char.check_combat()
    char.click(interval=interval)
    actual = char.clock.now() - start
    if actual > 0.15:
        char.logger.info(f"[诊断·普攻] {label} 耗时 {actual:.2f}s（偏长）")
    return actual


def diag_read_q(char, label):
    try:
        return bool(char.ultimate_available())
    except Exception as e:
        char.logger.warning(f"[诊断·Q读取异常] {label}: {e}")
        return None


def wait_sound_idle(char, max_wait=0.3, poll=0.05, label=""):
    try:
        from src.sound_trigger.SoundCombatContext import SoundCombatContext

        ctx = SoundCombatContext()
    except Exception:
        return

    def _active():
        try:
            return bool(SoundCombatContext.should_interrupt_combat())
        except TypeError:
            try:
                return bool(ctx.should_interrupt_combat())
            except Exception:
                return False
        except Exception:
            return False

    if not _active():
        return
    try:
        if hasattr(ctx, "is_bound_to") and not ctx.is_bound_to(char.task):
            return
    except Exception:
        pass

    start = char.clock.now()
    waited = False
    while char.clock.now() - start < max_wait:
        if not _active():
            if waited:
                char.logger.info(
                    f"[诊断·sound静默] {label} 等{char.clock.now()-start:.2f}s"
                )
            return
        waited = True
        char.sleep(poll, checks=char.SleepChecks.SOUND)
    char.logger.warning(
        f"[诊断·sound静默超时] {label} 等{char.clock.now()-start:.2f}s仍活跃"
    )


def wait_is_in_team_then_sleep(
    char,
    label,
    timeout,
    post_sleep=0.05,
    enter_anim_timeout=1,
    sample_interval=0.05,
):
    enter_start = char.clock.now()
    entered_anim = False
    phase1_elapsed = 0
    while True:
        if char.is_dead:
            char.logger.warning(f"[{label}] 阶段采样期间阵亡，提前返回")
            return
        elapsed = char.clock.now() - enter_start
        if elapsed >= enter_anim_timeout:
            break
        try:
            char.task.next_frame()
        except Exception:
            pass
        try:
            state = bool(char.task.is_in_team())
        except Exception:
            state = None
        if state is False:
            entered_anim = True
            phase1_elapsed = elapsed
            break
        remain = enter_anim_timeout - elapsed
        char.sleep(min(sample_interval, remain), checks=char.SleepChecks.NONE)

    if not entered_anim:
        char.logger.info(f"[{label}] 阶段1 {enter_anim_timeout}s 内未进入脱队动画")
        if post_sleep > 0:
            diag_sleep(char, f"{label} post", post_sleep)
        return

    char.logger.info(f"[{label}] 阶段1 进入脱队动画 @ {phase1_elapsed:.2f}s")

    end_start = char.clock.now()
    detected_at = None
    while True:
        if char.is_dead:
            char.logger.warning(f"[{label}] 阶段2 采样期间阵亡，提前返回")
            return

        try:
            char.task.next_frame()
        except Exception:
            pass
        try:
            state = bool(char.task.is_in_team())
        except Exception:
            state = None
        if state is True:
            detected_at = char.clock.now() - end_start
            break
        remain = timeout - (char.clock.now() - end_start)
        if remain <= 0:
            break
        char.sleep(min(sample_interval, remain), checks=char.SleepChecks.NONE)

    total = char.clock.now() - enter_start
    if detected_at is not None:
        char.logger.info(
            f"[{label}] 阶段2 脱队动画结束（总 {total:.2f}s，动画段 {detected_at:.2f}s，timeout {timeout}s）"
        )
    else:
        char.logger.warning(
            f"[{label}] 阶段2 is_in_team 超时 {total:.2f}s（timeout {timeout}s），继续"
        )
    if post_sleep > 0:
        diag_sleep(char, f"{label} post", post_sleep)


def send_ultimate_with_diag(
    char, label, timeout, post_sleep, retry=False, max_attempts=2
):
    attempt = 0
    accepted = False
    while attempt < max_attempts:
        attempt += 1
        before = diag_read_q(char, f"{label} 发前#{attempt}")
        char.logger.info(f"[诊断·Q] {label} 发前#{attempt} available={before}")

        char.send_ultimate_key(down_time=0.05, action_name=f"ultimate_send_{label}")
        char.sleep(0.1, checks=char.SleepChecks.NONE)

        after = diag_read_q(char, f"{label} 发后#{attempt}")
        char.logger.info(f"[诊断·Q] {label} 发后#{attempt} available={after}")

        if after is False:
            accepted = True
            break
        elif after is True:
            if retry and attempt < max_attempts:
                char.logger.warning(
                    f"[吞Q诊断] {label} 第 {attempt} 次发键后仍亮，准备重试"
                )
                wait_sound_idle(char, label=f"{label}重试前")
                diag_sleep(char, f"{label}重试前", 0.1)
                continue
            else:
                if retry:
                    char.logger.warning(
                        f"[吞Q诊断] {label} 第 {attempt} 次发键后仍亮，重试用尽"
                    )
                else:
                    char.logger.warning(f"[吞Q诊断] {label} 发键后仍亮（未启用重试）")
                break
        else:
            char.logger.warning(f"[诊断·Q] {label} 发后#{attempt} 读取异常")
            break

    wait_is_in_team_then_sleep(
        char, f"{label} POST", timeout=timeout, post_sleep=post_sleep
    )

    if char.is_dead:
        return accepted
    try:
        char.task.next_frame()
    except Exception:
        return accepted
    post = diag_read_q(char, f"{label} 发后POST")
    char.logger.info(f"[诊断·Q] {label} 发后POST available={post}")

    if accepted and post is True:
        char.logger.info(f"[吞Q] {label} 已接收，POST 时 CD 已恢复（非吞Q）")
    return accepted


def sound_action_stamp():
    try:
        from src.sound_trigger.SoundCombatContext import SoundCombatContext

        ctx = SoundCombatContext()
        listener = getattr(ctx, "listener", None)
        if listener is None:
            return (0,)
        return (getattr(listener, "_last_trigger_time", 0),)
    except Exception:
        return (0,)


def sound_action_changed(stamp):
    return sound_action_stamp() != stamp


def record_battle_end(char):
    """任何角色战斗结束时调用，统一记录 session 和时间戳到共享 rotation。"""
    _bind_rotation_logger(char)
    rotation = get_rotation(char.task)
    rotation._battle_end_time = char.clock.now()
    rotation._battle_end_session = getattr(char.task, "combat_session", None)
    char.logger.info(
        f"[排轴] {type(char).__name__} 记录战斗结束 session"
        f"（id={id(rotation._battle_end_session)}）"
    )


class ZankouWheelchairRotation:
    _is_zankou_wheelchair_rotation = True

    def __init__(self):
        self._boss_approached = False
        self.reset()

    def reset(self, new_battle=False):
        self.queue = list(OPENING_STAGES)
        self._battle_end_time = 0
        self._battle_end_session = None
        if new_battle:
            self._boss_approached = False

    def current_stage(self):
        return self.queue[0] if self.queue else None

    def current_owner(self):
        return STAGE_OWNER.get(self.current_stage(), "") if self.current_stage() else ""

    def stage_for(self, char):
        stage = self.current_stage()
        if stage and STAGE_OWNER.get(stage) == type(char).__name__:
            return stage
        return None

    def advance(self):
        if self.queue:
            self.queue.pop(0)
        if not self.queue:
            self.queue = list(LOOP_STAGES)


ROTATION_ATTR = "zankou_wheelchair_rotation"


def get_rotation(task):
    rotation = getattr(task, ROTATION_ATTR, None)
    if not getattr(rotation, "_is_zankou_wheelchair_rotation", False):
        rotation = ZankouWheelchairRotation()
        setattr(task, ROTATION_ATTR, rotation)
        task.find_element_reaction_target = lambda source_char: None
    return rotation


def find_teammate(char, owner_name):
    for t in char.task.chars:
        if t is not None and type(t).__name__ == owner_name:
            return t
    return None


def _is_char_on_field(char, name):
    target = find_teammate(char, name)
    if target is None or getattr(target, "is_dead", False):
        return False
    try:
        curr = char.task.get_current_char()
        if curr is target:
            return True
    except Exception:
        pass
    return bool(getattr(target, "is_current_char", False))


def ensure_switched_to_owner(
    char,
    rotation,
    target_name=None,
    reason_prefix="switch",
    settle_wait=0.15,
    retry_wait=0.1,
    poll_interval=0.05,
):
    resolved_name = target_name or rotation.current_owner()
    if not resolved_name:
        return True
    target = find_teammate(char, resolved_name)
    if target is None or getattr(target, "is_dead", False):
        return False

    # 观察期：entry() 内部切人要等 perform() 返回后才执行，仅做短窗口快速确认后即走补发
    if settle_wait > 0:
        observe_start = char.clock.now()
        while (char.clock.now() - observe_start) < settle_wait:
            try:
                char.task.next_frame()
            except Exception:
                pass
            if _is_char_on_field(char, resolved_name):
                return True
            if getattr(target, "is_dead", False):
                return False
            diag_sleep(
                char,
                f"{reason_prefix}·切人观察轮询",
                min(
                    poll_interval,
                    max(0.01, settle_wait - (char.clock.now() - observe_start)),
                ),
                checks=None,
            )
        char.logger.info(
            f"[切人观察] {reason_prefix} 观察 {settle_wait:.2f}s 后仍未切到 "
            f"{resolved_name}（阶段 {rotation.current_stage()}），进入补发"
        )

    char.logger.warning(
        f"[切人维护] 目标 {resolved_name} 未在场（阶段 {rotation.current_stage()}），补发切人请求"
    )
    try:
        _safe_request_switch(
            char,
            target,
            reason=f"re-switch({reason_prefix}) -> {rotation.current_stage()}",
        )
    except Exception as e:
        char.logger.warning(f"[切人维护] 补发 request_switch 失败: {e}")

    if retry_wait > 0:
        retry_start = char.clock.now()
        while (char.clock.now() - retry_start) < retry_wait:
            try:
                char.task.next_frame()
            except Exception:
                pass
            if _is_char_on_field(char, resolved_name):
                return True
            if getattr(target, "is_dead", False):
                return False
            diag_sleep(
                char,
                f"{reason_prefix}·复切等待轮询",
                min(
                    poll_interval,
                    max(0.01, retry_wait - (char.clock.now() - retry_start)),
                ),
                checks=None,
            )
    try:
        char.task.next_frame()
    except Exception:
        pass
    return _is_char_on_field(char, resolved_name)


def _find_next_alive_target(char, rotation):
    max_skip = len(OPENING_STAGES) + len(LOOP_STAGES)
    for _ in range(max_skip):
        target_name = rotation.current_owner()
        target = find_teammate(char, target_name) if target_name else None
        if target is not None and not target.is_dead:
            return target, target_name
        char.logger.warning(
            f"[排轴跳过] {rotation.current_stage()} owner={target_name} "
            f"已死或不存在，跳过该阶段"
        )
        try:
            target_is_dead = (
                getattr(target, "is_dead", None) if target is not None else None
            )
            chars_info = []
            for t in char.task.chars:
                if t is None:
                    continue
                chars_info.append(
                    f"{type(t).__name__}(dead={getattr(t, 'is_dead', None)})"
                )
            char.logger.warning(
                f"[排轴跳过诊断] target_name={target_name} "
                f"target={'存在' if target is not None else 'None'} "
                f"is_dead={target_is_dead} "
                f"chars_count={len(chars_info)} chars={chars_info}"
            )
        except Exception as e:
            char.logger.warning(f"[排轴跳过诊断] 诊断异常：{e}")
        rotation.advance()
    return None, None


def _safe_request_switch(char, target, reason):
    if target is None or getattr(target, "is_dead", False):
        return False
    if not getattr(char.task, "_in_combat", True):
        char.logger.info(f"[排轴] 已不在战斗中，跳过切人请求: {reason}")
        return False
    try:
        char.combat_context.request_switch(target, reason=reason)
        return True
    except RuntimeError as e:
        if "inactive planner cycle" in str(e):
            char.logger.warning(
                f"[排轴] planner 周期已结束，忽略切人请求 ({reason}): {e}"
            )
            return False
        raise


def _reset_and_switch_to_alive(char, rotation, reason):
    """重置轴后跳过 dead 角色，切到第一个活着的角色。"""
    rotation.reset()
    target, target_name = _find_next_alive_target(char, rotation)
    if target is None:
        char.logger.error(
            f"[{type(char).__name__}] {reason} 重置后找不到活着的角色，等待外部恢复"
        )
        return False
    char.logger.info(
        f"[{type(char).__name__}] {reason} 重置后找到活着的角色 {target_name}，"
        f"队列头 {rotation.current_stage()}"
    )
    if target is not char:
        _safe_request_switch(
            char, target, reason=f"wheelchair reset -> {rotation.current_stage()}"
        )
    return True


def advance_rotation(char, rotation):
    old_stage = rotation.current_stage()

    try:
        char.task.next_frame()
    except Exception:
        pass

    rotation.advance()

    target, target_name = _find_next_alive_target(char, rotation)
    char.logger.info(
        f"[排轴推进] {type(char).__name__} 完成 {old_stage} -> 推进至 {rotation.current_stage()}"
    )

    if target is None:
        char.logger.warning(
            f"[排轴警告] 推进后找不到活着的队友 {target_name}，重置轴到启动轴"
        )
        _reset_and_switch_to_alive(char, rotation, "排轴推进失败")
        return

    if target is char:
        char.logger.info(f"[排轴推进] 下一阶段仍为 {target_name}，原地继续")
        return

    curr_char = getattr(char.task, "get_current_char", lambda **_: None)(
        raise_exception=False
    )
    char.logger.info(
        f"[排轴切换] curr={type(curr_char).__name__ if curr_char else None} "
        f"{type(char).__name__} -> {target_name} "
        f"(stage={rotation.current_stage()}, target_dead={target.is_dead})"
    )
    _safe_request_switch(
        char, target, reason=f"wheelchair -> {rotation.current_stage()}"
    )


def make_stage_none_handler(char, rotation):
    def _handle():
        now = char.clock.now()

        current_owner_name = rotation.current_owner()
        current_owner = (
            find_teammate(char, current_owner_name) if current_owner_name else None
        )
        if current_owner is None or current_owner.is_dead:
            char.logger.warning(
                f"[{type(char).__name__}] 队列头角色 {current_owner_name} 已死或不存在"
                f"（阶段 {rotation.current_stage()}），立即重置轴跳过"
            )
            char._wait_switch_since = None
            _reset_and_switch_to_alive(
                char,
                rotation,
                f"队列头 {current_owner_name} 死亡",
            )
            return

        if getattr(char, "_wait_switch_since", None) is None:
            char._wait_switch_since = now
        waited = now - char._wait_switch_since

        if waited > WAIT_SWITCH_TIMEOUT:
            target = find_teammate(char, current_owner_name)
            if target is not None and not target.is_dead:
                char.logger.warning(
                    f"[{type(char).__name__}] 等待切人超时 {waited:.1f}s，"
                    f"重新 request_switch 到 {current_owner_name}"
                )
                char._wait_switch_since = now  # 重置计时
                ensure_switched_to_owner(
                    char,
                    rotation,
                    target_name=current_owner_name,
                    reason_prefix="none_handler_timeout",
                    settle_wait=0.25,
                    retry_wait=0.2,
                    poll_interval=0.05,
                )
            else:
                _reset_and_switch_to_alive(
                    char,
                    rotation,
                    f"等待切人超时 {waited:.1f}s",
                )
            return

        char.logger.info(
            f"[{type(char).__name__}] 当前非本角色阶段"
            f"（{rotation.current_stage()}），等待切人 {waited:.1f}s"
        )

    return _handle


class Zankou(StockZankou):
    cn_name = "残虹"
    en_name = "Zankou"
    element = BaseChar.ElementType.RED

    INTRO_WAIT = 0
    HEAVY_ATTACK_HOLD = 2
    PURPLE_E_POST_SLEEP = 1
    SECOND_ZA_INTERVAL = 1
    YELLOW_E_POLL_TIMEOUT = 18
    E_POLL_TIMEOUT = 7
    Q2_POLL_TIMEOUT = 6
    Q2_POST_TIMEOUT = 6
    Q2_POST_SEND_SLEEP = 0.05
    Q2_POST_SLEEP = 0.75
    YELLOW_E_WAIT_TIMEOUT = 5  # max_total_wait
    YELLOW_E_FAST_RETRY_INTERVAL = 0.2  # fast_retry_interval
    LOOP2PLUS_YELLOW_E_RETRIES = 5  # max_retries
    MAX_YELLOW_E_MISS_TIME = 6
    YELLOW_E_STALE_DISAPPEAR_SEC = 2.2
    ENABLE_APPROACH_BOSS = True
    APPROACH_DODGE_KEY = "lshift"
    APPROACH_FORWARD_KEY = "w"
    APPROACH_MOUSE_RELEASE_WAIT = 0.05
    APPROACH_W_PRESS_WAIT = 0.05
    APPROACH_DODGE_INTERVAL = 0.2
    APPROACH_DODGE_DOWN_TIME = 0.1
    APPROACH_FINAL_WAIT = 0.05
    STAGE_RETRY_SLEEP = 0.1
    # 第 2 轮及以后（loop_count >= 2）查黄E策略开关（第 1 轮固定 za_rounds=1）：
    # - LOOP2PLUS_DOUBLE_ZA=True  : 打 2 组 ZA（优先级高于 LOOP2PLUS_USE_ZA）
    # - LOOP2PLUS_DOUBLE_ZA=False 且 LOOP2PLUS_USE_ZA=True : 打 1 组 ZA
    # - 两者皆 False : 走 _loop_na_until_yellow_e 连续普攻查黄E
    LOOP2PLUS_DOUBLE_ZA = True
    LOOP2PLUS_USE_ZA = False

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bind_rotation_logger(self)
        self.planner_handles_arc = True
        self._wait_switch_since = None
        _install_ult_poll_log_throttle(getattr(self, "task", None))

    def send_skill_key(
        self, after_sleep=0, interval=-1, down_time=0.05, action_name=None, **_
    ):
        wait_sound_idle(self, label="残虹·E发键")
        return super().send_skill_key(
            after_sleep=after_sleep,
            interval=interval,
            down_time=down_time,
            action_name=action_name,
        )

    def send_ultimate_key(
        self, after_sleep=0, interval=-1, down_time=0.05, action_name=None, **_
    ):
        wait_sound_idle(self, label="残虹·Q发键")
        return super().send_ultimate_key(
            after_sleep=after_sleep,
            interval=interval,
            down_time=down_time,
            action_name=action_name,
        )

    def send_arc_key(self, after_sleep=0, interval=-1, down_time=0.05, **_):
        wait_sound_idle(self, label="残虹·R发键")
        return super().send_arc_key(
            after_sleep=after_sleep, interval=interval, down_time=down_time
        )

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.MAIN_DPS,
            field_preference=Planner.FieldPreference.MAIN_DPS,
            max_field_time=0,
            combat_start_priority=10,
        )

    def combat_policies(self):
        _bind_rotation_logger(self)
        _install_ult_poll_log_throttle(getattr(self, "task", None))
        rotation = get_rotation(self.task)
        current_session = getattr(self.task, "combat_session", None)
        end_session = getattr(rotation, "_battle_end_session", None)
        battle_end_time = getattr(rotation, "_battle_end_time", 0)
        elapsed = self.clock.now() - battle_end_time if battle_end_time > 0 else -1

        self.logger.info(
            f"[排轴诊断] combat_session id={id(current_session)}, "
            f"end_session id={id(end_session) if end_session is not None else None}, "
            f"session_same={end_session is not None and current_session is end_session}, "
            f"elapsed={elapsed:.2f}s"
        )

        if end_session is not None and current_session is not end_session:
            rotation.reset(new_battle=True)
            self.logger.info(
                f"[排轴] 新战斗（session 变更，上次结束 {elapsed:.2f}s 前），重置到启动轴"
            )
        elif end_session is not None:
            self.logger.info(
                f"[排轴] 脱战重开（session 未变，间隔 {elapsed:.2f}s），"
                f"保持队列 stage={rotation.current_stage()}"
            )
        else:
            rotation.reset(new_battle=True)
            self.logger.info("[排轴] 首次加载，重置到启动轴")

        self.task.find_element_reaction_target = lambda source_char: None

    def on_combat_end(self, chars):
        record_battle_end(self)
        super().on_combat_end(chars)

    def _retry_block(self, name, block_func, max_attempts=3):
        for attempt in range(1, max_attempts + 1):
            if attempt > 1:
                self.logger.warning(f"[{name}] 第 {attempt - 1} 次重试")
                if not self.is_current_char or getattr(
                    self.task, "combat_detect_uncertain", False
                ):
                    self.logger.info(
                        f"[{name}] 重试前等待状态落定"
                        f"（is_current_char={self.is_current_char}，"
                        f"combat_detect_uncertain="
                        f"{getattr(self.task, 'combat_detect_uncertain', False)}）"
                    )
                    diag_sleep(
                        self,
                        f"{name}重试前(切人/状态未定)",
                        0.1,
                        checks=self.SleepChecks.COMBAT,
                    )
                else:
                    diag_sleep(
                        self,
                        f"{name}重试前(常规)",
                        0.1,
                        checks=self.SleepChecks.COMBAT,
                    )
            if self.is_dead:
                self.logger.warning(f"[{name}] 角色阵亡，终止")
                return False
            try:
                if block_func():
                    return True
            except Exception as e:
                err_name = type(e).__name__
                if err_name == "TaskDisabledException":
                    raise
                if err_name == "NotInCombatException":
                    self.logger.warning(f"[{name}] 检测到脱战，直接向外抛出: {e}")
                    raise
                self.logger.warning(f"[{name}] 执行异常（{err_name}），准备重试: {e}")
        self.logger.error(f"[{name}] 达到最大重试次数，放弃")
        return False

    def _approach_boss(self):
        if self.is_dead:
            return
        if not self.ENABLE_APPROACH_BOSS:
            self.logger.info(
                "[残虹] 接近BOSS已禁用（ENABLE_APPROACH_BOSS=False），跳过"
            )
            return
        rotation = get_rotation(self.task)
        if getattr(rotation, "_boss_approached", False):
            self.logger.info("[残虹] 本场战斗已接近过BOSS，跳过重复移动")
            return

        try:
            self.task.mouse_up("left")
            self.logger.info("[残虹] 清除鼠标左键残留状态")
        except Exception as e:
            self.logger.warning(f"[残虹] mouse_up('left') 失败：{e}")
        if self.APPROACH_MOUSE_RELEASE_WAIT > 0:
            diag_sleep(self, "首切·清残留", self.APPROACH_MOUSE_RELEASE_WAIT)

        self.logger.info(
            "[残虹] 首切接近BOSS：按住W（task.send_key_down/send_key_up）"
            f" + W预热 {self.APPROACH_W_PRESS_WAIT}s"
            f" + 2次闪避（按键{self.APPROACH_DODGE_KEY}，单套，"
            f"按下{self.APPROACH_DODGE_DOWN_TIME}s，间隔{self.APPROACH_DODGE_INTERVAL}s）"
            f" + 收尾{self.APPROACH_FINAL_WAIT}s"
        )
        try:
            self.task.send_key_down(self.APPROACH_FORWARD_KEY)
        except Exception as e:
            self.logger.error(f"[残虹] task.send_key_down 失败，跳过接近BOSS移动：{e}")
            return
        # logger.info 也放进带 finally 的 try：任何异常路径下 W 都会被释放
        try:
            self.logger.info(
                f"[残虹] W 已按住，等 {self.APPROACH_W_PRESS_WAIT}s 让游戏识别方向"
            )
            diag_sleep(self, "首切·W预热", self.APPROACH_W_PRESS_WAIT)
            if self.is_dead:
                return
            self.send_key(
                self.APPROACH_DODGE_KEY, down_time=self.APPROACH_DODGE_DOWN_TIME
            )
            diag_sleep(self, "首切·闪避1后", self.APPROACH_DODGE_INTERVAL)
            if self.is_dead:
                return
            self.send_key(
                self.APPROACH_DODGE_KEY, down_time=self.APPROACH_DODGE_DOWN_TIME
            )
            diag_sleep(self, "首切·闪避2后收尾", self.APPROACH_FINAL_WAIT)
        finally:
            try:
                self.task.send_key_up(self.APPROACH_FORWARD_KEY)
                self.logger.info("[残虹] W 已松开")
            except Exception as e:
                self.logger.error(f"[残虹] task.send_key_up 失败：{e}")
        rotation._boss_approached = True
        self.logger.info("[残虹] 接近BOSS移动完成（本场战斗标记已接近）")

    def _run_stage_with_retry(self, func, label, max_attempts=MAX_STAGE_ATTEMPTS):
        for attempt in range(1, max_attempts + 1):
            if self.is_dead:
                self.logger.warning(f"[残虹] {label} 角色阵亡，中断")
                return False
            try:
                success = func()
            except Exception as e:
                err_name = type(e).__name__
                if err_name == "TaskDisabledException":
                    raise
                if err_name == "NotInCombatException":
                    self.logger.warning(f"[残虹{label}] 脱战，向外抛出")
                    raise
                self.logger.error(f"[残虹{label}异常] {e}")
                success = False
            if success:
                self.logger.info(f"[残虹] {label} 成功（第 {attempt} 次）")
                return True
            self.logger.warning(f"[残虹] {label} 第 {attempt}/{max_attempts} 次失败")
            if attempt < max_attempts:
                diag_sleep(
                    self,
                    f"{label}阶段重试前",
                    self.STAGE_RETRY_SLEEP,
                    checks=self.SleepChecks.COMBAT,
                )
        self.logger.error(f"[残虹] {label} 达到最大重试次数 {max_attempts}")
        return False

    def combat_plan(self):
        _install_ult_poll_log_throttle(getattr(self, "task", None))
        rotation = get_rotation(self.task)
        handle_none = make_stage_none_handler(self, rotation)

        def entry():
            _bind_rotation_logger(self)
            stage = rotation.stage_for(self)
            self.logger.info(f"[残虹入场] 阶段={stage}")

            if stage is None:
                handle_none()
                return
            self._wait_switch_since = None

            if self.is_dead:
                self.logger.warning("[残虹] 阵亡，重置轴")
                _reset_and_switch_to_alive(self, rotation, "残虹阵亡")
                return
            if stage == STAGE_OPEN_ZANKOU_PASS:
                try:
                    self._approach_boss()
                except Exception as e:
                    err_name = type(e).__name__
                    if err_name in ("TaskDisabledException", "NotInCombatException"):
                        raise
                    self.logger.error(f"[残虹过场异常] {e}")
                if self.is_dead:
                    self.logger.warning("[残虹] 过场后阵亡，重置轴")
                    _reset_and_switch_to_alive(self, rotation, "残虹过场后阵亡")
                    return
                advance_rotation(self, rotation)
            elif stage in (STAGE_OPEN_ZANKOU_COMBO, STAGE_LOOP_ZANKOU_COMBO):
                self.logger.info(
                    "[残虹动作] 大循环：前置Q1-Q2 → 循环(ZA-黄E-一直A-紫E)直到状态满足"
                )
                success = self._run_stage_with_retry(
                    self.perform_macro_loop, "大循环", max_attempts=1
                )
                if self.is_dead:
                    self.logger.warning("[残虹] 大循环后阵亡，重置轴")
                    _reset_and_switch_to_alive(self, rotation, "残虹大循环后阵亡")
                    return
                if not success:
                    self.logger.warning("[残虹] 大循环失败，推进后由后续段兜底")
                advance_rotation(self, rotation)
            else:
                self.logger.error(f"[残虹异常] 未处理的阶段 {stage}，等待人工排查")
                return

        return self.plan(entry=entry)

    def wait_intro(self, time_out=-1, click=True):
        if self.has_intro:
            if self.INTRO_WAIT > 0:
                self.logger.info(f"[残虹] INTRO_WAIT={self.INTRO_WAIT:.2f}s")
                diag_sleep(self, "残虹援护入场", self.INTRO_WAIT)
            else:
                self.logger.info("[残虹] INTRO_WAIT=0，跳过")

    def _ultimate_ready(self):
        value = self.ultimate_available()
        return bool(value) if value is not None else False

    def _check_exit_condition(self, refresh=True):
        if not self.is_cycle_full():
            return False

        # 分离两个条件，残虹紫Q 用图像识别二次确认
        bb_q_ready = self._blackbird_q_ready_silent()
        zk_q_ready = self._ultimate_ready()
        if zk_q_ready:
            try:
                self.task.next_frame()
            except Exception:
                pass
            if not self.find_ult_purple():
                self.logger.info(
                    "[残虹大循环] 残虹紫Q 框架API误判为亮，图像识别未亮，忽略"
                )
                zk_q_ready = False

        if not (zk_q_ready or bb_q_ready):
            return False
        if refresh:
            try:
                self.task.next_frame()
            except Exception:
                pass
            if not self.is_cycle_full():
                self.logger.info(
                    "[残虹大循环] 退出条件双确认失败（环合不满），继续大循环"
                )
                return False
            bb_q_ready2 = self._blackbird_q_ready_silent()
            zk_q_ready2 = False
            if self._ultimate_ready():
                try:
                    self.task.next_frame()
                except Exception:
                    pass
                if self.find_ult_purple():
                    zk_q_ready2 = True
            if not (zk_q_ready2 or bb_q_ready2):
                self.logger.info(
                    "[残虹大循环] 退出条件双确认失败（紫Q图像/黑羽Q 不满足），继续大循环"
                )
                return False
        self.logger.info("[残虹大循环] 满足环合 + (残虹紫Q图像 或 黑羽Q)，退出循环")
        return True

    def perform_macro_loop(self):
        self.logger.info("[残虹大循环] 开始")
        if not self.is_current_char:
            if not self._wait_on_field("大循环进场"):
                self.logger.warning("[残虹大循环] 未切到残虹，放弃本轮大循环")
                return False
        q12_done = self._block_q12()
        if not q12_done:
            self.logger.warning("[残虹大循环] Q1-Q2 未完成（紫Q未亮或Q1释放失败）")

        loop_start = self.clock.now()
        yellow_miss_start = None
        loop_count = 0
        MAX_MACRO_LOOP_TIME = 45
        exit_ok = False

        while True:
            if self.is_dead:
                return False

            elapsed = self.clock.now() - loop_start
            if elapsed > MAX_MACRO_LOOP_TIME:
                self.logger.warning(
                    f"[残虹大循环] 达到 {MAX_MACRO_LOOP_TIME}s 上限，结束本阶段并推进"
                )
                break

            loop_count += 1
            self.logger.info(
                f"[残虹大循环] 开始第 {loop_count} 轮（已耗时 {elapsed:.1f}s）"
            )

            if yellow_miss_start is None:
                yellow_miss_start = self.clock.now()

            if loop_count == 1:
                yellow_finder = lambda: self._loop_za_until_yellow_e(
                    za_rounds=1, is_loop2plus=False
                )
            elif self.LOOP2PLUS_DOUBLE_ZA:
                yellow_finder = lambda: self._loop_za_until_yellow_e(
                    za_rounds=2, is_loop2plus=True
                )
            elif self.LOOP2PLUS_USE_ZA:
                yellow_finder = lambda: self._loop_za_until_yellow_e(
                    za_rounds=1, is_loop2plus=True
                )
            else:
                yellow_finder = self._loop_na_until_yellow_e

            yellow_ok = self._retry_block(
                "残虹大循环黄E", yellow_finder, max_attempts=3
            )

            if not yellow_ok:
                miss_total = self.clock.now() - yellow_miss_start
                self.logger.warning(
                    f"[残虹大循环] 第 {loop_count} 轮黄E失败，累计黄E未亮 {miss_total:.1f}s"
                )
                if miss_total > self.MAX_YELLOW_E_MISS_TIME:
                    self.logger.warning(
                        f"[残虹大循环] 连续黄E未亮 {miss_total:.1f}s "
                        f"超过 {self.MAX_YELLOW_E_MISS_TIME:.1f}s，退出大循环交给队友"
                    )
                    break
                continue

            yellow_miss_start = None
            if self._check_exit_condition():
                exit_ok = True
                break

            if not self._retry_block(
                "残虹大循环紫E", self._loop_until_purple_e, max_attempts=3
            ):
                self.logger.warning(f"[残虹大循环] 第 {loop_count} 轮紫E失败，继续尝试")

            if loop_count == 1 and not q12_done:
                if self.is_dead:
                    return False
                try:
                    self.task.next_frame()
                except Exception:
                    pass
                if self.find_ult_purple():
                    self.logger.info("[残虹大循环] 第 1 轮结束后紫Q亮起，释放 Q1-Q2")
                    if self._block_q12():
                        q12_done = True
                        diag_sleep(
                            self,
                            "残虹Q1Q2收尾落定",
                            0.1,
                            checks=self.SleepChecks.NONE,
                        )
                        if self._check_exit_condition():
                            exit_ok = True
                            break
                else:
                    self.logger.info("[残虹大循环] 第 1 轮结束后紫Q未亮，后续不再检查")

            if self._check_exit_condition():
                exit_ok = True
                break

        return exit_ok

    def _sleep_yellow_e_poll(self, iter_idx):
        poll_checks = (
            self.SleepChecks.COMBAT if (iter_idx % 8 == 0) else self.SleepChecks.NONE
        )
        self.sleep(0.06, checks=poll_checks)

    def _trigger_yellow_e(
        self,
        start_time,
        max_total_wait=5,
        fast_retry_interval=0.1,
        max_retries=10,
        allow_poke=True,
    ):
        self.logger.info(
            f"[残虹大循环] 检测到黄E（{self.clock.now() - start_time:.2f}s），发E并毫秒级轮询状态"
        )
        try:
            self.task.mouse_up("left")
        except Exception:
            pass

        sent_when_available = False
        last_sent_at = None
        last_sent_iter = None
        iter_idx = 0
        last_retry_time = None
        if self.skill_available(check_color=False):
            send_ret = self.send_skill_key(
                down_time=0.05, after_sleep=0.05, action_name="zankou_yellow_e"
            )
            self.logger.info(f"[诊断·黄E首发] send_skill_key 返回={send_ret!r}")
            if send_ret is not False:
                sent_when_available = True
                now_sent = self.clock.now()
                last_sent_at = now_sent
                last_sent_iter = 0
                last_retry_time = now_sent
            else:
                self.logger.warning(
                    "[残虹大循环] 黄E首发 send_skill_key 返回 False，视为未发出"
                )
        else:
            self.logger.warning(
                "[残虹大循环] 黄E亮但E在共享CD，首发跳过，在总窗口内等待抢点"
            )
        send_at = self.clock.now()
        if self._check_exit_condition():
            self.logger.info(
                f"[诊断·黄E] 发键后 {self.clock.now() - send_at:.3f}s 即满足退出条件，"
                f"黄E 图标={self.find_zankou_skill()}"
            )
            return True

        wait_start = start_time  # 统一以黄E亮起时刻作为 t=0 起点
        max_cd_wait = max_total_wait
        max_yellow_retries = max(0, int(max_retries))
        retry_interval = 0.55
        effective_retry_interval = (
            fast_retry_interval
            if (fast_retry_interval is not None and fast_retry_interval > 0)
            else retry_interval
        )
        retries_exhausted_confirm = 0.55 if max_yellow_retries >= 3 else 0.35
        poke_interval = 0.1
        retry_count = 0
        last_poke_time = self.clock.now() - poke_interval
        exhausted_at = None

        while not self.is_dead and (self.clock.now() - wait_start) < max_cd_wait:
            iter_idx += 1
            try:
                self.task.next_frame()
            except Exception:
                pass
            if self.find_zankou_skill() != Labels.zankou_skill_gold:
                break

            if self._check_exit_condition():
                return True

            now = self.clock.now()

            if not self.skill_available(check_color=False):
                if allow_poke and (now - last_poke_time) >= poke_interval:
                    self.check_combat()
                    self.click(interval=0.1)
                    last_poke_time = self.clock.now()
                    if self._check_exit_condition():
                        return True
                self._sleep_yellow_e_poll(iter_idx)
                continue

            if retry_count < max_yellow_retries and (
                last_retry_time is None
                or (now - last_retry_time) >= effective_retry_interval
            ):
                retry_count += 1
                self.logger.warning(f"[残虹大循环] 黄E仍亮，第 {retry_count} 次补发 E")
                send_ret = self.send_skill_key(
                    down_time=0.05,
                    after_sleep=0.05,
                    action_name="zankou_yellow_e_retry",
                )
                self.logger.info(
                    f"[诊断·黄E补发#{retry_count}] send_skill_key 返回={send_ret!r}"
                )
                now_after = self.clock.now()
                if send_ret is not False:
                    sent_when_available = True
                    last_sent_at = now_after
                    last_sent_iter = iter_idx
                else:
                    self.logger.warning(
                        f"[残虹大循环] 黄E第 {retry_count} 次补发 send_skill_key 返回 False"
                    )
                last_retry_time = now_after
                if retry_count >= max_yellow_retries:
                    exhausted_at = now_after
            elif (
                max_yellow_retries > 0
                and exhausted_at is not None
                and (now - exhausted_at) >= retries_exhausted_confirm
            ):
                try:
                    self.task.next_frame()
                except Exception:
                    pass
                if self.find_zankou_skill() != Labels.zankou_skill_gold:
                    break
                self.logger.warning(
                    f"[残虹大循环] 黄E补发 {retry_count} 次后确认窗内仍未熄灭，提前退出"
                )
                break
            else:
                if allow_poke and (now - last_poke_time) >= poke_interval:
                    self.check_combat()
                    self.click(interval=0.1)
                    last_poke_time = self.clock.now()
                    if self._check_exit_condition():
                        return True

            self._sleep_yellow_e_poll(iter_idx)

        try:
            self.task.mouse_up("left")
        except Exception:
            pass

        try:
            self.task.next_frame()
        except Exception:
            pass
        if self.find_zankou_skill() == Labels.zankou_skill_gold:
            if self.is_dead:
                self.logger.warning("[残虹大循环] 黄E未熄灭但角色已阵亡")
                return False
            self.logger.warning(
                f"[残虹大循环] 黄E补发 {retry_count} 次仍未熄灭（耗时 "
                f"{self.clock.now() - wait_start:.2f}s），返回 False 触发外层重试"
            )
            return False

        if not sent_when_available or last_sent_at is None or last_sent_iter is None:
            self.logger.warning(
                "[残虹大循环] 黄E已灭但全程E在共享CD或未成功发键，非本次点掉；"
                "返回 False"
            )
            return False

        # 发键后超过阈值时间才熄灭且非紧邻轮次，视为疑似自行熄灭（抗卡帧误杀）
        since_last_sent = self.clock.now() - last_sent_at
        if (
            iter_idx - last_sent_iter
        ) > 6 and since_last_sent > self.YELLOW_E_STALE_DISAPPEAR_SEC:
            self.logger.warning(
                f"[残虹大循环] 黄E已灭但距离上次成功发键已过 {since_last_sent:.2f}s"
                f"（>{self.YELLOW_E_STALE_DISAPPEAR_SEC:.2f}s），疑似自行熄灭；返回 False"
            )
            return False

        self.logger.info(
            f"[残虹大循环] 黄E已释放（{'首发成功' if retry_count == 0 else f'补发{retry_count}次'}，"
            f"耗时 {self.clock.now() - wait_start:.2f}s）"
        )
        return True

    def _loop_za_until_yellow_e(self, za_rounds=1, is_loop2plus=False):
        start = self.clock.now()
        poll_round = 0
        attacks = 0

        while (
            not self.is_dead and (self.clock.now() - start) < self.YELLOW_E_POLL_TIMEOUT
        ):
            if not self.is_current_char:
                if not self._wait_on_field("查黄E(ZA)"):
                    return False

            # 循环开始先查退出
            if self._check_exit_condition():
                return True

            poll_round += 1
            for combo_idx in range(za_rounds):
                if (
                    self.is_dead
                    or (self.clock.now() - start) >= self.YELLOW_E_POLL_TIMEOUT
                ):
                    return False
                if not self.is_current_char:
                    if not self._wait_on_field(f"查黄E(ZA#{combo_idx + 1})"):
                        return False

                round_start = self.clock.now()
                try:
                    self.task.mouse_up("left")
                except Exception:
                    pass
                self.check_combat()
                try:
                    self.task.next_frame()
                except Exception:
                    pass
                diag_sleep(
                    self,
                    f"ZA轮{poll_round}#{combo_idx + 1}·Z前落定",
                    0.1,
                    checks=self.SleepChecks.COMBAT,
                )

                h_start = self.clock.now()
                self.heavy_attack(self.HEAVY_ATTACK_HOLD)
                try:
                    self.task.mouse_up("left")
                except Exception:
                    pass
                self.sleep(0.1, checks=self.SleepChecks.NONE)
                h_actual = self.clock.now() - h_start

                is_mid_za = za_rounds > 1 and combo_idx < za_rounds - 1
                if is_loop2plus:
                    trig_kwargs = {
                        "max_total_wait": self.YELLOW_E_WAIT_TIMEOUT,
                        "fast_retry_interval": self.YELLOW_E_FAST_RETRY_INTERVAL,
                        "max_retries": self.LOOP2PLUS_YELLOW_E_RETRIES,
                        "allow_poke": True,
                    }
                elif is_mid_za:
                    trig_kwargs = {
                        "max_total_wait": self.YELLOW_E_WAIT_TIMEOUT,
                        "fast_retry_interval": self.YELLOW_E_FAST_RETRY_INTERVAL,
                    }
                else:
                    trig_kwargs = {
                        "max_total_wait": self.YELLOW_E_WAIT_TIMEOUT,
                    }
                try:
                    self.task.next_frame()
                except Exception:
                    pass
                if self.find_zankou_skill() == Labels.zankou_skill_gold:
                    lit_time = self.clock.now()
                    # 第一套ZA的Z后若正卡共享CD，不在此死等，直接打A消化CD后再抢点
                    if not is_mid_za or self.skill_available(check_color=False):
                        if self._trigger_yellow_e(lit_time, **trig_kwargs):
                            return True
                        if is_mid_za:
                            self.logger.info(
                                f"[残虹大循环] ZA轮{poll_round}#{combo_idx + 1}·Z后黄E未打出，继续第二套ZA"
                            )

                diag_sleep(
                    self,
                    f"ZA轮{poll_round}#{combo_idx + 1}·Z后",
                    0.1,
                    checks=self.SleepChecks.COMBAT,
                )
                if self._check_exit_condition():
                    return True
                try:
                    self.task.mouse_up("left")
                except Exception:
                    pass

                a_actual = diag_normal_attack(
                    self, f"ZA轮{poll_round}#{combo_idx + 1}·A", interval=0.1
                )
                attacks += 1

                diag_sleep(
                    self,
                    f"ZA轮{poll_round}#{combo_idx + 1}·A后",
                    0.1,
                    checks=self.SleepChecks.COMBAT,
                )
                if self._check_exit_condition():
                    return True

                try:
                    self.task.next_frame()
                except Exception:
                    pass
                round_total = self.clock.now() - round_start
                is_yellow = self.find_zankou_skill() == Labels.zankou_skill_gold
                if round_total > 3 or is_yellow or za_rounds > 1:
                    self.logger.info(
                        f"[诊断·ZA轮{poll_round}#{combo_idx + 1}/{za_rounds}] "
                        f"heavy={h_actual:.2f}s A={a_actual:.2f}s "
                        f"总={round_total:.2f}s 黄E={'亮' if is_yellow else '否'}"
                    )

                if is_yellow:
                    lit_time = self.clock.now()
                    if self._trigger_yellow_e(lit_time, **trig_kwargs):
                        return True
                    if is_mid_za:
                        self.logger.info(
                            f"[残虹大循环] ZA轮{poll_round}#{combo_idx + 1}·A后黄E未打出，继续第二套ZA"
                        )

                if combo_idx < za_rounds - 1 and self.SECOND_ZA_INTERVAL > 0:
                    diag_sleep(
                        self,
                        f"ZA轮{poll_round}·两次ZA间隔",
                        self.SECOND_ZA_INTERVAL,
                        checks=self.SleepChecks.COMBAT,
                    )

        return False

    def _loop_na_until_yellow_e(self):
        if self.is_dead:
            return False
        self.logger.info("[残虹大循环] 后续轮次：连打普攻查黄E")
        start = self.clock.now()
        attacks = 0

        try:
            self.task.mouse_up("left")
            self.task.next_frame()
        except Exception:
            pass

        while self.clock.now() - start < self.YELLOW_E_POLL_TIMEOUT:
            if self.is_dead:
                return False

            if not self.is_current_char:
                if not self._wait_on_field("查黄E(NA)"):
                    return False

            # 循环开始先查退出
            if self._check_exit_condition():
                return True

            round_start = self.clock.now()
            a_actual = diag_normal_attack(self, f"NA轮{attacks + 1}·A", interval=0.1)

            diag_sleep(
                self, f"NA轮{attacks + 1}·A后", 0.1, checks=self.SleepChecks.COMBAT
            )
            if self._check_exit_condition():
                return True

            try:
                self.task.next_frame()
            except Exception:
                pass
            round_total = self.clock.now() - round_start
            is_yellow = self.find_zankou_skill() == Labels.zankou_skill_gold
            if round_total > 3 or is_yellow:
                self.logger.info(
                    f"[诊断·NA轮{attacks + 1}] A={a_actual:.2f}s 总={round_total:.2f}s "
                    f"黄E={'亮' if is_yellow else '否'}"
                )

            if is_yellow:
                lit_time = self.clock.now()
                return self._trigger_yellow_e(lit_time)

            attacks += 1

        self.logger.warning(f"[残虹大循环] 普攻查黄E超时（{attacks} 段普攻）")
        return False

    def _loop_until_purple_e(self):
        if self.is_dead:
            return False
        start = self.clock.now()
        attacks = 0
        last_combat_check = 0
        last_bb_q_check = 0
        cached_bb_q_ready = False
        last_zk_q_check = 0
        cached_zk_q_ready = False
        zk_q_check_interval = 0.5
        last_purple_wait_yellow_at = -999
        purple_wait_yellow_min_interval = 1.5

        while self.clock.now() - start < self.E_POLL_TIMEOUT:
            if self.is_dead:
                return False
            if not self.is_current_char:
                if not self._wait_on_field("查紫E"):
                    return False

            try:
                self.task.next_frame()
            except Exception:
                pass

            now = self.clock.now()

            # 0. 等紫E期间顺手处理亮起的黄E（按完不退出本阶段，继续等紫E）
            # 直接复用黄E触发/补发逻辑处理黄E，完成后回到外层继续普攻等紫E；
            # 两次处理间隔节流避免刷屏。
            if (
                self.find_zankou_skill() == Labels.zankou_skill_gold
                and (now - last_purple_wait_yellow_at)
                >= purple_wait_yellow_min_interval
            ):
                last_purple_wait_yellow_at = now
                self.logger.info(
                    f"[残虹大循环] 等紫E期间检测到黄E（{now - start:.2f}s），调用黄E处理后继续等紫E"
                )
                try:
                    self.task.mouse_up("left")
                except Exception:
                    pass

                self._trigger_yellow_e(
                    now,
                    max_total_wait=2,
                    fast_retry_interval=0.15,
                    max_retries=5,
                    allow_poke=True,
                )
                last_purple_wait_yellow_at = self.clock.now()

                try:
                    self.task.mouse_up("left")
                except Exception:
                    pass
                if self._check_exit_condition():
                    return True
                continue

            # 1. 紫E最高优先级：亮起即刻触发并快速重试
            if self.find_zankou_skill() == Labels.zankou_skill_purple:
                self.logger.info(
                    f"[残虹大循环] 检测到紫E（{self.clock.now() - start:.2f}s），即刻发E"
                )
                try:
                    self.task.mouse_up("left")
                except Exception:
                    pass
                self.send_skill_key(
                    down_time=0.05, after_sleep=0.05, action_name="zankou_purple_e"
                )

                purple_confirm_start = self.clock.now()
                purple_confirm_timeout = 0.55
                while (
                    not self.is_dead
                    and (self.clock.now() - purple_confirm_start)
                    < purple_confirm_timeout
                ):
                    try:
                        self.task.next_frame()
                    except Exception:
                        pass
                    if (
                        self.find_zankou_skill() != Labels.zankou_skill_purple
                        and not getattr(self.task, "in_animation", False)
                    ):
                        break
                    self.sleep(0.08, checks=self.SleepChecks.NONE)

                retry = 0
                while (
                    not self.is_dead
                    and self.find_zankou_skill() == Labels.zankou_skill_purple
                    and retry < 2
                ):
                    retry += 1
                    self.logger.warning(f"[残虹大循环] 紫E仍亮，第 {retry} 次补发")
                    try:
                        self.task.mouse_up("left")
                    except Exception:
                        pass
                    self.send_skill_key(
                        down_time=0.05,
                        after_sleep=0.05,
                        action_name=f"zankou_purple_e_retry{retry}",
                    )
                    retry_confirm_start = self.clock.now()
                    while (
                        not self.is_dead
                        and (self.clock.now() - retry_confirm_start) < 0.45
                    ):
                        try:
                            self.task.next_frame()
                        except Exception:
                            pass
                        if (
                            self.find_zankou_skill() != Labels.zankou_skill_purple
                            and not getattr(self.task, "in_animation", False)
                        ):
                            break
                        self.sleep(0.08, checks=self.SleepChecks.NONE)

                if (
                    not self.is_dead
                    and self.find_zankou_skill() == Labels.zankou_skill_purple
                ):
                    self.logger.warning(
                        "[残虹大循环] 紫E多次发键后仍亮，返回 False 触发外层重试"
                    )
                    try:
                        self.task.mouse_up("left")
                    except Exception:
                        pass
                    return False
                if self.is_dead:
                    return False
                try:
                    self.task.mouse_up("left")
                except Exception:
                    pass
                if self.PURPLE_E_POST_SLEEP > 0:
                    diag_sleep(
                        self,
                        "残虹紫E后缓冲",
                        self.PURPLE_E_POST_SLEEP,
                        checks=self.SleepChecks.COMBAT,
                    )
                try:
                    self.task.mouse_up("left")
                except Exception:
                    pass
                return True

            if now - last_combat_check >= 0.35:
                self.check_combat()
                last_combat_check = now

            # 2. 节流刷新黑羽 Q 状态（每 0.75s 一次，避免低 conf 高频空查）
            if now - last_bb_q_check >= 0.75:
                cached_bb_q_ready = self._blackbird_q_ready_silent()
                last_bb_q_check = now

            # 3. 节流刷新紫Q 状态，避免每轮两次 OCR
            if now - last_zk_q_check >= zk_q_check_interval:
                cached_zk_q_ready = self._ultimate_ready()
                last_zk_q_check = now

            # 4. 紫E未亮时检查退出（刚 next_frame 过，refresh=False）
            if self.is_cycle_full() and (cached_zk_q_ready or cached_bb_q_ready):
                if self._check_exit_condition(refresh=False):
                    return True

            # 5. 普攻一次，并在每个 A 后检查退出
            self.click(interval=0.1)
            attacks += 1
            if self.is_cycle_full() and (cached_zk_q_ready or cached_bb_q_ready):
                if self._check_exit_condition():
                    return True

        self.logger.warning(f"[残虹大循环] 查紫E超时（{attacks} 次普攻）")
        return False

    def _block_q12(self):
        if self.is_dead:
            return False

        # 切人刚完成时（如合击后 char index fallback 过渡），短等当前角色状态落稳再读紫Q
        if not self.is_current_char:
            settle_start = self.clock.now()
            while not self.is_current_char and (self.clock.now() - settle_start) < 0.5:
                if self.is_dead:
                    return False
                self.sleep(0.1, checks=self.SleepChecks.NONE)
                try:
                    self.task.next_frame()
                except Exception:
                    pass

        self.logger.info("[残虹诊断] 开始诊断紫Q状态")
        has_purple = False
        for i in range(2):
            try:
                self.task.next_frame()
            except Exception:
                pass
            has_purple = self.find_ult_purple()
            self.logger.info(
                f"[残虹诊断] 第 {i + 1}/2 次读紫Q: {'亮' if has_purple else '未亮'}"
            )
            if has_purple:
                break
            diag_sleep(self, f"读紫Q{i + 1}之间", 0.1, checks=self.SleepChecks.COMBAT)

        if not has_purple:
            diag_sleep(
                self, "紫Q未亮二次确认缓冲", 0.05, checks=self.SleepChecks.COMBAT
            )
            try:
                self.task.next_frame()
            except Exception:
                pass
            has_purple = self.find_ult_purple()
            self.logger.info(f"[残虹诊断] 补查紫Q: {'亮' if has_purple else '未亮'}")

        if not has_purple:
            self.logger.warning("[残虹] 紫Q未亮，跳过 Q1-Q2")
            return False

        self.logger.info("[残虹] Q1 释放")
        q1_start = self.clock.now()
        q1_ok = self.click_ultimate()
        self.logger.info(
            f"[诊断·残虹Q1] click_ultimate 返回={q1_ok} 耗时={self.clock.now()-q1_start:.2f}s"
        )
        if not q1_ok:
            self.logger.warning("[残虹] Q1 释放失败")
            return False

        if self.is_dead:
            return False

        q2_start = self.clock.now()
        q2_success = False
        last_q2_check = q2_start - 0.1
        while self.clock.now() - q2_start < self.Q2_POLL_TIMEOUT:
            if self.is_dead:
                return False
            now = self.clock.now()
            elapsed = now - q2_start
            if now - last_q2_check >= 0.08:
                ready = diag_read_q(self, "残虹Q2轮询")
                if ready:
                    self.logger.info(
                        f"[残虹Q2轮询] elapsed={elapsed:.2f}s available=True → 发键"
                    )
                    q2_confirmed = send_ultimate_with_diag(
                        self,
                        "残虹Q2",
                        self.Q2_POST_TIMEOUT,
                        self.Q2_POST_SEND_SLEEP,
                        retry=True,
                        max_attempts=2,
                    )
                    q2_success = bool(q2_confirmed)
                    break
                self.logger.info(f"[残虹Q2轮询] elapsed={elapsed:.2f}s available=False")
                last_q2_check = now
            diag_sleep(self, "残虹Q2轮询间隔", 0.06, checks=self.SleepChecks.NONE)

        if q2_success:
            self.logger.info(
                f"[残虹] Q2 send 完成（Q1 后轮询 {self.clock.now() - q2_start:.2f}s）"
            )
            diag_sleep(
                self,
                "残虹Q2后缓冲",
                self.Q2_POST_SLEEP,
                checks=self.SleepChecks.COMBAT,
            )
        else:
            self.logger.warning(
                f"[残虹] Q2 未确认放出（轮询 {self.clock.now() - q2_start:.2f}s），"
                f"按 Q2 可能已出处理，等 {self.Q2_POST_SLEEP:.2f}s 收口再接 ZA"
            )
            try:
                self.task.mouse_up("left")
            except Exception:
                pass
            # Q2 实际可能已放出但 send_ultimate_with_diag 误判 False，
            # 落定时长与成功分支 Q2_POST_SLEEP 对齐，避免后续 ZA 的 Z 被吞
            diag_sleep(
                self,
                "残虹Q2未出落定",
                self.Q2_POST_SLEEP,
                checks=self.SleepChecks.COMBAT,
            )
        return True

    def _wait_on_field(self, desc):
        if self.is_current_char:
            return True
        self.logger.warning(f"[残虹空窗] {desc} 前不在场，等待切回")
        wait_start = self.clock.now()
        while self.clock.now() - wait_start < WINDOW_RE_CLAIM_TIMEOUT:
            diag_sleep(
                self,
                f"残虹空窗·{desc}轮询",
                WINDOW_RE_CLAIM_POLL,
                checks=self.SleepChecks.COMBAT,
            )
            if self.is_dead:
                self.logger.warning("[残虹空窗] 等待切回期间阵亡")
                return False
            if self.is_current_char:
                self.logger.info("[残虹空窗] 切回成功")
                return True
        self.logger.warning(f"[残虹空窗] {desc} 切回超时")
        return False

    def _blackbird_q_ready_silent(self):
        bb = find_teammate(self, "Blackbird")
        return bb is not None and bool(bb.ultimate_available())


TEAM_MODULE_KEY = "_zankou_wheelchair_team_module"
try:
    from pathlib import Path as _Path

    _TEAM_SOURCE_STAMP = _Path(__file__).resolve().stat().st_mtime_ns
except OSError:
    _TEAM_SOURCE_STAMP = None
sys.modules.setdefault(TEAM_MODULE_KEY, sys.modules[__name__])
