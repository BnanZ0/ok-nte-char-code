import sys


def _load_team_module():
    import importlib.util
    from pathlib import Path

    key = "_zankou_wheelchair_team_module"
    team_path = Path(__file__).resolve().with_name("zankou.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
record_battle_end = _team.record_battle_end
STAGE_OPEN_BLACKBIRD_E_Q1 = _team.STAGE_OPEN_BLACKBIRD_E_Q1
STAGE_OPEN_BLACKBIRD_Q2 = _team.STAGE_OPEN_BLACKBIRD_Q2
STAGE_LOOP_BLACKBIRD_E_Q1 = _team.STAGE_LOOP_BLACKBIRD_E_Q1
STAGE_LOOP_BLACKBIRD_Q2 = _team.STAGE_LOOP_BLACKBIRD_Q2
get_rotation = _team.get_rotation
advance_rotation = _team.advance_rotation
diag_sleep = _team.diag_sleep
send_ultimate_with_diag = _team.send_ultimate_with_diag
wait_sound_idle = _team.wait_sound_idle
sound_action_stamp = _team.sound_action_stamp
sound_action_changed = _team.sound_action_changed
make_stage_none_handler = _team.make_stage_none_handler
_reset_and_switch_to_alive = _team._reset_and_switch_to_alive
_safe_request_switch = _team._safe_request_switch
_bind_rotation_logger = _team._bind_rotation_logger

from src.char.BaseChar import BaseChar
from src.combat.planner import Planner, RoleProfile


class Blackbird(BaseChar):
    cn_name = "黑羽"
    en_name = "Blackbird"
    element = BaseChar.ElementType.BLUE

    INTRO_WAIT = 0.5
    Q1_POST_TIMEOUT = 8
    Q1_POST_SEND_SLEEP = 0.1
    Q1_POST_SLEEP = 1.8
    Q2_POST_TIMEOUT = 5
    Q2_POST_SEND_SLEEP = 0.1
    Q2_POST_ANIM_SLEEP = 2.5
    Q2_SWITCH_SETTLE_SLEEP = 0.15
    Q2_OBSERVE_TIMEOUT = 1
    Q2_OBSERVE_POLL = 0.1
    HEAVY_ATTACK_HOLD = 0.6
    HEAVY_INPUT_PACING = 0.1
    HEAVY_POST_SLEEP = 0.1
    Q_CHARGE_TIMEOUT = 5
    CHARGE_ATTACK_INTERVAL = 0.1
    SKILL_POST_SLEEP = 0.1
    MAX_STAGE_ATTEMPTS = 3
    STAGE_RETRY_SLEEP = 0.1

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bind_rotation_logger(self)
        self.planner_handles_arc = True
        self._wait_switch_since = None
        self._last_q1_time = -1e9

    def on_combat_end(self, chars):
        record_battle_end(self)
        self._last_q1_time = -1e9
        super().on_combat_end(chars)

    def send_skill_key(
        self, after_sleep=0, interval=-1, down_time=0.05, action_name=None, **_
    ):
        wait_sound_idle(self, label="黑羽·E发键")
        return super().send_skill_key(
            after_sleep=after_sleep,
            interval=interval,
            down_time=down_time,
            action_name=action_name,
        )

    def send_ultimate_key(
        self, after_sleep=0, interval=-1, down_time=0.05, action_name=None, **_
    ):
        wait_sound_idle(self, label="黑羽·Q发键")
        return super().send_ultimate_key(
            after_sleep=after_sleep,
            interval=interval,
            down_time=down_time,
            action_name=action_name,
        )

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUB_DPS,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def _ultimate_ready(self):
        value = self.ultimate_available()
        return bool(value) if value is not None else False

    def wait_intro(self, time_out=-1, click=True):
        rotation = get_rotation(self.task)
        stage = rotation.stage_for(self)

        if stage in (STAGE_LOOP_BLACKBIRD_E_Q1, STAGE_LOOP_BLACKBIRD_Q2):
            self.logger.info(
                f"[黑羽] 循环轴入场({stage})，跳过 INTRO_WAIT，直接读 Q 状态"
            )
            return

        if not self.has_intro:
            return
        if self.INTRO_WAIT > 0:
            self.logger.info(f"[黑羽] INTRO_WAIT={self.INTRO_WAIT:.2f}s")
            diag_sleep(self, "黑羽援护入场", self.INTRO_WAIT)
        else:
            self.logger.info("[黑羽] INTRO_WAIT=0，跳过")

    def _charge_for_q(self):
        self.logger.info(
            f"[黑羽] 循环轴 Q 不满，开始攒能（上限 {self.Q_CHARGE_TIMEOUT}s）"
        )
        start = self.clock.now()
        attacks = 0
        stamp = sound_action_stamp()
        while self.clock.now() - start <= self.Q_CHARGE_TIMEOUT:
            if self.is_dead:
                return False
            if self._ultimate_ready():
                try:
                    self.task.next_frame()
                except Exception:
                    pass
                if self._ultimate_ready():
                    self.logger.info(
                        f"[黑羽] 攒能成功（双确认，普攻 {attacks} 次，"
                        f"耗时 {self.clock.now() - start:.2f}s）"
                    )
                    return True
                self.logger.info("[黑羽] 攒能临界态：双确认失败，继续攒能")
            if sound_action_changed(stamp):
                self.logger.info("[黑羽] 攒能检测到声音打断，补一次普攻保持段数")
                self.check_combat()
                self.click(interval=self.CHARGE_ATTACK_INTERVAL)
                stamp = sound_action_stamp()
                continue
            self.check_combat()
            self.click(interval=self.CHARGE_ATTACK_INTERVAL)
            stamp = sound_action_stamp()
            attacks += 1
        self.logger.warning(
            f"[黑羽] 攒能 {self.Q_CHARGE_TIMEOUT}s 超时（普攻 {attacks} 次），强制放弃"
        )
        return False

    def _heavy_transition(self, tag):
        if self.is_dead:
            return
        if self.HEAVY_ATTACK_HOLD > 0:
            try:
                self.sleep(0.1, checks=self.SleepChecks.COMBAT)
                self.heavy_attack(self.HEAVY_ATTACK_HOLD)
            except Exception as e:
                err_name = type(e).__name__
                if err_name in ("TaskDisabledException", "NotInCombatException"):
                    raise
                self.logger.warning(f"[黑羽{tag}后重击异常] {err_name}: {e}，跳过")
            # tight-input-loop 补 pacing：重击后加显式最小间隔
            if self.HEAVY_INPUT_PACING > 0:
                self.sleep(self.HEAVY_INPUT_PACING, checks=self.SleepChecks.NONE)
        if self.HEAVY_POST_SLEEP > 0:
            diag_sleep(self, f"黑羽{tag}后重击缓冲", self.HEAVY_POST_SLEEP)

    def _block_e_q1(self, is_loop=False):
        if self.is_dead:
            return False

        # 强校验：攒能普攻 / E-Q1 发键前必须确认在场，否则会打在队友身上
        if not self.is_current_char:
            wait_start = self.clock.now()
            while not self.is_current_char and self.clock.now() - wait_start < 2.5:
                if self.is_dead:
                    return False
                self.sleep(0.1, checks=self.SleepChecks.COMBAT)
                try:
                    self.task.next_frame()
                except Exception:
                    pass
            if not self.is_current_char:
                self.logger.warning(
                    "[黑羽] _block_e_q1 入口 2.5s 内未切到本角色，返回 False 触发重试"
                )
                return False

        if is_loop:
            self.logger.info("[黑羽] 循环轴进场，next_frame 刷新一帧后读 Q 状态")
            try:
                self.task.next_frame()
            except Exception:
                pass
            if not self._ultimate_ready():
                self.logger.info("[黑羽] 循环轴入场 Q 不满，进入攒能")
                if not self._charge_for_q():
                    self.logger.warning(
                        "[黑羽] 循环轴攒能超时，返回 False 触发外层重试"
                        "（重试用尽后按最大重试次数推进）"
                    )
                    return False  # ← 改为 False
            else:
                self.logger.info("[黑羽] 循环轴入场 Q 已满，直接 E-Q1")

        try:
            self.task.next_frame()
        except Exception:
            pass
        self.sleep(0.1, checks=self.SleepChecks.NONE)

        e_start = self.clock.now()
        # tight-input-loop 补 pacing
        e_ok = self.click_skill(down_time=0.05, post_sleep=self.SKILL_POST_SLEEP)
        e_actual = self.clock.now() - e_start
        self.logger.info(f"[诊断·黑羽E] click_skill 返回={e_ok} 耗时={e_actual:.2f}s")

        if self.is_dead:
            return False

        if self._ultimate_ready():
            q_accepted = send_ultimate_with_diag(
                self, "黑羽Q1", self.Q1_POST_TIMEOUT, self.Q1_POST_SEND_SLEEP
            )
            if not q_accepted:
                self.logger.warning("[黑羽] Q1 未确认释放，阶段失败，交给外层重试")
                return False

            self._last_q1_time = self.clock.now()

            # 刷新一帧后再稳定，避免盲等期间 UI 状态滞后
            try:
                self.task.next_frame()
            except Exception:
                pass
            if self.Q1_POST_SLEEP > 0:
                diag_sleep(
                    self,
                    "黑羽Q1收尾稳定缓冲",
                    self.Q1_POST_SLEEP,
                    checks=self.SleepChecks.NONE,
                )
            # 收尾后再刷一帧，让 downstream 切人时读到最新状态
            try:
                self.task.next_frame()
            except Exception:
                pass
            self._heavy_transition("Q1")
        else:
            self.logger.warning("[黑羽] Q1 能量不足，跳过 Q1 直接切走（不算阶段失败）")
        return not self.is_dead

    def _q2_progressed(self, start_stage=None):
        if not self.is_current_char:
            return True
        if getattr(self.task, "in_animation", False):
            return True
        try:
            if not bool(self.task.is_in_team()):
                return True
        except Exception:
            pass
        if start_stage is not None:
            try:
                rotation = get_rotation(self.task)
                if rotation.stage_for(self) != start_stage:
                    return True
            except Exception:
                pass
        return False

    def _wait_q2_started(self, start_stage=None):
        start = self.clock.now()
        while self.clock.now() - start < self.Q2_OBSERVE_TIMEOUT:
            if self.is_dead:
                return False
            try:
                self.task.next_frame()
            except Exception:
                pass
            if self._q2_progressed(start_stage=start_stage):
                return True
            # 改用 NONE 避免发键观察期被 CombatCheck 索敌拉长
            self.sleep(self.Q2_OBSERVE_POLL, checks=self.SleepChecks.NONE)
        return self._q2_progressed(start_stage=start_stage)

    def _block_q2(self):
        if self.is_dead:
            return False

        if not self.is_current_char:
            self.logger.warning("[黑羽] Q2 入口不在场，快速失败触发重试")
            return False

        wait_start = self.clock.now()
        stable_frames = 0
        while self.clock.now() - wait_start < 1.5:
            if self.is_dead:
                return False
            try:
                self.task.next_frame()
            except Exception:
                pass
            try:
                in_team_now = bool(self.task.is_in_team())
            except Exception:
                in_team_now = False
            if self.is_current_char and in_team_now:
                stable_frames += 1
                if stable_frames >= 2:
                    break
            else:
                stable_frames = 0
            self.sleep(0.1, checks=self.SleepChecks.COMBAT)

        if not self.is_current_char:
            self.logger.warning(
                "[黑羽] Q2 入口 1.5s 内未切到本角色，返回 False 触发外层重试"
            )
            return False

        if stable_frames < 2:
            self.logger.info(
                f"[黑羽] Q2 入场稳定帧不足（{stable_frames}），继续轮询至稳定或 0.25s 超时"
            )
            extra_wait_start = self.clock.now()
            while self.clock.now() - extra_wait_start < 0.25:
                if self.is_dead:
                    return False
                try:
                    self.task.next_frame()
                except Exception:
                    pass
                try:
                    in_team_now = bool(self.task.is_in_team())
                except Exception:
                    in_team_now = False
                if self.is_current_char and in_team_now:
                    stable_frames += 1
                    if stable_frames >= 2:
                        self.logger.info(
                            f"[黑羽] Q2 稳定帧补足（{stable_frames}），耗时 "
                            f"{self.clock.now() - extra_wait_start:.2f}s"
                        )
                        break
                else:
                    stable_frames = 0
                self.sleep(0.1, checks=self.SleepChecks.NONE)
            if stable_frames < 2:
                self.logger.warning(
                    f"[黑羽] Q2 入场稳定帧仍不足（{stable_frames}），继续尝试发 Q2"
                )

        self.logger.info("[黑羽] Q2 释放前 next_frame 刷新 UI 状态")
        try:
            self.task.next_frame()
        except Exception:
            pass
        diag_sleep(self, "黑羽Q2前稳定", 0.1)

        q1_age = self.clock.now() - getattr(self, "_last_q1_time", -1e9)
        if 0 <= q1_age < 3.5:
            self.logger.warning(
                f"[黑羽Q2] 距离上次 Q1 仅 {q1_age:.2f}s，疑似 Q1 后未切走直接进入 Q2，补发切人确认"
            )
            try:
                rotation = get_rotation(self.task)
                target_name = rotation.current_owner()
                if target_name and target_name != type(self).__name__:
                    for t in self.task.chars:
                        if (
                            t is not None
                            and type(t).__name__ == target_name
                            and not t.is_dead
                        ):
                            _safe_request_switch(
                                self, t, reason="guard q1->q2 without switch"
                            )
                            break
            except Exception:
                pass
            diag_sleep(self, "黑羽Q2防连发切人缓冲", 0.25, checks=self.SleepChecks.NONE)
            try:
                self.task.next_frame()
            except Exception:
                pass
            if not self.is_current_char:
                self.logger.info("[黑羽Q2] 已成功切出黑羽，交由目标角色执行")
                return False
            try:
                cur_owner = get_rotation(self.task).current_owner()
                if cur_owner and cur_owner != type(self).__name__:
                    self.logger.warning(
                        f"[黑羽Q2] 防连发切出未生效且当前阶段归属 {cur_owner}，放弃发 Q2"
                    )
                    return False
            except Exception:
                pass

        if q1_age > 20.0:
            self.logger.warning(
                f"[黑羽Q2] 距离上次 Q1 已过 {q1_age:.1f}s（可能 Q1 未实际触发），仍尝试发 Q2 但缩短长动画等待"
            )
            effective_anim_sleep = min(self.Q2_POST_ANIM_SLEEP, 1.0)
        else:
            effective_anim_sleep = self.Q2_POST_ANIM_SLEEP

        start_stage = None
        try:
            start_stage = get_rotation(self.task).stage_for(self)
        except Exception:
            start_stage = None

        wait_sound_idle(self, label="黑羽·Q2首发前")
        send_ret = self.send_ultimate_key(
            down_time=0.05,
            action_name="ultimate_send_黑羽Q2_#1",
        )
        if self.Q2_POST_SEND_SLEEP > 0:
            diag_sleep(
                self,
                "黑羽Q2发键后缓冲",
                self.Q2_POST_SEND_SLEEP,
                checks=self.SleepChecks.NONE,
            )

        progressed = self._wait_q2_started(start_stage=start_stage)
        if progressed:
            self.logger.info("[黑羽Q2] 发键后已确认进入动画/状态推进")
        elif send_ret is not False and not self.is_dead:
            self.logger.info(
                "[黑羽Q2] 发键已完成，按Q2长动画/满能不耗图标处理，进入动画等待"
            )
        else:
            self.logger.warning("[黑羽] Q2 发键失败或未生效，阶段失败交给外层重试")
            return False

        if self.is_dead:
            return False

        if effective_anim_sleep > 0:
            # 长动画等待前后各刷一帧，确保动画/队伍状态读取不过期
            try:
                self.task.next_frame()
            except Exception:
                pass
            diag_sleep(
                self,
                "黑羽Q2长动画等待",
                effective_anim_sleep,
                checks=self.SleepChecks.NONE,
            )
            try:
                self.task.next_frame()
            except Exception:
                pass
        if self.is_dead:
            return False

        if self.Q2_SWITCH_SETTLE_SLEEP > 0:
            diag_sleep(
                self,
                "黑羽Q2切人前落定",
                self.Q2_SWITCH_SETTLE_SLEEP,
                checks=self.SleepChecks.NONE,
            )
        self._heavy_transition("Q2")
        return True

    def combat_plan(self):
        rotation = get_rotation(self.task)
        handle_none = make_stage_none_handler(self, rotation)

        def entry():
            _bind_rotation_logger(self)
            stage = rotation.stage_for(self)
            self.logger.info(f"[黑羽入场] 阶段={stage}")

            if stage is None:
                handle_none()
                return
            self._wait_switch_since = None

            if self.is_dead:
                self.logger.warning("[黑羽] 阵亡，重置轴")
                _reset_and_switch_to_alive(self, rotation, "黑羽阵亡")
                return

            for attempt in range(1, self.MAX_STAGE_ATTEMPTS + 1):
                if self.is_dead:
                    self.logger.warning("[黑羽] 角色阵亡，中断")
                    _reset_and_switch_to_alive(self, rotation, "黑羽阵亡")
                    return
                try:
                    if stage == STAGE_OPEN_BLACKBIRD_E_Q1:
                        if attempt == 1:
                            self.logger.info("[黑羽] E-Q1（启动轴）")
                        ok = self._block_e_q1(False)
                    elif stage == STAGE_LOOP_BLACKBIRD_E_Q1:
                        if attempt == 1:
                            self.logger.info("[黑羽] E-Q1（循环轴）")
                        ok = self._block_e_q1(True)
                    elif stage in (STAGE_OPEN_BLACKBIRD_Q2, STAGE_LOOP_BLACKBIRD_Q2):
                        if attempt == 1:
                            self.logger.info("[黑羽] Q2")
                        ok = self._block_q2()
                    else:
                        self.logger.error(
                            f"[黑羽异常] 未处理的阶段 {stage}，等待人工排查"
                        )
                        return
                except Exception as e:
                    err_name = type(e).__name__
                    if err_name == "TaskDisabledException":
                        raise
                    if err_name == "NotInCombatException":
                        self.logger.warning("[黑羽] 脱战，向外抛出")
                        raise
                    self.logger.error(f"[黑羽异常] {e}")
                    ok = False

                if ok:
                    if self.is_dead:
                        self.logger.warning("[黑羽] 完成后阵亡，重置轴")
                        _reset_and_switch_to_alive(self, rotation, "黑羽完成后阵亡")
                        return
                    try:
                        self.task.next_frame()
                    except Exception:
                        pass
                    self.logger.info(
                        f"[黑羽] 阶段 {stage} 完成，准备 advance"
                        f"（当前队列头 {rotation.current_stage()}）"
                    )
                    advance_rotation(self, rotation)
                    self.logger.info(
                        f"[黑羽] advance 后队列头 {rotation.current_stage()}"
                    )
                    return

                self.logger.warning(
                    f"[黑羽] 阶段 {stage} 第 {attempt}/{self.MAX_STAGE_ATTEMPTS} 次失败"
                )
                if attempt < self.MAX_STAGE_ATTEMPTS:
                    diag_sleep(
                        self,
                        "黑羽阶段重试前",
                        self.STAGE_RETRY_SLEEP,
                        checks=self.SleepChecks.COMBAT,
                    )

            self.logger.error(f"[黑羽] 阶段 {stage} 达到最大重试次数，推进跳过避免死锁")
            advance_rotation(self, rotation)

        return self.plan(entry=entry)
