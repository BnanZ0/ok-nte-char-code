import sys


def _load_team_module():
    import importlib.util
    from pathlib import Path

    key = "_zankou_wheelchair_team_module"
    team_path = Path(__file__).resolve().with_name("zankou.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
record_battle_end = _team.record_battle_end
STAGE_OPEN_DAFFODILL_QE = _team.STAGE_OPEN_DAFFODILL_QE
STAGE_OPEN_DAFFODILL_R = _team.STAGE_OPEN_DAFFODILL_R
STAGE_LOOP_DAFFODILL_QRE = _team.STAGE_LOOP_DAFFODILL_QRE
get_rotation = _team.get_rotation
advance_rotation = _team.advance_rotation
diag_sleep = _team.diag_sleep
wait_sound_idle = _team.wait_sound_idle
sound_action_stamp = _team.sound_action_stamp
sound_action_changed = _team.sound_action_changed
make_stage_none_handler = _team.make_stage_none_handler
_reset_and_switch_to_alive = _team._reset_and_switch_to_alive
_bind_rotation_logger = _team._bind_rotation_logger

from src.char.Daffodill import Daffodill as StockDaffodill
from src.combat.planner import Planner, RoleProfile


class Daffodill(StockDaffodill):
    cn_name = "达芙蒂尔"
    en_name = "Daffodill"

    INTRO_WAIT = 0.5
    ARC_AFTER_SLEEP = 0.1
    R_POST_SLEEP = 0.35
    LOOP_R_TO_E_WAIT = 0.15
    E_POST_SLEEP = 0.1
    Q_CHARGE_TIMEOUT = 6.5
    CHARGE_ATTACK_INTERVAL = 0.1
    SKILL_POST_SLEEP = 0.1
    MAX_STAGE_ATTEMPTS = 3
    STAGE_RETRY_SLEEP = 0.1

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _bind_rotation_logger(self)
        self.planner_handles_arc = True
        self._wait_switch_since = None

    def on_combat_end(self, chars):
        record_battle_end(self)
        super().on_combat_end(chars)

    def send_skill_key(
        self, after_sleep=0, interval=-1, down_time=0.05, action_name=None, **_
    ):
        wait_sound_idle(self, label="达芙·E发键")
        return super().send_skill_key(
            after_sleep=after_sleep,
            interval=interval,
            down_time=down_time,
            action_name=action_name,
        )

    def send_ultimate_key(
        self, after_sleep=0, interval=-1, down_time=0.05, action_name=None, **_
    ):
        wait_sound_idle(self, label="达芙·Q发键")
        return super().send_ultimate_key(
            after_sleep=after_sleep,
            interval=interval,
            down_time=down_time,
            action_name=action_name,
        )

    def send_arc_key(self, after_sleep=0, interval=-1, down_time=0.05, **_):
        wait_sound_idle(self, label="达芙·R发键")
        return super().send_arc_key(
            after_sleep=after_sleep, interval=interval, down_time=down_time
        )

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUB_DPS,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def _ultimate_ready(self):
        value = self.ultimate_available()
        return bool(value) if value is not None else False

    def _click_ultimate_with_retry(self, tag):
        q_ok = self.click_ultimate()
        if not q_ok and not self.is_dead:
            self.logger.warning(f"[达芙Q{tag}] 首次释放失败，重试1次")
            wait_sound_idle(self, label=f"达芙·Q重试前{tag}")
            diag_sleep(self, f"达芙Q重试前{tag}", 0.1)
            if self._ultimate_ready() and not self.is_dead:
                q_ok = self.click_ultimate()
        if not q_ok and not self.is_dead:
            self.logger.warning(f"[达芙Q{tag}] 重试后仍失败，跳过Q")
        return q_ok

    def wait_intro(self, time_out=-1, click=True):
        if not self.has_intro:
            return
        if self.INTRO_WAIT > 0:
            self.logger.info(f"[达芙蒂尔] INTRO_WAIT={self.INTRO_WAIT:.2f}s")
            diag_sleep(self, "达芙蒂尔援护入场", self.INTRO_WAIT)
        else:
            self.logger.info("[达芙蒂尔] INTRO_WAIT=0，跳过")

    def _charge_for_q(self):
        self.logger.info(
            f"[达芙蒂尔] 循环轴 Q 不满，开始攒能（上限 {self.Q_CHARGE_TIMEOUT}s）"
        )
        start = self.clock.now()
        attacks = 0
        stamp = sound_action_stamp()
        while self.clock.now() - start <= self.Q_CHARGE_TIMEOUT:
            if self.is_dead:
                return False
            if self._ultimate_ready():
                try:
                    self.task.next_frame()
                except Exception:
                    pass
                if self._ultimate_ready():
                    self.logger.info(
                        f"[达芙蒂尔] 攒能成功（双确认，普攻 {attacks} 次，"
                        f"耗时 {self.clock.now() - start:.2f}s）"
                    )
                    return True
                self.logger.info("[达芙蒂尔] 攒能临界态：双确认失败，继续攒能")
            if sound_action_changed(stamp):
                self.logger.info("[达芙蒂尔] 攒能检测到声音打断，补一次普攻保持段数")
                self.check_combat()
                self.click(interval=self.CHARGE_ATTACK_INTERVAL)
                stamp = sound_action_stamp()
                continue
            self.check_combat()
            self.click(interval=self.CHARGE_ATTACK_INTERVAL)
            stamp = sound_action_stamp()
            attacks += 1
        self.logger.warning(
            f"[达芙蒂尔] 攒能 {self.Q_CHARGE_TIMEOUT}s 超时（普攻 {attacks} 次），强制放弃"
        )
        return False

    def _block_q_e(self):
        if self.is_dead:
            return False

        # 强校验：等切人真正生效，避免 Q/E 打在错误角色身上
        if not self.is_current_char:
            wait_start = self.clock.now()
            while not self.is_current_char and self.clock.now() - wait_start < 2.5:
                if self.is_dead:
                    return False
                self.sleep(0.1, checks=self.SleepChecks.COMBAT)
                try:
                    self.task.next_frame()
                except Exception:
                    pass
            if not self.is_current_char:
                self.logger.warning(
                    "[达芙] _block_q_e 入口 2.5s 内未切到本角色，返回 False 触发重试"
                )
                return False

        if self._ultimate_ready():
            q_start = self.clock.now()
            self._click_ultimate_with_retry("启动")
            self.logger.info(
                f"[诊断·达芙Q] click_ultimate 总耗时={self.clock.now()-q_start:.2f}s"
            )
            if self.is_dead:
                return False
            # 启动轴 Q 后短落定，避免 E 被 Q 后摇/音效吞键
            # （循环轴 _block_q_r_e 已有 Q→R→E 落定，本处补齐对称）
            diag_sleep(self, "达芙蒂尔启动Q后落定", 0.1, checks=self.SleepChecks.COMBAT)
        else:
            self.logger.warning("[达芙蒂尔] Q 能量不足，跳过 Q 只打 E")

        if self.skill_available():
            e_start = self.clock.now()
            # tight-input-loop 补 pacing
            self.click_skill(down_time=0.05, post_sleep=self.SKILL_POST_SLEEP)
            self.logger.info(
                f"[诊断·达芙E] click_skill 耗时={self.clock.now()-e_start:.2f}s"
            )
        if self.E_POST_SLEEP > 0:
            self.logger.info(f"[达芙蒂尔] E_POST_SLEEP={self.E_POST_SLEEP:.2f}s")
            diag_sleep(self, "达芙蒂尔E后缓冲", self.E_POST_SLEEP)
        else:
            self.logger.info("[达芙蒂尔] E_POST_SLEEP=0，跳过E后缓冲")
        return not self.is_dead

    def _block_q_r_e(self):
        try:
            self.task.next_frame()
        except Exception:
            pass
        if self.is_dead:
            return False

        # 强校验：必须在攒能/Q 释放前，等切人真正生效，避免攒能普攻打在黑羽身上
        if not self.is_current_char:
            wait_start = self.clock.now()
            while not self.is_current_char and self.clock.now() - wait_start < 2.5:
                if self.is_dead:
                    return False
                self.sleep(0.1, checks=self.SleepChecks.COMBAT)
                try:
                    self.task.next_frame()
                except Exception:
                    pass
            if not self.is_current_char:
                self.logger.warning(
                    f"[达芙] _block_q_r_e 入口 2.5s 内未切到本角色，返回 False 触发重试"
                )
                return False

        if not self._ultimate_ready():
            charged = self._charge_for_q()
            try:
                self.task.next_frame()
            except Exception:
                pass
            if not charged and not self._ultimate_ready():
                allow_skip_q = False
                try:
                    rotation = get_rotation(self.task)
                    if (
                        getattr(rotation, "_daff_qre_attempt", 0)
                        >= self.MAX_STAGE_ATTEMPTS
                    ):
                        allow_skip_q = True
                except Exception:
                    allow_skip_q = True
                if not allow_skip_q:
                    self.logger.warning(
                        "[达芙蒂尔] 循环轴 Q 攒能失败，返回 False 触发外层重试"
                    )
                    return False

        if self._ultimate_ready():
            q_start = self.clock.now()
            self._click_ultimate_with_retry("循环")
            self.logger.info(
                f"[诊断·达芙Q(循环)] click_ultimate 总耗时={self.clock.now()-q_start:.2f}s"
            )
            if self.is_dead:
                return False
            diag_sleep(self, "达芙蒂尔循环Q后落定", 0.1, checks=self.SleepChecks.COMBAT)
            r_tag = "达芙R"
        else:
            self.logger.warning("[达芙蒂尔] Q 攒能失败，跳过 Q 继续 R-E")
            r_tag = "达芙R(无Q)"

        r_start = self.clock.now()
        # tight-input-loop 补 pacing
        self.send_arc_key(down_time=0.05, after_sleep=self.ARC_AFTER_SLEEP)
        self.logger.info(
            f"[诊断·{r_tag}] send_arc_key 耗时={self.clock.now()-r_start:.2f}s"
        )
        if self.LOOP_R_TO_E_WAIT > 0:
            diag_sleep(self, "达芙蒂尔循环R→E", self.LOOP_R_TO_E_WAIT)
        else:
            self.logger.info("[达芙蒂尔] 达芙蒂尔LOOP_R_TO_E_WAIT=0，跳过R→E缓冲")

        if self.is_dead:
            return False

        if self.skill_available():
            e_start = self.clock.now()
            # tight-input-loop 补 pacing
            self.click_skill(down_time=0.05, post_sleep=self.SKILL_POST_SLEEP)
            self.logger.info(
                f"[诊断·达芙E(循环)] click_skill 耗时={self.clock.now()-e_start:.2f}s"
            )
        else:
            self.logger.warning("[达芙蒂尔] 循环轴 E 不可用，跳过 E")
        if self.E_POST_SLEEP > 0:
            self.logger.info(f"[达芙蒂尔] E_POST_SLEEP={self.E_POST_SLEEP:.2f}s")
            diag_sleep(self, "达芙蒂尔E后缓冲", self.E_POST_SLEEP)
        else:
            self.logger.info("[达芙蒂尔] E_POST_SLEEP=0，跳过E后缓冲")
        return not self.is_dead

    def _block_r(self):
        if self.is_dead:
            return False

        # 强校验：等切人真正生效，最多 2.5s；超时直接返回 False 触发 entry 重试
        wait_start = self.clock.now()
        while not self.is_current_char and self.clock.now() - wait_start < 2.5:
            if self.is_dead:
                return False
            self.sleep(0.1, checks=self.SleepChecks.COMBAT)
            try:
                self.task.next_frame()
            except Exception:
                pass

        if not self.is_current_char:
            self.logger.warning(
                f"[达芙] _block_r 入口 2.5s 内未切到本角色，返回 False 触发重试"
            )
            return False

        wait_sound_idle(self, label="达芙·R发键前")

        diag_sleep(self, "达芙R前稳定", 0.15)

        stable_start = self.clock.now()
        stable_frames = 0
        iterations = 0
        while self.clock.now() - stable_start < 0.4:
            try:
                self.task.next_frame()
            except Exception:
                pass
            iterations += 1
            try:
                in_team_now = bool(self.task.is_in_team())
            except Exception as e:
                self.logger.warning(f"[诊断·达芙R] is_in_team 读取异常: {e}")
                in_team_now = False
            if in_team_now:
                stable_frames += 1
                if stable_frames >= 2:
                    break
            else:
                stable_frames = 0
            self.sleep(0.08, checks=self.SleepChecks.NONE)

        if stable_frames >= 2:
            diag_sleep(self, "达芙R前稳定追加", 0.05, checks=self.SleepChecks.NONE)

        try:
            self.task.next_frame()
        except Exception:
            pass
        if not self.is_current_char:
            self.logger.warning("[达芙] 稳定后当前角色已切走，放弃本次 R")
            return False

        try:
            in_team = self.task.is_in_team()
        except Exception as e:
            in_team = f"err:{e}"
        self.logger.info(
            f"[诊断·达芙R状态] is_current_char={self.is_current_char} "
            f"is_in_team={in_team} has_intro={self.has_intro} "
            f"stable_frames={stable_frames} iterations={iterations} "
            f"elapsed={self.clock.now()-stable_start:.2f}s"
        )

        r_start = self.clock.now()
        # tight-input-loop 补 pacing
        self.send_arc_key(down_time=0.05, after_sleep=self.ARC_AFTER_SLEEP)
        self.logger.info(
            f"[诊断·达芙R(启动)] send_arc_key 耗时={self.clock.now()-r_start:.2f}s"
        )
        if self.R_POST_SLEEP > 0:
            diag_sleep(self, "达芙蒂尔启动R后缓冲", self.R_POST_SLEEP)
        return True

    def combat_plan(self):
        rotation = get_rotation(self.task)
        handle_none = make_stage_none_handler(self, rotation)

        def entry():
            _bind_rotation_logger(self)
            stage = rotation.stage_for(self)
            self.logger.info(f"[达芙蒂尔入场] 阶段={stage}")

            if stage is None:
                handle_none()
                return
            self._wait_switch_since = None

            if self.is_dead:
                self.logger.warning("[达芙蒂尔] 阵亡，重置轴")
                _reset_and_switch_to_alive(self, rotation, "达芙蒂尔阵亡")
                return

            for attempt in range(1, self.MAX_STAGE_ATTEMPTS + 1):
                if self.is_dead:
                    self.logger.warning("[达芙蒂尔] 角色阵亡，中断")
                    _reset_and_switch_to_alive(self, rotation, "达芙蒂尔阵亡")
                    return
                try:
                    if stage == STAGE_OPEN_DAFFODILL_QE:
                        rotation._daff_qre_attempt = 0
                        if attempt == 1:
                            self.logger.info("[达芙蒂尔] Q-E（启动轴）")
                        ok = self._block_q_e()
                    elif stage == STAGE_OPEN_DAFFODILL_R:
                        rotation._daff_qre_attempt = 0
                        if attempt == 1:
                            self.logger.info("[达芙蒂尔] R")
                        ok = self._block_r()
                    elif stage == STAGE_LOOP_DAFFODILL_QRE:
                        rotation._daff_qre_attempt = attempt
                        if attempt == 1:
                            self.logger.info("[达芙蒂尔] Q-R-E（循环轴）")
                        ok = self._block_q_r_e()
                    else:
                        rotation._daff_qre_attempt = 0
                        self.logger.error(
                            f"[达芙蒂尔异常] 未处理的阶段 {stage}，等待人工排查"
                        )
                        return
                except Exception as e:
                    err_name = type(e).__name__
                    if err_name == "TaskDisabledException":
                        raise
                    if err_name == "NotInCombatException":
                        self.logger.warning("[达芙蒂尔] 脱战，向外抛出")
                        raise
                    self.logger.error(
                        f"[达芙蒂尔异常] 第 {attempt}/{self.MAX_STAGE_ATTEMPTS} 次: {e}"
                    )
                    ok = False

                if ok:
                    try:
                        rotation._daff_qre_attempt = 0
                    except Exception:
                        pass
                    try:
                        self.task.next_frame()
                    except Exception:
                        pass
                    if self.is_dead:
                        self.logger.warning("[达芙蒂尔] 完成后阵亡，重置轴")
                        _reset_and_switch_to_alive(self, rotation, "达芙蒂尔完成后阵亡")
                        return
                    advance_rotation(self, rotation)
                    return

                self.logger.warning(
                    f"[达芙蒂尔] 阶段 {stage} 第 {attempt}/{self.MAX_STAGE_ATTEMPTS} 次失败"
                )
                if attempt < self.MAX_STAGE_ATTEMPTS:
                    diag_sleep(
                        self,
                        "达芙阶段重试前",
                        self.STAGE_RETRY_SLEEP,
                        checks=self.SleepChecks.COMBAT,
                    )

            try:
                rotation._daff_qre_attempt = 0
            except Exception:
                pass
            self.logger.error(
                f"[达芙蒂尔] 阶段 {stage} 达到最大重试次数，推进跳过避免死锁"
            )
            advance_rotation(self, rotation)

        return self.plan(entry=entry)
