# -*- coding: utf-8 -*-
"""
伊洛伊（Iroi）- 辅助 / 援护触发 + qza1
排轴稿：
  - 模式A（步骤1）：环合满援护入场 → e
  - 模式B（步骤4）：安魂曲E后切入 → q→z→a1
"""

from src.char.BaseChar import BaseChar
from src.combat.planner import (
    CombatContext,
    Planner,
    RoleProfile,
)


class Iroi(BaseChar):
    """伊洛伊 - 辅助，援护e / qza1 双模式"""

    MODE_ASSIST_E = "assist_e"
    MODE_QZA1 = "qza1"

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=2.0,
        )

    def combat_plan(self, context: CombatContext):
        self._init_state()

        act_assist_e = self.planner_action(
            tags={
                Planner.ActionTag.SKILL_ACTION,
                Planner.ActionTag.SUPPORT,
                Planner.ActionTag.COORDINATION,
            },
            slot=Planner.ActionSlot.ENTRY_REACTION,
            name="iroi_assist_e",
            can_execute=lambda ctx: self.enter_mode == self.MODE_ASSIST_E,
            execute=lambda ctx: self._do_assist_e(),
            reason="援护入场（自动）→ e",
        )

        act_qza1 = self.planner_action(
            tags={
                Planner.ActionTag.ULTIMATE_ACTION,
                Planner.ActionTag.SUPPORT,
                Planner.ActionTag.COORDINATION,
            },
            slot=Planner.ActionSlot.ULTIMATE,
            name="iroi_qza1",
            can_execute=lambda ctx: self.enter_mode == self.MODE_QZA1,
            execute=lambda ctx: self._do_qza1(),
            reason="q→z→a1",
        )

        def entry():
            if self.enter_mode == self.MODE_ASSIST_E:
                result = yield act_assist_e
                if result:
                    self.enter_mode = self.MODE_QZA1
                return
            if self.enter_mode == self.MODE_QZA1:
                result = yield act_qza1
                if result:
                    self.enter_mode = self.MODE_ASSIST_E
                return

        return self.plan(act_assist_e, act_qza1, entry=entry)

    def combat_policies(self, context: CombatContext):
        return None

    def _init_state(self):
        if not hasattr(self, "enter_mode"):
            self.enter_mode = self.MODE_ASSIST_E

    def _do_assist_e(self):
        self._wait_assist_animation()
        if self._skill_ready():
            self.click_skill()      # e
            self._wait_skill_cd_icon()
        return True

    def _do_qza1(self):
        self.click_ultimate()       # q
        self.sleep(0.2)
        self.heavy_attack(1.0)      # z
        self.click()                # a1
        return True

    def _ultimate_ready(self):
        return self.ultimate_available()

    def _skill_ready(self):
        return self.skill_available()

    def _wait_assist_animation(self):
        self.sleep(0.8)

    def _wait_skill_cd_icon(self):
        for _ in range(30):
            if not self._skill_ready():
                return
            self.sleep(0.1)
