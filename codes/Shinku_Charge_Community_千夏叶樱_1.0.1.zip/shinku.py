"""真红盈蓄社区方案的主场轮转。"""

from src.char.Shinku import Shinku


class CommunityShinku(Shinku):
    """完成 E→Q 并在大招窗口持续执行强化技能与普攻。"""

    cn_name = "真红（盈蓄社区版）"
    en_name = "Shinku (Charge Community)"

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan)
        self.register_ultimate(plan)
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        self.click_skill()
        if self.click_ultimate():
            self.perform_in_ult()
