"""真红盈蓄社区方案的零环合轮转。"""

from src.char.Zero import Zero
from src.combat.planner import Planner


class CommunityZeroShinku(Zero):
    """优先释放环合技能，必要时补充大招。"""

    cn_name = "零（真红队）"
    en_name = "Zero (Shinku Team)"

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(plan, add_tags=Planner.ActionTag.TEAM_BUFF)
        self.register_ultimate(plan)
        return plan
