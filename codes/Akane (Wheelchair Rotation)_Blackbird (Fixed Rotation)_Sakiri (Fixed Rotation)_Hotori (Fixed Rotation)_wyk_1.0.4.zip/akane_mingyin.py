"""明音 / 黑羽 / 早雾 / 浔（老板娘）轮椅轴配置。

轴（逐字对应使用者口径）
=======================
开局（每场战斗只做一次）::

    切浔 → E(开技能记录窗)

之后每一轮（从早雾开始，一路向前切，不回头）::

    早雾  → 大招(R) → E                     (两个技能放完就切人)
    黑羽  → E → 大招(R) → A 2 下             (R 真放出来了才等变身动画)
    明音  → 长按 E 开大 + 大招(R)
            → 连点平A，直到强化 E 图标亮起（弦能满）
            → 长按 E 放强化 E
            → 二段大招(R)
              （窗口只剩 0.5 秒时：不管强化 E 放没放出来，都直接放二段大）
    黑羽  → E → 大招(R)                     (二段大; 不判变身窗口)
    明音  → 连点平A，直到强化 E 图标亮起
            → 长按 E 放强化 E               (这步不再放二段大)
    早雾  → 回到本轮开头

切人链（浔是插入的，不算在固定链里）::

    明音(开局) → 浔E → 早雾 → 黑羽 → 明音 → 黑羽 → 明音 → 早雾 → ...

整场战斗跑在**同一个 perform() 里**：切人、按键、等待全部由本脚本控制，直到脱战
才把控制权还给框架。这样 planner 没有机会在轮中途按自己的评分把人换走，固定轴
不会散架（这是上一版反复踩的坑：队友一拿到站场就自己开大、自己抢首切）。

浔（老板娘）是插入牌
====================
浔**不在固定步骤里**：开局先入场放一次 E（开技能记录窗），之后只按能量插入：

* 能量满了 → 切浔做一次动作 → **立刻切回原角色**，从轴没走完的位置继续。
* 动作按 **Q → E → Q → E** 交替：
  - **Q**：放大招(R) + 跳 A 1~2 下 + A 10 下；
  - **E**：只重新开记录窗，不做跳 A。
* 用"能量上升沿"触发（先见到一次不满、再变满才插入）。否则 E 放完能量还满着的话，
  下一步会立刻又插进来。
* 每个固定步骤之前都会检查一次（`_maybe_boss_insert`），插入完回原角色再走那一步。

实现要点（都是踩过的坑）
========================
1. **R = 大招，E = 小技能**。队友的"大招"一律发终结技键；发弧盘键的话一个都放不出来。
   本轴用不到弧盘键。
2. **明音没有弧盘技能**，所以 `planner_handles_arc = True`：否则每次上场
   `perform()` 会先兜底按一次弧盘键，把流程第一步顶掉。
3. **不把切人决策交给 planner，尤其不能让环合反应自己切人**：
   * 固定轴期间整段跳过 `switch_next_char()`（它内部就是 `decide_switch()`）。
   * `has_intro` 每步前后、每次按键后都压成 False —— 环合反应决策的唯一开关就是它
     （`_element_reaction_decision` 第一行 `if not has_intro: return None`）。
   * 注意 `decide_switch()` 还会把"协奏值满"算成有入场资源
     （`has_intro = free_intro or current_char.is_cycle_full()`），所以只清 `has_intro`
     不够，必须连 `switch_next_char()` 一起跳过。
   * 交人统一走 `task._switch_to_char(..., has_intro=False, retry_intro=False)`：
     `retry_intro=True` 会在切人中途重新跑一次 `decide_switch()`，照样可能拉出环合反应。
4. **明音长按 E 开大**，但长按 E 不一定真的进大招：按完等 `AKANE_ULT_HOLD_WAIT`
   秒查一次大招图标，还亮着就补一次 R（补 R 同样要确认放出来）。
5. **强化 E 看 `akane_skill_2` 图标**：图标亮 = 弦能满 → 直接长按 E；没亮说明弦能
   还差一点，先补打 `ENHANCED_CHARGE_EXTRA` 秒再按——否则按出来的是普通 E，画面里
   根本看不到强化版。
6. **明音普攻 = 10Hz 连点**（照搬内置 `Akane.perform_ult_combo`）：`click()` +
   `sleep(0.1)` 每 0.1 秒点一下左键，每轮顺便查一次强化 E 图标。这样连段
   A1→A2→A3→A4 不会断，图标一亮立刻停手（0.1 秒级响应；之前长按 3.5 秒一段，
   要等最多 3.5 秒才知道弦能满了）。
7. **老板娘"跳 A"用空格键**：BaseChar 没有 `jump()`，要发 `space`。
8. **大招动画期间必须跳过战斗检测**：黑羽变身会把敌人血条和锁定 UI 一起盖住，
   框架的 `in_combat` 判不清楚 → `_recover_or_end_combat()` → `target_enemy` 重试
   3 秒仍失败 → `raise_not_in_combat` → **整场战斗被中断、重新 load_chars 开新战斗**。
   固定轴于是每隔十秒从"浔 E"重头跑一遍，日志里看起来就是"切人很乱"。
   解法：`skip_combat_check()` 在技能/大招动画的等待期间返回 True，框架会直接认定仍在
   战斗，不走 target_enemy（队友外壳也实现了同名方法，因为框架查的是当前角色）。
9. **开战首切明音**：`describe_role()` 把 `combat_start_priority` 提到 200。否则上一场
   结束时停在谁身上，下一场开局就是谁，再由队友外壳把站场交回明音 —— 又多一次乱切。
10. **E 交给内置 `click_skill()` 放，不要自己手写"按一次"**：它内部是
    `_try_available_action()` —— 只要技能还可用就一直重按，直到技能真的进 CD
    （=放出来了）或超时；被大招动画吞掉会自动补，正是内置角色不怕吞键的原因。
    注意要交给**当前在场角色**执行（`task.get_current_char().click_skill(...)`）：
    `self.skill_available()` 读的是明音自己的技能栏，队友在场时会查错人。
11. **大招后的等待一律条件驱动**：`_wait_team_visible(label, 上限, 最短)` —— 必须先
    见过战斗 UI（`is_in_team`）消失一次、再看到它回来才提前结束，上限只是兜底。
    不要写成固定 `sleep`，否则动画短于等待值就会"尬住"（角色站着不动）。
12. **强化 E 流程**：等 E 可用（不可用就连点补攒）→ 图标亮则直接按，不亮则补打
    `ENHANCED_CHARGE_EXTRA` 秒 → 停 `E_CAST_DELAY` 秒避开硬直 → `click_skill()` 重按到
    进 CD；没放出来就补攒后**重试一次**，绝不直接切人。
13. **闪避时也连 A**：`SoundCombatContext` 触发闪避会把主线程暂停、执行
    `DodgeCounterTrigger.dodge_action`（默认只按 Left Shift），这 0.3~0.8 秒连点循环
    根本跑不到。`_install_dodge_attack()` 把 dodge_action 换成 `_dodge_with_attack`
    （同样的 Left Shift 序列，末尾补 `DODGE_ATTACK_HITS` 下 A），所以闪避期间也有普攻；
    闪避结束后连点循环还会用 `ATTACK_RESUME_FACTOR` 补点接回连段。
14. **R 放出来了才等动画**：`_press_ultimate_verified()` 先查能量 → 按 R → 轮询大招图标
    变不可用（= 真的放出去了）。没放出来（能量不够/被吞）就不等动画直接走下一步，
    否则角色会站着发呆（使用者 2026-10-17 反馈"早雾 R 没放成功 在发呆"）。
15. 中途脱战/被秒会直接结束固定轴（`NotInCombatException` 不吞），下次开战从开局
    动作重新开始；单步出错只记日志、继续下一步，不让一处异常带崩整场。
16. **v1.4.22 的 planner 契约是无参调用**：`combat_plan()`、`combat_policies()` 都不传
    context（`CombatPlanner._plan_snapshot_for` / `_apply_combat_policies` 直接无参调）。
    框架的 `adapt_character_hooks()` 只适配"定义在具体角色类 `__dict__` 里"的覆盖，
    **不会**适配本文件里由队友子类继承得到的 `RotationPuppet` 方法。所以
    `RotationPuppet` 的两个 hook 必须写 `(self, *args, **kwargs)`——写成
    `(self, context)` 会在队友上场时直接抛
    `RotationPuppet.combat_policies() missing 1 required positional argument: 'context'`，
    整场战斗在 `load_chars()` 里就崩了。明音自己的 `combat_plan` 则保持无参签名，
    用正式的 `plan.register()`（不再走 deprecated 的 `planner_action()`）。
17. **`click_skill()` 超时在 v1.4.22 是"脱战异常"**：`_finish_skill_action()` 发现
    `timed_out` 会 `raise_not_in_combat("too long clicking a ultimate")`。早雾/浔的
    技能 CD 图标本来就经常读不出来，不处理的话一次读图失败就会结束整场战斗。
    `_press_skill_verified()` 按异常消息识别并吞掉它，只当作"这次没放出来"继续。
18. **按 E 之前必须先等队伍 UI 回来**：`click_skill()` 第一步查 `is_in_team()`，不在
    队伍画面（大招过场/切人动画）时直接返回、**一个键都不发**。早雾 R 后的动画比
    `ZAOWU_ULT_EXTRA_WAIT` 长时，`_wait_team_visible` 到上限返回，紧接的 E 就 1 毫秒
    "没放出来"——2026-11-02 实战两轮早雾 E 全丢。`_wait_team_ui()` 在按键前条件轮询
    UI 恢复，最多等 `SKILL_UI_WAIT` 秒。
19. **连点攒弦能期间不放普通 E**：普通 E 会把 E 打进 CD，等弦能满时强化 E 反而按不出
    （2026-11-02 实战 18:49:57 / 18:50:38 / 18:50:45 三次强化 E 都被 CD 吃掉，
    二段大也跟着过期）。用户口径始终只有"一直普攻直到强化 E 亮起"。
    强化 E 失败后的重试也按窗口剩余时间裁剪：剩余 ≤ `ENHANCED_SKILL_RETRY_RESERVE`
    就放弃重试、直接走二段大。

所有时间常量都在类顶部，手感不对只改那里，不用碰流程代码。
"""

import time
from contextlib import contextmanager

from src.char.Akane import Akane
from src.combat.BaseCombatTask import NotInCombatException
from src.combat.planner import FieldClaim, Planner, SwitchDecision
from src.Labels import Labels


class RotationPuppet:
    """固定轴队友的"执行器"外壳（三个队友文件都从这里 import）。

    为什么需要它：``AutoCombatTask`` 的主循环是「当前角色 perform() → planner 决定
    下一个人」。明音脚本把切人、按键全部写在一次 ``perform()`` 里，但只要把站场交回
    框架一瞬，planner 就会立刻按自己的评分重排队伍（浔的常驻 reservation 把明音换走、
    黑羽自己开一段大、早雾自己开辅助大招），固定轴就被冲散了。

    这个 mixin 做的事：
    * ``combat_plan()`` 返回空计划 —— 队友没有 planner 可见动作，不会自己放技能；
    * ``combat_policies()`` 返回 None —— 不发布队伍级策略/预留；
    * ``planner_handles_arc = True`` —— 抢到站场时 ``perform()`` 不先按弧盘键；
    * 压低 ``combat_start_priority`` / ``max_field_time`` —— 不抢首切、不赖场；
    * ``skip_combat_check()`` 跟着轴主的动画窗口走 —— 队友在场时也别误判脱战；
    * ``switch_next_char()`` 兜底把站场交回轴主，而不是交给 planner 重新评分。

    两条约束（改的时候别踩）：
    1. 本类**不能**继承 BaseChar：`CharRegistry` 要求每个外部角色文件"恰好一个
       BaseChar 子类"，本文件已经有一个 `AkaneMingyinLoop`。
    2. 队友文件用多重继承：``class BlackbirdPuppet(RotationPuppet, Blackbird)``，
       mixin 在前、原型在后 —— 这样 ``combat_plan`` 用空实现，普攻/技能等仍来自原型。

    历史：这个类原本单独放在一个下划线前缀的模块里，但工坊导出 zip 会跳过这类文件，
    导致分享出去的包缺文件、对方导入报 `external implementation could not be loaded`。
    所以并进主脚本，队友文件只从主脚本 import。
    """

    # 谁也不许在开战时抢站场: 明音脚本自己控制轮转顺序。
    combat_start_priority = 0
    # 不在场上滞留: planner 的内建站场动作 (planner_field_time) 直接失效。
    max_field_time = 0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 队友没有弧盘技能, 也不能让 perform() 开头先按一次弧盘键把技能顶掉。
        self.planner_handles_arc = True

    # 签名说明（v1.4.22 起）：planner 以**无参契约**调用 `combat_plan()` /
    # `combat_policies()`（`CombatPlanner._plan_snapshot_for` / `_apply_combat_policies`）。
    # 框架的 `adapt_character_hooks()` 只会适配"定义在具体角色类 `__dict__` 里"的覆盖，
    # 而这两个方法定义在本 mixin 里、由 BlackbirdPuppet 等子类**继承**得到，不会被适配。
    # 所以这里必须自己兼容两种调用方式（旧版传 context / 新版不传），
    # 否则就会报 `RotationPuppet.combat_policies() missing 1 required positional
    # argument: 'context'`，整场战斗在 planner reset 时直接崩掉。
    def combat_plan(self, *args, **kwargs):
        """返回空计划: 没有动作可做, 也就没有 planner 决策。"""
        return self.plan()

    def combat_policies(self, *args, **kwargs):
        """不发布任何队伍级策略 (浔的常驻 reservation / 记录路线全部关掉)。"""
        return None

    def skip_combat_check(self) -> bool:
        """轴主正在播大招/技能动画时, 队友这边也跳过战斗检测。

        `CombatCheck._check_active_combat()` 读的是**当前角色**的 `skip_combat_check()`。
        轴主把动画窗口打开时, 如果此刻站场在队友身上, 队友也必须回报"跳过", 否则
        黑羽变身的特效照样会被判成脱战（`target_enemy` 失败 -> 整场战斗被中断）。
        """
        for char in self.task.chars:
            if char is not None and getattr(char, "rotation_leader", False):
                return bool(getattr(char, "_animation_window", 0) > 0)
        return False

    def switch_next_char(self, post_action=None, free_intro=False):
        """队友异常拿到站场时, 把站场交回轴主, 不要交给 planner 重新评分。"""
        self.has_intro = False
        leader = next(
            (
                char
                for char in self.task.chars
                if char is not None and char is not self and getattr(char, "rotation_leader", False)
            ),
            None,
        )
        if leader is None or leader.is_dead or self.is_dead:
            return super().switch_next_char(post_action=post_action, free_intro=free_intro)
        if leader.is_current_char:
            return
        from src.combat.planner import SwitchDecision

        self.logger.info(f"puppet hand back field to rotation leader {leader.ufn_name}")
        self.task._switch_to_char(
            SwitchDecision(
                target=leader,
                reason="fixed rotation hand back",
                priority=0,
                has_intro=False,
            ),
            current_char=self,
            retry_intro=False,
        )

    def describe_role(self):
        """保留原型的能力画像, 但去掉抢站场的三个开关。

        `field_preference=SETUP_ONLY` 是参考社区队伍（残虹倾陷·早雾分支里早雾/阿德勒/
        达芙蒂尔都是 ``SETUP_ONLY + max_field_time=0``）的做法：它让普通切人评分里
        这个角色拿到 -80 而不是 SUB_DPS 的 +40，即使原型是主/副 C 也不会被 planner
        主动抬上场。固定轴自己决定谁上场，这里只是把 planner 的"想切人"压到最低。
        """
        profile = super().describe_role()
        profile.combat_start_priority = 0
        profile.max_field_time = 0
        profile.field_preference = Planner.FieldPreference.SETUP_ONLY
        return profile


class AkaneMingyinLoop(Akane):
    """明音队长：一个人把四个角色的固定轴串起来跑。"""

    cn_name = "明音"
    en_name = "Akane (Wheelchair Rotation)"
    # 给固定轴队友外壳看的标记: 队友异常拿到站场时, 会把站场交回给带这个标记的角色,
    # 而不是交给 planner 重新评分（重新评分就可能触发环合反应）。
    rotation_leader = True

    # ======================== 可调参数（手感不对只改这里）========================

    # ---- 通用 ----
    # 切人动画落地后, 再等多久才开始按键; 太短会打在切人动画里。
    SWITCH_SETTLE = 0.2
    # 切人键按下之前的稳定等待: 刚放完技能/时停收尾时按键会被吞，框架检测不到就会
    # 一直轮询（日志里见过 6.5 秒才靠血条变化确认），那段时间轴是卡住的。
    # 这段等待**不能空站**：正常连点普攻（`_do_switch` 里用 `_click_attack`），
    # 既保持输出又让角色动作自然（使用者 2026-10-18 要求）。
    SWITCH_PRESS_DELAY = 0.4
    # 放 E 用内置 `click_skill()` 时的重试上限（秒）: 它会一直重按直到技能进 CD 或超时。
    SKILL_CLICK_TIMEOUT = 2.5
    # 按 E 之前等"游戏画面回到队伍 UI"的上限（秒）。
    # `click_skill()` 第一步查 `is_in_team()`：不在队伍画面时直接返回、一个键都不发。
    # 早雾大招动画比 `ZAOWU_ULT_EXTRA_WAIT` 长时正好撞上这个 -> E 整个丢掉
    # （2026-11-02 实战 18:49:11 / 18:50:12 两轮早雾都没放出 E）。
    SKILL_UI_WAIT = 2.0
    # 按完 R 之后等多久确认"大招真的放出去了"（图标从可用变不可用）。
    # 超时就认为没放出来：不要再去等动画，否则角色会站着发呆。
    ULT_VERIFY_TIMEOUT = 1.2
    # 大招后等动画的统一写法: `*_MIN` 是最短等待（动画确实要开起来）, `*_WAIT` 是上限。
    # 中间用 `_wait_team_visible` 轮询战斗 UI, UI 一回来就提前结束 —— 不再硬等秒数,
    # 否则角色会站着不动（使用者 2026-10-17 反馈"尬住"）。

    # ---- 老板娘（浔）----
    BOSS_E_HOLD = 0.1            # 记录窗 E 按住的时长
    # E 之后只停一下: 这两个角色的技能 CD 图标经常读不出来, 再等也只是浪费时间
    # （使用者反馈"浔和早雾 E 的战场时间太长, 释放成功就能切人了"）。
    BOSS_E_WAIT = 0.3
    BOSS_ULT_MIN_WAIT = 0.5      # 大招按下后至少等这么久（动画起手）
    BOSS_ULT_WAIT = 1.5          # 动画等待上限
    BOSS_JUMP_ATTACKS = 3        # 跳 A 次数（跳 + A 算一次）
    BOSS_JUMP_LIFT = 0.35        # 起跳后多久按 A
    BOSS_JUMP_LAND = 0.45        # A 之后等落地
    BOSS_NORMAL_ATTACKS = 10     # 落地后连按 A 几下
    BOSS_ATTACK_INTERVAL = 0.2   # 每下 A 的间隔

    # ---- 早雾 ----
    ZAOWU_SKILL_HOLD = 0.25      # 早雾 E 要按久一点, 官方 click_skill_action 用的就是 0.25
    # 大招之后隔多久按 E（先大招后 E, 顺序别改反）。
    # E 交给 `click_skill()` 自己重试到放出来, 所以这里只等一个最短时间,
    # 不再硬等 2.6 秒（那 2.6 秒就是"尬住"的来源）。
    ZAOWU_ULT_TO_SKILL_GAP = 0.7
    # 之后等战斗 UI 回来的上限（兜底, UI 一回来就提前结束）。
    # 2.0 秒实测不够: 2026-11-02 两轮早雾大招到 2.0 秒上限时 UI 还没回来,
    # 紧接着按 E 就撞上"不在队伍画面"（click_skill 一个键都不发）。
    # 这里放宽到 3.0 秒, 后面 `_wait_team_ui()` 还会再兜一层。
    ZAOWU_ULT_EXTRA_WAIT = 3.0
    # E 之后只停一下就走, 不再等 CD 图标（读不准, 白等 1 秒多）。
    ZAOWU_SKILL_WAIT = 0.3

    # ---- 黑羽 ----
    BLACKBIRD_SKILL_HOLD = 0.1
    BLACKBIRD_SKILL_WAIT = 0.6   # E 之后隔多久按大招
    # 变身动画要等: 太早点击会被吞（实测 3.45 秒后偷 A, 画面一个 A 都没出）。
    # 现在靠 `_wait_team_visible` 的"见过 UI 消失再恢复"判断动画结束; UI 检测不到时
    # 才耗到 `WAIT` 上限。`MIN` 只保证动画确实起手了。
    BLACKBIRD_ULT_MIN_WAIT = 1.0
    BLACKBIRD_ULT_WAIT = 4.2
    BLACKBIRD_STEAL_ATTACKS = 2  # 黑羽 E+大招之后固定偷 A 的段数（R 没放出也打）
    STEAL_ATTACK_INTERVAL = 0.4  # 两下 A 之间留够时间, 连点会被吞
    # 偷 A 之后留一点收招时间再切人, 否则黑羽普攻挥到一半就换人（动作不连贯）。
    STEAL_ATTACK_SETTLE = 0.3
    BLACKBIRD_ULT_2_MIN_WAIT = 0.5  # 二段大: 最少等这么久
    BLACKBIRD_ULT_2_WAIT = 2.6      # 二段大: 动画等待上限

    # ---- 明音 ----
    AKANE_ULT_HOLD_E = 0.6       # 长按 E 开大, E 按住多久
    AKANE_ULT_HOLD_WAIT = 0.35   # 长按 E 之后等大招图标刷新
    AKANE_ULT_MIN_WAIT = 0.4     # 明音放大招后至少等这么久
    AKANE_ULT_WAIT = 1.5         # 明音大招动画等待上限
    # 大招窗口（内置 Akane.ULT_DURATION）：一段大之后超过这个时间二段大就没了，
    # 再按 R 会变成新的一段大。所以先判窗口，过了就跳过。
    AKANE_ULT_WINDOW = 20.0
    # 窗口只剩这么多秒时，**不管强化 E 放没放出来，都必须放二段大**——
    # 否则窗口一过，二段大就变成新的一段大 / 直接放不出来。
    AKANE_ULT_2_RESERVE = 0.5
    # 强化 E 也是长按 E。0.6 偶尔会被上一段连点普攻的收手硬直吃掉, 加长到 0.8 更稳。
    ENHANCED_SKILL_HOLD = 0.8
    ENHANCED_SKILL_WAIT = 0.5    # 强化 E 之后等动作
    # 按强化 E 之前先停一下: 等连点普攻收手 / 闪避（闪A）的硬直过去, 否则这一下会被吞。
    E_CAST_DELAY = 0.25
    # E 转好 ≠ 弦能满（E 的 CD 往往先好）: 检测到 E 可用后再补打这么久普攻,
    # 把弦能攒满再按 E, 才放得出强化版而不是普通 E。
    # 别调大: E 一好就该尽快放，1.2 秒的补打实测让强化 E 晚了近 2 秒
    # （2026-10-17 反馈"强化 E 好了没有第一时间放"）。0.5 秒只做最低限度攒能。
    ENHANCED_CHARGE_EXTRA = 0.5
    # 查强化 E 图标时最多等多久 —— 内置 Akane.perform_ult_combo 用的是 0.5 秒,
    # 这里压到 0.3 秒给"立即释放"让路。
    ENHANCED_ICON_WAIT = 0.3
    # 明音普攻改成**内置 Akane 的做法**：`click()` + `sleep(0.1)` 的 10Hz 连点，
    # 每点一下顺便查一次 E。连段不会断，E 一转好立刻停手（之前长按 3.5 秒才查一次，
    # E 好了最多还得干等 3.5 秒）。使用者 2026-10-17 决定改成这个。
    ATTACK_INTERVAL = 0.1        # 连点间隔（内置 perform_ult_combo 用的就是 0.1）
    # 某轮 sleep 实际耗时超过 `ATTACK_INTERVAL × 这个倍数` 就认为被闪避打断了，
    # 立刻补点一下把连段接回来（闪避会暂停主线程 0.3~0.8 秒）。
    ATTACK_RESUME_FACTOR = 2.0
    # 强化 E 图标亮起之后再多打这么久，让当前这刀（A3/A4）收完再停手按 E。
    # 否则连段正打在 A3、A4 中间就被 E 打断（使用者反馈"第二套 A3 和 A4 之间就切走了"）。
    ENHANCED_RELEASE_TAIL = 0.35
    # 闪避自己的动作里也带上 A：次数与间隔。使用者要求"闪避时也一直普攻连A"，
    # 闪避期间主线程被 SoundCombatContext 暂停，连点循环跑不到，只能把点 A
    # 塞进 dodge_action 里（见 `_dodge_with_attack`）。
    DODGE_ATTACK_HITS = 2
    DODGE_ATTACK_INTERVAL = 0.08
    # 连点攒弦能最多打多久（大招窗口 20 秒, 得给后面的强化 E / 二段大留时间）。
    ATTACK_UNTIL_SKILL_TIMEOUT = 12.0
    # 强化 E 前 E 可能还在 CD: 最多再连点补攒多久。
    ENHANCED_SKILL_TIMEOUT = 5.0
    # 强化 E 没放出来时，补攒这么久再重试一次（不能直接切人）。
    ENHANCED_SKILL_RETRY_WAIT = 0.6
    # 强化 E 失败后，窗口剩余少于这么多秒就不再重试（重试要 2~5 秒，
    # 会把二段大拖过期）。2026-11-02 实战就是重试 8 秒把二段大弄没的。
    ENHANCED_SKILL_RETRY_RESERVE = 2.0

    # ---- 行为开关 ----
    # 浔不再占固定步骤: 开局放一次 E, 之后能量满就插进来（见 `_maybe_boss_insert`）。

    # ================================ 初始化 =================================

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 明音没有弧盘技能: 关掉 perform() 开头的弧盘兜底按键, 否则每次上场都会先
        # 按一次弧盘键, 把流程第一步顶掉。
        self.planner_handles_arc = True
        # 本场战斗跑到第几轮（只用于日志和"开局老板娘 E"判定）。
        self._round_index = 0
        # 固定轴接管期间跳过 perform() 末尾的框架切人。
        self._skip_final_switch = False
        # 本次入场是否已经跑过固定轴（防 planner 在同一次入场里重复执行动作）。
        self._entry_step_done = False
        # 浔是"插入牌": 下次切进来该做什么（"E" 开记录窗 / "Q" 放大招）。
        self._boss_next_action = "E"
        # 能量"上升沿"检测: 只有见过一次"没满"之后再次变满才触发插入,
        # 否则 E 放完能量还满着的话会立刻又插进来。
        self._boss_seen_not_ready = True
        # 用来识别"新的一场战斗", 新战斗要复位轮次和浔的插入状态。
        self._session_ref = None
        # 大招/技能动画窗口计数: 窗口内跳过战斗状态检测 (见 skip_combat_check)。
        self._animation_window = 0
        # 连点普攻期间是否看到过强化 E 图标（`_auto_attack(watch_enhanced=True)` 会写）。
        self._enhanced_hit = False

    # ================================ planner ================================

    def describe_role(self):
        """开战首切一定要是明音。

        上一场战斗结束时停在谁身上, 下一场开局就是谁（例如黑羽），然后黑羽的
        执行器外壳再把站场交回明音 —— 看着就是一次多余的乱切。给明音一个首切
        优先级, `begin_combat_session()` 会直接把她切上场。
        """
        profile = super().describe_role()
        profile.combat_start_priority = 200
        return profile

    def skip_combat_check(self) -> bool:
        """大招/技能动画窗口内跳过战斗状态检测。

        实测（2026-10-17 17:38 那场）黑羽按 R 后 1.6 秒, 变身特效盖住敌人血条,
        框架的 `in_combat` 判不清楚 -> `_recover_or_end_combat()` -> `target_enemy`
        重试 3 秒仍失败 -> `raise_not_in_combat` -> 整场战斗被迫结束、重新
        `load_chars()` 开新战斗。固定轴于是每隔十秒从头跑一遍（浔 E → 早雾 → 黑羽 …),
        看起来就是"切人很乱"。

        框架本来就留了这个开关: `CombatCheck._check_active_combat()` 在
        `get_current_char().skip_combat_check()` 为真时直接认定还在战斗, 不走
        target_enemy。所以只在"技能/大招动画正在播"的等待期间把它打开。
        """
        return self._animation_window > 0

    @contextmanager
    def _animation_guard(self):
        """标记"现在在播动画, 别做战斗检测", 退出时自动恢复。"""
        self._animation_window += 1
        try:
            yield
        finally:
            self._animation_window -= 1

    def combat_plan(self):
        """把整条固定轴声明成一个动作。

        动作一执行就会跑完整轮循环（直到脱战），所以 planner 在一次入场里只会看到
        这一个动作。`can_execute` 保证同一次入场不会被重复执行。

        签名保持**无参**（v1.4.22 的 planner 契约）：`CombatPlanner._plan_snapshot_for`
        调的是 `char.combat_plan()`。这里不用旧的 `planner_action()` 而是
        `plan.register()`：后者是 v1.4.20 起的正式接口，`can_execute` 也是无参回调，
        不再走 `ActionIntent` 兼容层。
        """
        plan = self.plan()
        plan.register(
            self._run_rotation,
            name="mingyin_wheelchair_rotation",
            tags={Planner.ActionTag.DAMAGE, Planner.ActionTag.HIGH_PRIORITY},
            slot=Planner.ActionSlot.LEGACY_COMBO,
            reason="明音轮椅轴",
            can_execute=lambda: not self._entry_step_done,
        )
        # 兜底: 万一固定轴被异常打断、站场落在队友身上, strict claim 能让 planner
        # 把明音切回来, 下一轮 perform 继续跑轴。正常跑轴期间不会走到这里。
        plan.add(FieldClaim.strict(reason="明音轮椅轴接管站场"))
        return plan

    def perform(self):
        """每次上台重新获得"执行固定轴"的资格。"""
        self._entry_step_done = False
        return super().perform()

    def switch_next_char(self, post_action=None, free_intro=False):
        """固定轴接管期间跳过 perform() 末尾的框架切人。

        `switch_next_char` 会调用 `planner.decide_switch()`: 只要当前角色的协奏值满了
        (`is_cycle_full()`), planner 就会把 `has_intro` 当成 True, 于是环合反应
        (优先级 999500) 直接把人换走。固定轴自己决定下一个是谁, 所以整场战斗都跳过它。
        """
        if self._skip_final_switch:
            self.logger.info("[轮椅轴] 站场由固定轴接管, 跳过框架切人(含环合反应)")
            self.has_intro = False
            self._ultimate_available = self.ultimate_available() if self.is_current_char else False
            return
        super().switch_next_char(post_action=post_action, free_intro=free_intro)

    # ============================== 循环主流程 ==============================

    def _run_rotation(self, context=None) -> bool:
        """一整轮接一整轮地跑，直到脱战。浔不占固定步骤，能量满了随时插进来。"""
        self._entry_step_done = True
        self._skip_final_switch = True
        self._begin_new_combat_if_needed()
        self._warn_broken_teammates()
        # 先让框架确认一次战斗状态, 把 scene 的 in_combat 缓存点亮:
        # 缓存为 True 之后 `in_combat()` 会直接返回缓存, 不会再因为特效遮挡血条
        # 去跑 target_enemy（那一步会卡 3 秒, 失败就把整场判死）。
        self.task.in_combat()
        # 闪避动作里也补 A（使用者要求"闪避时也一直普攻连A"）。
        self._install_dodge_attack()
        self.logger.info("[轮椅轴] 固定轴接管（浔改为能量满时插入）")
        while self.task.in_combat():
            if self.is_dead:
                self.logger.warning("[轮椅轴] 明音阵亡, 停止固定轴")
                break
            self._round_index += 1
            self.logger.info(f"[轮椅轴] ===== 第 {self._round_index} 轮 =====")
            if self._round_index == 1:
                # 首轮浔先入场开记录窗; 之后她只按能量插入。
                self._run_step("老板娘·E(开局记录窗)", "_step_boss_open")
            for name, method_name in self.LOOP:
                # 每一步之前看一眼浔的能量: 满了就插进来打一套, 再回原角色继续。
                #
                # 这里**不要**再查 `task.in_combat()`: 明音/黑羽大招特效会把血条盖住，
                # 这一查会被判脱战，然后 `break` 掉整个 for —— 后面的步骤（比如黑羽
                # 二段大、明音第二次强化E）就直接没了，表现就是"轴乱"（2026-10-18 日志：
                # 明音二段大之后空 3.4 秒直接跳第 2 轮）。
                # 真脱战由 `_run_step` 里的 `NotInCombatException` 负责，它会往外抛。
                self._maybe_boss_insert()
                self._run_step(name, method_name)
            # 轮末把入场标记压掉, 下一轮由早雾重新开始。
            self.clear_intro()
        self.logger.info("[轮椅轴] 脱战/中断, 停止固定轴")
        # 兜底: 如果是因为明音阵亡以外的原因跳出来, 把站场收回明音, 免得队友空转。
        if self.task.in_combat():
            self._back_to_mingyin()
        return True

    def _run_step(self, name: str, method_name: str) -> None:
        """执行一步；单步异常只记日志，不中断整轮（脱战异常要放行）。"""
        self.logger.info(f"[轮椅轴] {name}")
        # 每步开头、结尾都压一次入场标记: 环合反应切人的唯一开关就是它。
        self.clear_intro()
        try:
            getattr(self, method_name)()
        except NotInCombatException:
            raise
        except Exception as error:
            self.logger.error(f"[轮椅轴] {name} 执行失败: {error}")
        self.clear_intro()

    def _begin_new_combat_if_needed(self) -> None:
        """新的一场战斗 → 轮次和浔的插入状态都回到初始状态。"""
        session = self.task.combat_session
        if session is None or session is self._session_ref:
            return
        self._session_ref = session
        self._round_index = 0
        self._boss_next_action = "E"
        self._boss_seen_not_ready = True
        self.logger.info("[轮椅轴] 新战斗: 复位轮次和浔的插入状态")

    # ============================== 固定的步骤 ==============================

    def _step_boss_open(self):
        """开局：浔先入场放 E 开技能记录窗，放完就走。"""
        if not self._switch_to("老板娘"):
            return
        self._press_skill_verified("E(浔·开局记录窗)", self.BOSS_E_HOLD, self.BOSS_E_WAIT)
        self._boss_next_action = "Q"

    def _step_zaowu(self):
        """早雾：先大招、后 E；**R 真放出来了才等动画**，E 交给 click_skill 重试。"""
        if not self._switch_to("早雾"):
            return
        zaowu = self._find_teammate("早雾")
        if self._press_ultimate_verified(zaowu, "R(早雾·大招)"):
            # 先等一个最短时间, 之后 UI 一回来（动画结束）就提前按 E。
            self._wait_team_visible(
                "早雾·大招", self.ZAOWU_ULT_EXTRA_WAIT, self.ZAOWU_ULT_TO_SKILL_GAP
            )
        else:
            self.logger.info("[轮椅轴] 早雾 R 没放出来, 不等动画, 直接 E")
        self._press_skill_verified("E(早雾·技能)", self.ZAOWU_SKILL_HOLD, self.ZAOWU_SKILL_WAIT)

    def _step_blackbird_open(self):
        """黑羽：E → 大招 → 偷 A 2 下。

        R 放出来了就等变身动画再偷 A；R 没放出来（能量不够/被吞）不等动画，
        **但仍然补 A 2 下**（使用者 2026-10-17："黑羽E大招之后还是要A俩下"）。
        """
        if not self._switch_to("黑羽"):
            return
        blackbird = self._find_teammate("黑羽")
        self._press_skill("E(黑羽·技能)", self.BLACKBIRD_SKILL_WAIT, self.BLACKBIRD_SKILL_HOLD)
        if self._press_ultimate_verified(blackbird, "R(黑羽·大招)"):
            # 变身动画还没收尾时点左键会被吃: 最少等 MIN, UI 回来就提前偷 A。
            self._wait_team_visible(
                "黑羽·大招", self.BLACKBIRD_ULT_WAIT, self.BLACKBIRD_ULT_MIN_WAIT
            )
        else:
            self.logger.info("[轮椅轴] 黑羽 R 没放出来, 不等动画, 但照样 A 两下")
        self._steal_attacks("黑羽", self.BLACKBIRD_STEAL_ATTACKS)

    def _step_akane_burst(self):
        """明音：长按 E 开大 → 一直打平A 攒弦能 → 弦能满长按强化 E → 二段大。

        使用者 2026-10-17 简化口径：开大之后不要数"打几套"，**一直连点平A**，
        强化 E 图标（弦能满）一亮就长按 E 放，放完直接接二段大。
        连点期间每一下都盯图标，所以不会出现"图标亮了还在打"的情况。
        """
        if not self._switch_to("明音"):
            return
        self._start_ultimate()
        self._attack_until_enhanced_ready()
        if self._ult_window_remaining() > self.AKANE_ULT_2_RESERVE:
            self._enhanced_skill("弦能满")
        else:
            self.logger.warning(
                f"[轮椅轴] 大招窗口只剩 {self._ult_window_remaining():.1f}s, "
                "跳过强化 E, 直接放二段大"
            )
        self._press_my_ultimate_if_ready("R(明音·二段大)")

    def _step_akane_after_ult2(self):
        """明音：二段大之后切回来，普攻到强化 E 亮起再长按 E（这步不放大招）。

        使用者 2026-10-17 口径："切明音 一直普攻直到 强化E亮起，长按E"。
        二段大已经放过了，所以不受大招窗口兜底限制（`protect_ult2=False`）。
        """
        if not self._switch_to("明音"):
            return
        self._attack_until_enhanced_ready(watch_ult_window=False)
        self._enhanced_skill("二段大后", protect_ult2=False)

    def _step_blackbird_ult_2(self):
        """黑羽：切过去放 E + 大招（二段大在后台没有时间限制）。

        不再判什么变身窗口：切到黑羽就 E（可用才按）+ 大招。只考虑没放成功怎么办——
        R 没放出来（能量不够/被吞）就不等动画，直接走下一步，别站着发呆。
        """
        blackbird = self._find_teammate("黑羽")
        if blackbird is None or not self._switch_to("黑羽"):
            return
        if self._teammate_skill_ready(blackbird):
            self._press_skill(
                "E(黑羽·技能)", self.BLACKBIRD_SKILL_WAIT, self.BLACKBIRD_SKILL_HOLD
            )
        else:
            self.logger.info("[轮椅轴] 黑羽 E 还在 CD, 这次只放大招")
        if self._press_ultimate_verified(blackbird, "R(黑羽·二段大)"):
            self._wait_team_visible(
                "黑羽·二段大", self.BLACKBIRD_ULT_2_WAIT, self.BLACKBIRD_ULT_2_MIN_WAIT
            )
        else:
            self.logger.info("[轮椅轴] 黑羽二段大 R 没放出来, 不等动画直接走")

    # ============================ 浔（插入牌） ============================

    def _maybe_boss_insert(self) -> bool:
        """浔是"插入牌": 能量满了就切进来，打完/放完立刻回原角色继续轴。

        使用者 2026-10-17 口径：
        * 首轮先入场放 E（开技能记录窗），之后不再占固定步骤。
        * 之后能量满 → 切浔：`_boss_next_action` 是 "Q" 就放大招 + 跳 A + A 10 下；
          是 "E" 就放记录窗 E。做完切回原角色，从轴的原位置继续。
        * 动作按 Q → E → Q → E 交替。

        用"上升沿"触发（先见到一次不满、再变满才插入）：否则 E 放完能量还满着的话，
        下一步又会立刻插进来。
        """
        boss = self._find_teammate("老板娘")
        if boss is None or boss.is_dead:
            return False
        if not self._teammate_ultimate_ready(boss):
            self._boss_seen_not_ready = True
            return False
        if not self._boss_seen_not_ready:
            return False
        self._boss_seen_not_ready = False

        previous = self.task.get_current_char(raise_exception=False)
        action = self._boss_next_action
        back_to = previous.ufn_name if previous is not None else "?"
        self.logger.info(f"[轮椅轴] 浔能量满 -> 插入 {action}（打完回 {back_to}）")
        if not self._switch_to("老板娘"):
            return False
        if action == "Q":
            # 浔的大招是时停: 用框架时钟（monotonic）登记 freeze, 不能用 time.time()
            # 的 Unix 时间戳——两者参考点不同, `time_elapsed_accounting_for_freeze`
            # 会算出错误的窗口（v1.4.18 起框架统一使用 `src.utils.clock`）。
            freeze_start = self.clock.now()
            if self._press_ultimate_verified(boss, "R(浔·大招)"):
                self._wait_team_visible(
                    "浔·大招", self.BOSS_ULT_WAIT, self.BOSS_ULT_MIN_WAIT
                )
                self._boss_jump_attacks()
                # 浔的大招是**时停**：这段时间游戏内不计时。登记成 freeze，否则黑羽/明音的
                # 二段大窗口会被这 7 秒误判成"已过"（使用者 2026-10-17 指出）。
                self.add_freeze_duration(freeze_start, self.clock.now() - freeze_start)
            else:
                self.logger.info("[轮椅轴] 浔 R 没放出来, 不等动画、不跳A, 只打落地A")
            self._boss_normal_attacks()
            self._boss_next_action = "E"
        else:
            self._press_skill_verified("E(浔·记录窗)", self.BOSS_E_HOLD, self.BOSS_E_WAIT)
            self._boss_next_action = "Q"
        self._switch_back_to(previous)
        return True

    def _switch_back_to(self, target) -> bool:
        """插入结束后切回原来的角色，继续没走完的轴。"""
        if target is None or target.is_dead:
            return False
        if target.is_current_char:
            return True
        self.logger.info(f"[轮椅轴] 插入结束, 切回 {target.ufn_name}")
        return self._do_switch(target)

    # =============================== 明音动作 ===============================

    def _start_ultimate(self) -> None:
        """长按 E 开大；长按 E 没进大招时补一次 R。

        两种情况都要记下 `last_ultimate_time`：二段大的窗口是从一段大时刻开始算的。
        """
        self.logger.info("[轮椅轴] 明音 长按 E 开大")
        self.send_key(self.get_skill_key(), down_time=self.AKANE_ULT_HOLD_E)
        with self._animation_guard():
            self.sleep(self.AKANE_ULT_HOLD_WAIT)
        if self.ultimate_available():
            self.logger.info("[轮椅轴] 长按 E 后大招图标仍亮 -> 补按 R")
            self._press_my_ultimate("R(明音·大招)")
        else:
            self.logger.info("[轮椅轴] 长按 E 已进入大招")
            # 用框架时钟域: `time_elapsed_accounting_for_freeze` 只认 monotonic,
            # 传 time.time() 的 Unix 秒会让窗口算成巨大负数（v1.4.18+）。
            self.last_ultimate_time = self.clock.now()

    def _click_attack(
        self, seconds: float, tag: str = "", watch_enhanced: bool = False
    ) -> int:
        """10Hz 连点普攻，持续 `seconds` 秒（对齐内置 `Akane.perform_ult_combo`）。

        内置就是 `self.click()` + `self.sleep(0.1)`：每 0.1 秒点一次左键。这样连段
        （A1→A2→A3→A4）不会断，也不会像"慢速点 4 下"那样只出 A1/A2。

        连点期间算"动画窗口"（`_animation_guard`）：普攻/大招特效盖住血条时，
        `normal_attack()` 里的 `check_combat()` 会被判脱战（就是"卡住不切人"那种）。

        每轮 sleep 之后查一次实际耗时：明显超时就说明中间插了闪避
        （`SoundCombatContext` 会暂停主线程去按 Left Shift），这一轮等于白停
        0.3~0.8 秒，连段就断档了。这时补点一下把节奏接回来（使用者反馈
        "闪避后有时候平A慢了"）。

        `watch_enhanced=True`：每一轮顺便看一眼强化 E 图标（`akane_skill_2`），
        一亮就立刻停手、把 `_enhanced_hit` 置 True——这样 E 好了不用等整套平A
        打完才检查（使用者 2026-10-17 要求"一直监听明音 E 的图标"）。

        返回实际点了几下，方便日志核对。
        """
        clicks = 0
        resumed = 0
        hit_at = 0.0
        # 用框架时钟（`clock.now()`，单调秒）而不是 time.time()：项目约定所有
        # 时长/窗口都走 src.utils.clock，避免时停 freeze 和参考点不一致
        # （参考社区队伍 zankou.py 用 self.clock.timer 的写法）。
        deadline = self.clock.now() + seconds
        with self._animation_guard():
            while self.clock.now() < deadline:
                self.normal_attack()
                clicks += 1
                started = self.clock.now()
                self.sleep(self.ATTACK_INTERVAL)
                if self.clock.now() - started > self.ATTACK_INTERVAL * self.ATTACK_RESUME_FACTOR:
                    # 这一轮被闪避/声音动作打断了：立刻补一下接回连段。
                    self.normal_attack()
                    clicks += 1
                    resumed += 1
                if watch_enhanced and hit_at == 0.0 and self._enhanced_ready():
                    hit_at = self.clock.now()
                    self._enhanced_hit = True
                    self.logger.info(
                        f"[轮椅轴] 明音 强化E图标亮起 ({tag}, 连点 {clicks} 下), "
                        f"再收尾 {self.ENHANCED_RELEASE_TAIL}s 就停手"
                    )
                # 图标亮起后再打一小段收尾，避免连段正打在 A3/A4 中间被 E 打断。
                if hit_at and self.clock.now() - hit_at >= self.ENHANCED_RELEASE_TAIL:
                    break
                self.clear_intro()
        if resumed:
            self.logger.info(
                f"[轮椅轴] 明音 连点被闪避打断 {resumed} 次, 已补点接回 ({tag})"
            )
        return clicks

    def _auto_attack(
        self, seconds: float, tag: str = "", watch_enhanced: bool = False
    ) -> bool:
        """连点普攻一段时间（补打攒弦能 / 强化 E 重试前用）。

        返回 True 表示这段时间里强化 E 图标亮起了（连点被提前打断）。
        """
        self._enhanced_hit = False
        clicks = self._click_attack(seconds, tag, watch_enhanced)
        self.logger.info(f"[轮椅轴] 明音 连点普攻 ({tag}, {seconds}s, {clicks} 下)")
        return self._enhanced_hit

    # ============================ 闪避时也连 A ============================

    def _install_dodge_attack(self) -> None:
        """把"闪避动作里也点 A"注册到声音触发上。

        `SoundCombatContext` 触发闪避时会把主线程暂停、执行 `DodgeCounterTrigger`
        的 `dodge_action`（默认只按 Left Shift）。暂停期间我们的连点循环跑不到，
        所以闪避那 0.3~0.8 秒一下 A 都不出。这里换掉 dodge_action，让闪避自己
        带 A——使用者要求"闪避时也一直普攻连A"。
        """
        try:
            self.task._apply_sound_config(dodge_action=self._dodge_with_attack)
            self.logger.info("[轮椅轴] 已注册闪避连A（闪避动作里会补普攻）")
        except Exception as error:
            self.logger.warning(f"[轮椅轴] 注册闪避连A失败: {error}")

    def _dodge_with_attack(self) -> None:
        """闪避动作本体：Left Shift 起跳后立刻补几下 A，保持普攻连段不断。

        与内置 `DodgeCounterTrigger._default_dodge_action` 相同的按键序列，
        末尾额外点 A。这个方法在 `SoundCombatContext` 的主线程暂停窗口里执行，
        所以这里 sleep 的时间就是闪避动作本身的时间。
        """
        try:
            self.task.send_key_down("d")
            time.sleep(0.02)
            self.task.send_key("lshift")
            time.sleep(0.02)
        finally:
            self.task.send_key_up("d")
            time.sleep(0.02)
        self.task.send_key("lshift")
        time.sleep(0.02)
        # 闪避后继续 A：不经过 normal_attack（它会做战斗检测，闪避窗口里不合适）。
        for _ in range(self.DODGE_ATTACK_HITS):
            self.task.click()
            time.sleep(self.DODGE_ATTACK_INTERVAL)

    def _attack_until_skill_ready(
        self, tag: str = "", timeout: float = 0.0, charge: bool = True
    ) -> bool:
        """10Hz 连点普攻，一直点到 E 能释放（弦能满）为止。

        完全对齐内置 `Akane.perform_ult_combo`：每轮点一下左键、顺便查一次
        `skill_available()`，E 一转好立刻停手——不用等"打完一套"才检查，所以
        E 的响应是 0.1 秒级，而不是长按时代的最多 3.5 秒。

        `charge`：E 转好之后要不要再补打 `ENHANCED_CHARGE_EXTRA` 秒把弦能攒满。
        **同一个步骤里只能补一次**——之前 `_attack_until_skill_ready` 和
        `_enhanced_skill` 各补一次，E 好了还硬打了 2.4 秒（2026-10-17 反馈
        "强化 E 好了没有释放, 又打了一会普攻"）。
        """
        timeout = timeout or self.ATTACK_UNTIL_SKILL_TIMEOUT
        if self.skill_available():
            if charge:
                self._charge_after_skill_ready(tag, "一开始就可用")
            return True
        start = self.clock.now()
        clicks = 0
        # 注意循环里**不要**再查 `task.in_combat()`: 大招特效盖着血条时这一查会被
        # 判脱战（target_enemy 卡 3 秒后整场结束），表现就是"卡住不切人"。
        # 真脱战由步骤边界的检查负责，这里靠超时兜底。
        with self._animation_guard():
            while self.clock.now() - start < timeout:
                if self.skill_available():
                    elapsed = self.clock.now() - start
                    self.logger.info(
                        f"[轮椅轴] 明音 E 转好 ({tag}, 连点 {clicks} 下, {elapsed:.1f}s)"
                    )
                    if charge:
                        self._charge_after_skill_ready(
                            tag, f"连点普攻 {elapsed:.1f}s"
                        )
                    return True
                self.normal_attack()
                clicks += 1
                started = self.clock.now()
                self.sleep(self.ATTACK_INTERVAL)
                # 同 `_click_attack`: 这轮被闪避打断就补点一下，别让连段断档。
                if self.clock.now() - started > self.ATTACK_INTERVAL * self.ATTACK_RESUME_FACTOR:
                    self.normal_attack()
                    clicks += 1
                self.clear_intro()
        self.logger.warning(
            f"[轮椅轴] 明音 E 连点普攻打 {timeout:.0f}s 还没转好, 按现状继续"
        )
        return self.skill_available()

    def _ult_window_remaining(self) -> float:
        """距明音大招窗口结束还剩多少秒（扣除浔大招的时停）。"""
        if self.last_ultimate_time <= 0:
            return self.AKANE_ULT_WINDOW
        return self.AKANE_ULT_WINDOW - self.time_elapsed_accounting_for_freeze(
            self.last_ultimate_time
        )

    def _normal_skill_hold(self) -> float:
        """普通 E 的按键时长：Boss 战点按 0.01 秒、平时 0.3 秒（对齐内置 Akane）。

        注意：固定轴连点攒弦能期间**不再放普通 E**（会把 E 打进 CD，抢掉强化 E）。
        这个方法只在明确要按普通 E 的场景才用。
        """
        return 0.01 if getattr(self.task, "_boss_fight", False) else 0.3

    def _attack_until_enhanced_ready(
        self, timeout: float = 0.0, watch_ult_window: bool = True
    ) -> bool:
        """一直连点平A，直到强化 E 图标亮起（弦能满）或超时。

        使用者 2026-10-17 简化口径："长按E 一直打平A，弦能满了长按强化E"——
        不再数"打几套"，图标一亮立刻停手，所以不会出现"图标亮了还在打"。
        连点期间算动画窗口，避免普攻特效遮住血条被判脱战。

        **连点期间不放普通 E**（2026-11-02 实战日志修正）：之前对齐内置
        `Akane.perform_ult_combo`，E 一转好就先放普通 E。但这套轴里 E 是留给
        强化 E 的——普通 E 一放，E 就进 CD（实测 5 秒以上），等弦能满时
        `click_skill()` 按的 E 全被 CD 吃掉：日志里 18:49:57、18:50:38、18:50:45
        的三次强化 E 全是"技能不可用/按键被吞"，二段大也因此过期。
        用户口径从头到尾只有"一直普攻直到强化 E 亮起"，没有普通 E 这一步。

        `watch_ult_window=False`：二段大已经放过了，大招窗口早结束也无所谓，
        这时必须一直打到弦能满为止，不能被窗口兜底打断。
        """
        timeout = timeout or self.ATTACK_UNTIL_SKILL_TIMEOUT
        start = self.clock.now()
        clicks = 0
        with self._animation_guard():
            while self.clock.now() - start < timeout:
                # 窗口快到了: 停止连点, 把剩下的时间留给二段大（使用者 2026-10-17）。
                if watch_ult_window:
                    remaining = self._ult_window_remaining()
                    if remaining <= self.AKANE_ULT_2_RESERVE:
                        self.logger.warning(
                            f"[轮椅轴] 大招窗口只剩 {remaining:.1f}s, 停止连点, 准备二段大"
                        )
                        return False
                # 弦能满 -> 立刻停手，交给 `_enhanced_skill` 放强化 E。
                if self._enhanced_ready():
                    self.logger.info(
                        f"[轮椅轴] 明音 弦能满 (连点 {clicks} 下, "
                        f"{self.clock.now() - start:.1f}s)"
                    )
                    return True
                self.normal_attack()
                clicks += 1
                started = self.clock.now()
                self.sleep(self.ATTACK_INTERVAL)
                if self.clock.now() - started > self.ATTACK_INTERVAL * self.ATTACK_RESUME_FACTOR:
                    self.normal_attack()
                    clicks += 1
                self.clear_intro()
        self.logger.warning(
            f"[轮椅轴] 明音 连点 {timeout:.0f}s 弦能仍未满, 按现状继续"
        )
        return False

    def _charge_after_skill_ready(self, tag: str, when: str) -> None:
        """E 转好之后再补打一小段普攻，确保弦能真的攒满。

        E 的 CD 往往比弦能攒满快：只等到"E 可用"就按 E，游戏里放出来的是普通 E，
        不是强化 E（使用者反馈"闪A 后没有打强化 E 就切走了"）。所以这里多连点
        `ENHANCED_CHARGE_EXTRA` 秒；如果强化 E 图标在 0.5 秒内出现（内置
        `perform_ult_combo` 用的也是 `wait_until(..., time_out=0.5)`），说明弦能
        确实满了，直接跳过补打。
        """
        if self._enhanced_ready(self.ENHANCED_ICON_WAIT):
            self.logger.info(f"[轮椅轴] 明音弦能已满 ({when})")
            return
        self.logger.info(
            f"[轮椅轴] 明音 E 已可用 ({when}), 再连点普攻 "
            f"{self.ENHANCED_CHARGE_EXTRA}s 攒满弦能再放强化 E"
        )
        self._auto_attack(self.ENHANCED_CHARGE_EXTRA, "补打攒弦能")

    def _enhanced_skill(self, tag: str = "", protect_ult2: bool = True) -> bool:
        """明音强化 E：弦能满时长按 E 释放，并按 CD 确认真的放出来了。

        弦能满和 E 转好不是同一件事（E 的 CD 往往先好），所以流程是：
        先等 E 可用（`_attack_until_skill_ready`）→ 再补打一小段把弦能攒满
        （`_charge_after_skill_ready`）→ 停 `E_CAST_DELAY` 秒避开松手/闪避硬直 →
        长按 E → 查 `has_cd("skill")` 确认放出，没进 CD 就补按一次。

        2026-10-17 两次反馈都指向这里：先"闪避后没放出强化 E 就切走了"，后"闪A 后
        没打强化 E"——前者是硬直吃键，后者是弦能没满（放出来的是普通 E）。

        `Labels.akane_skill_2`（强化 E 图标）：命中就是弦能满、直接放；没命中说明弦能
        可能还差一点，**先补打 `ENHANCED_CHARGE_EXTRA` 秒**（期间继续盯图标）再按——
        否则按出来的是普通 E，画面里看不到强化版（2026-10-17 反馈"这一场没放强化 E
        就切黑羽了"，日志里正是 `强化 E 图标未命中` 之后直接按了 E）。

        窗口兜底：`_ult_window_remaining()` 只剩 `AKANE_ULT_2_RESERVE` 秒时直接放弃
        强化 E —— 二段大比强化 E 重要，窗口一过就什么都没了（使用者 2026-10-17）。
        `protect_ult2=False` 时不做这个检查：二段大已经放过了，窗口结束也不影响。
        """
        if protect_ult2:
            remaining = self._ult_window_remaining()
            if remaining <= self.AKANE_ULT_2_RESERVE:
                self.logger.warning(
                    f"[轮椅轴] 大招窗口只剩 {remaining:.1f}s, 跳过强化 E, 保留二段大"
                )
                return False
        waited = self._wait_skill_ready()
        if not self.skill_available():
            self.logger.info("[轮椅轴] 明音 E 等不到可用, 跳过强化 E")
            return False
        if waited > 0.4:
            self.logger.info(f"[轮椅轴] 多等了 {waited:.1f}s 让 E 转好")
        if self._enhanced_ready():
            self.logger.info(f"[轮椅轴] 弦能已满, 长按 E 释放强化 E ({tag})")
        else:
            self.logger.info(
                f"[轮椅轴] 强化 E 图标未命中, 补打 {self.ENHANCED_CHARGE_EXTRA}s "
                f"确保弦能满再按 E ({tag})"
            )
            self._auto_attack(
                self.ENHANCED_CHARGE_EXTRA, "强化 E 前补打", watch_enhanced=True
            )
        # 等连点普攻收手 / 闪避（闪A）的硬直过去, 否则长按 E 会被游戏吞掉。
        with self._animation_guard():
            self.sleep(self.E_CAST_DELAY)
        clicked = self._press_skill_verified(
            f"E(强化·{tag})", self.ENHANCED_SKILL_HOLD, self.ENHANCED_SKILL_WAIT
        )
        if clicked:
            return True
        # 没按进去（被硬直/动画吞了，或者 E 又进了 CD）。**不能直接切人**：
        # 使用者 2026-10-17 反馈"没打强化 E 就切黑羽了"。再连点攒一下、重试一次。
        #
        # 但重试要再花 2~5 秒：窗口不够时必须放弃强化 E、保住二段大。
        # 2026-11-02 实战里就是这里把二段大拖过期了（18:50:38 失败后重试到
        # 18:50:45，距一段大 23s > 20s 窗口 -> "明音大招不可用, 跳过二段大"）。
        if protect_ult2 and self._ult_window_remaining() <= self.ENHANCED_SKILL_RETRY_RESERVE:
            self.logger.warning(
                f"[轮椅轴] 强化 E 没放出来 ({tag}) 且窗口只剩 "
                f"{self._ult_window_remaining():.1f}s, 放弃重试, 直接走二段大"
            )
            return False
        self.logger.warning(f"[轮椅轴] 强化 E 没放出来 ({tag}), 补攒后重试一次")
        self._auto_attack(self.ENHANCED_SKILL_RETRY_WAIT, "强化 E 重试前")
        self._wait_skill_ready()
        with self._animation_guard():
            self.sleep(self.E_CAST_DELAY)
        return self._press_skill_verified(
            f"E(强化·{tag}·重试)", self.ENHANCED_SKILL_HOLD, self.ENHANCED_SKILL_WAIT
        )

    def _wait_skill_ready(self) -> float:
        """E 不可用时用连点普攻补攒弦能；返回等了多久（秒）。

        `charge=False`：补打弦能已经在 `_attack_until_skill_ready` 里做过一次了，
        这里再补一次会让 E 好了却多打 1.2 秒（2026-10-17 实测打了 2.4 秒）。

        等待上限按**大招窗口剩余**动态裁剪：窗口紧的时候不能死等 5 秒，
        否则二段大直接过期（两段大窗口只有 20 秒）。
        """
        timeout = self.ENHANCED_SKILL_TIMEOUT
        remaining = self._ult_window_remaining()
        if remaining > 0:
            # 给二段大留出 AKANE_ULT_2_RESERVE，再多留 0.5 秒给按 E / 收招。
            timeout = min(timeout, max(0.5, remaining - self.AKANE_ULT_2_RESERVE - 0.5))
        start = self.clock.now()
        if not self.skill_available():
            self._attack_until_skill_ready(
                "强化 E 前补打", timeout, charge=False
            )
        return self.clock.now() - start

    def _enhanced_ready(self, wait_seconds: float = 0.0) -> bool:
        """弦能是否已满（强化 E 图标 `akane_skill_2` 是否出现）。

        参考内置 `Akane.perform_ult_combo()`：它在 E 转好时用
        `wait_until(find_one(akane_skill_2), time_out=0.5)` —— 等一小会儿看图标会不会
        出现，而不是查一次就走（图标常常晚一两帧）。传 `wait_seconds` 时我们也等。

        等待期间套 `_animation_guard()`：大招特效盖着血条时，`wait_until` 内部的
        sleep 会被战斗检测误判成脱战（就是之前"卡住不切人"那种）。
        """
        try:
            if wait_seconds > 0:
                with self._animation_guard():
                    return bool(
                        self.task.wait_until(
                            lambda: self.task.find_one(Labels.akane_skill_2),
                            time_out=wait_seconds,
                        )
                    )
            return bool(self.task.find_one(Labels.akane_skill_2))
        except Exception as error:
            self.logger.debug(f"[轮椅轴] 强化 E 图标检测失败: {error}")
            return False

    # ============================== 老板娘动作 ==============================

    def _boss_jump_attacks(self) -> None:
        """跳 A：空格起跳, 空中补一下 A。"""
        for index in range(self.BOSS_JUMP_ATTACKS):
            self.logger.info(f"[轮椅轴] 老板娘 跳A {index + 1}/{self.BOSS_JUMP_ATTACKS}")
            self.send_key("space")
            # 跳 A / 大招后特效期间不要做战斗检测（会被判脱战）。
            with self._animation_guard():
                self.sleep(self.BOSS_JUMP_LIFT)
            self.normal_attack()
            with self._animation_guard():
                self.sleep(self.BOSS_JUMP_LAND)

    def _boss_normal_attacks(self) -> None:
        """落地后连按 A。"""
        self.logger.info(f"[轮椅轴] 老板娘 落地 A x{self.BOSS_NORMAL_ATTACKS}")
        with self._animation_guard():
            for _ in range(self.BOSS_NORMAL_ATTACKS):
                self.normal_attack()
                self.sleep(self.BOSS_ATTACK_INTERVAL)

    def _steal_attacks(self, owner: str, hits: int) -> None:
        """大招动画结束后偷 A；打完留一点收招时间再切人。"""
        self.logger.info(f"[轮椅轴] {owner} 大招动画后偷 A {hits} 下")
        # 偷 A 还在大招尾段, 点左键会触发 check_combat; 包进动画窗口避免误判脱战。
        with self._animation_guard():
            for _ in range(hits):
                self.normal_attack()
                self.sleep(self.STEAL_ATTACK_INTERVAL)
            # 别在普攻挥到一半就切人（动作会断得很难看）。
            if self.STEAL_ATTACK_SETTLE > 0:
                self.logger.info(
                    f"[轮椅轴] {owner} 偷A 收招 {self.STEAL_ATTACK_SETTLE}s 再切人"
                )
                self.sleep(self.STEAL_ATTACK_SETTLE)

    def _wait_team_visible(
        self, label: str, timeout: float, min_wait: float = 0.0
    ) -> bool:
        """等大招动画结束：一旦见过 UI 消失、再看到它回来就立刻返回。

        参考内置 `BaseChar._wait_action_animation()`：轮询 `is_in_team()`，间隔取小
        （0.05s），期间把 `task.in_animation` 置 True —— 框架看到 in_animation 会直接
        认定还在战斗，不会去跑 target_enemy。

        关键规则：**必须先见过一次 UI 消失（`seen_hidden`），恢复后才提前返回**。
        这样"动画确实播完了"才有证据；如果 UI 一直没消失（检测不到动画），就只能
        等满 `timeout` 兜底，而不是一到 `min_wait` 就走（那会让偷 A / E 打在动画里）。
        之前 min_wait 设成 4.0 秒就是为了防这个，但代价是动画 2.5 秒结束后还要
        干站 1.5 秒（使用者反馈"黑羽在发呆"）。
        """
        start = self.clock.now()
        previous_in_animation = self.task.in_animation
        seen_hidden = False
        try:
            while True:
                elapsed = self.clock.now() - start
                if self.task.is_in_team():
                    if seen_hidden and elapsed >= min_wait:
                        self.logger.info(
                            f"[轮椅轴] {label} 动画结束, 等了 {elapsed:.1f}s"
                        )
                        return True
                else:
                    seen_hidden = True
                if elapsed >= timeout:
                    break
                self.task.in_animation = True
                self.sleep(0.05, checks=self.SleepChecks.NONE)
        finally:
            self.task.in_animation = previous_in_animation
        self.logger.info(f"[轮椅轴] {label} 等动画上限 {timeout}s 到了, 继续")
        return False

    # =============================== 按键封装 ===============================

    def _press(self, key: str, label: str, hold: float = 0.05, wait: float = 0.0) -> None:
        """给当前在场角色按一次键, 并把实际按键记进日志（便于事后核对固定轴）。

        按完之后的等待都算"技能/大招动画期间", 用 `_animation_guard()` 跳过战斗检测:
        大招特效会把敌人血条和锁定 UI 一起盖住, 让框架误判脱战（详见 skip_combat_check）。
        """
        self.logger.info(f"[轮椅轴] {self._current_name()} 按 {label} ({key})")
        self.send_key(key, down_time=hold)
        if wait > 0:
            with self._animation_guard():
                self.sleep(wait)
        self.clear_intro()

    def _press_skill(self, label: str, wait: float = 0.0, hold: float = 0.05) -> None:
        self._press(self.get_skill_key(), label, hold, wait)

    def _press_skill_verified(
        self, label: str, hold: float, wait: float, retries: int = 1
    ) -> bool:
        """放 E：交给内置的 `click_skill()`，它会自己重按到技能真的进 CD。

        内置 `click_skill()` 内部是 `_try_available_action()`：只要目标角色的技能还
        可用就继续按键，直到技能进 CD（=真的放出来了）或超时。这正是"按 E 被动画
        吞掉就补按"的官方实现，比自己按一次 + 查 CD 更完整——早雾/浔的技能 CD 图标
        读不出来，手写验证会误判（日志里"按了 2 次, 技能图标始终没进 CD"那种）。

        一定要交给**当前在场角色**执行：`self.skill_available()` 读的是明音自己的
        技能栏，队友在场时得用队友实例（`is_current_char=True` 才会读当前 UI）。

        `retries` 只为兼容旧调用签名，实际由 `click_skill` 内部重试。

        版本适配（v1.4.18 起）：`BaseChar.click_skill()` 的签名是
        ``(down_time=0.05, post_sleep=0, send_click=True, time_out=0)``——
        **已经没有 `has_animation` 参数**（旧版用它控制"放完技能要不要等动画"）。
        新版把"等动画"并进了 `_finish_skill_action()`：只有按键后真的检测到
        `is_in_team()` 消失（技能进了过场/大招镜头）才会等，普通 E 直接返回；
        这个行为等价于原来的 `has_animation=False`，所以这里只传现行参数。

        v1.4.22 起 `click_skill()` 超时（按键发出去了、技能却迟迟没进 CD）会
        `raise_not_in_combat("too long clicking a ultimate")`——它把"技能图标读不出来"
        当成了脱战。早雾/浔的技能 CD 图标本来就经常读不出来，这一下会把整场战斗
        直接结束（`_run_rotation` 上层只放行真脱战）。这里按异常消息识别，吞掉它
        并当作"这次没放出来"继续走下一步。

        **按之前必须先等队伍 UI 回来**：`click_skill()` 第一行判断是 `is_in_team()`，
        不在队伍画面（大招过场/切人动画）时它直接返回 UNAVAILABLE、一个键都不发。
        2026-11-02 实战里早雾 R 后动画超过 2 秒，`_wait_team_visible` 到上限返回，
        紧接着调 click_skill 就 1 毫秒返回"没能放出来"——E 从来没按出去过。
        """
        actor = self.task.get_current_char(raise_exception=False) or self
        self._wait_team_ui(label)
        self.logger.info(f"[轮椅轴] {actor.ufn_name} 按 {label}（click_skill 自动重试）")
        clicked = self._click_skill_once(actor, label, hold)
        if not clicked and self._teammate_skill_ready(actor):
            # 按键被吞/图标状态抖动：技能现在仍可用，补按一次（仍由 click_skill 自己重试）。
            self.logger.info(f"[轮椅轴] {label} 没确认放出但技能仍可用 -> 补按一次")
            clicked = self._click_skill_once(actor, label, hold)
        if clicked:
            self.logger.info(f"[轮椅轴] {label} 确认放出（技能进 CD）")
        else:
            self.logger.warning(f"[轮椅轴] {label} 没能放出来（技能不可用或按键被吞）")
        if wait > 0:
            with self._animation_guard():
                self.sleep(wait)
        return bool(clicked)

    def _click_skill_once(self, actor, label: str, hold: float) -> bool:
        """调一次 `click_skill()`，并把"点击超时"的脱战异常吞掉。"""
        try:
            return bool(
                actor.click_skill(
                    down_time=hold,
                    post_sleep=0,
                    send_click=False,
                    time_out=self.SKILL_CLICK_TIMEOUT,
                )
            )
        except NotInCombatException as error:
            if "too long clicking" not in str(error):
                raise
            self.logger.warning(
                f"[轮椅轴] {label} 点击超时（技能 CD 图标可能读不出来）, 当作没放出来继续"
            )
            return False

    def _wait_team_ui(self, label: str, timeout: float = 0.0) -> bool:
        """等游戏画面回到队伍 UI（`is_in_team()` 为 True）再按键。

        `BaseChar.click_skill()` 和 `click_ultimate()` 的第一步都是 `is_in_team()`：
        不在队伍画面时直接返回、不发任何键。所以大招过场/切人动画里按 E 等于白按。
        这里条件驱动：UI 一回来立刻继续，等不到上限也只记录日志（后面照常尝试按键）。
        """
        timeout = timeout or self.SKILL_UI_WAIT
        if self.task.is_in_team():
            return True
        start = self.clock.now()
        self.logger.info(f"[轮椅轴] {label}: 画面还没回到队伍 UI, 等它回来再按")
        previous_in_animation = self.task.in_animation
        try:
            while self.clock.now() - start < timeout:
                self.task.in_animation = True
                self.sleep(0.05, checks=self.SleepChecks.NONE)
                if self.task.is_in_team():
                    self.logger.info(
                        f"[轮椅轴] {label}: 队伍 UI 回来了（等了 {self.clock.now() - start:.1f}s）"
                    )
                    return True
        finally:
            self.task.in_animation = previous_in_animation
        self.logger.warning(f"[轮椅轴] {label}: 等队伍 UI 超时 {timeout}s, 仍然尝试按键")
        return False

    def _press_ultimate(self, label: str) -> None:
        """给队友（或自己）放大招：发终结技键, 不等动画。

        动画由调用方用 `_wait_team_visible(label, 上限, 最短)` 等——条件驱动,
        动画一结束就走, 不硬等秒数。

        对队友发 `send_ultimate_key` 会改队友实例的可用性标记, 而队友只是执行器外壳,
        不需要维护那套状态；这里统一用裸 `send_key`。
        """
        self._press(self.get_ultimate_key(), label, 0.05)

    def _press_ultimate_verified(
        self, target, label: str, timeout: float = 0.0
    ) -> bool:
        """按大招并**确认真的放出来了**（大招图标从"可用"变"不可用"）。

        返回 True 才值得去等动画；False 说明 R 压根没放出去（能量不够/被吞），
        这时候再等就是让角色站在原地发呆（使用者 2026-10-17 反馈
        "早雾 R 没放成功 在发呆"）。

        判定方式：大招放出去后图标会立刻进入不可用状态，所以按完轮询
        `target.ultimate_available()` 变 False 即视为成功。
        """
        timeout = timeout or self.ULT_VERIFY_TIMEOUT
        try:
            if not self._teammate_ultimate_ready(target):
                self.logger.info(f"[轮椅轴] {label} 能量没满 -> 不按 R")
                return False
            self._press_ultimate(label)
            with self._animation_guard():
                ok = bool(
                    self.task.wait_until(
                        lambda: not self._teammate_ultimate_ready(target),
                        time_out=timeout,
                    )
                )
            if ok:
                self.logger.info(f"[轮椅轴] {label} 确认放出")
            else:
                self.logger.warning(
                    f"[轮椅轴] {label} 没放出来（图标一直可用）, 不等动画直接走"
                )
            return ok
        except Exception as error:
            self.logger.warning(f"[轮椅轴] {label} 校验失败: {error}")
            return False

    def _press_my_ultimate(self, label: str) -> bool:
        """明音自己放大招：按键 → 确认放出 → 放出了才等动画 → 同步状态。"""
        self._press_ultimate(label)
        ok = False
        try:
            with self._animation_guard():
                ok = bool(
                    self.task.wait_until(
                        lambda: not self.ultimate_available(),
                        time_out=self.ULT_VERIFY_TIMEOUT,
                    )
                )
        except Exception as error:
            self.logger.warning(f"[轮椅轴] {label} 校验失败: {error}")
        if ok:
            self.logger.info(f"[轮椅轴] {label} 确认放出")
            self._wait_team_visible(label, self.AKANE_ULT_WAIT, self.AKANE_ULT_MIN_WAIT)
        else:
            self.logger.warning(f"[轮椅轴] {label} 没放出来, 不等动画")
        self._ultimate_available = False
        # 二段大窗口的起点也必须是框架时钟（monotonic），见 `_start_ultimate`。
        self.last_ultimate_time = self.clock.now()
        return ok

    def _press_my_ultimate_if_ready(self, label: str) -> bool:
        """明音二段大：大招可用 + 还在大招窗口内才按。

        窗口过了再按 R，游戏里会放成新的一段大（不是二段大），所以宁可跳过。
        """
        if not self.ultimate_available():
            self.logger.info(f"[轮椅轴] 明音大招不可用, 跳过 {label}")
            return False
        elapsed = (
            self.time_elapsed_accounting_for_freeze(self.last_ultimate_time)
            if self.last_ultimate_time > 0
            else 999.0
        )
        if elapsed > self.AKANE_ULT_WINDOW:
            self.logger.info(
                f"[轮椅轴] 明音大招窗口已过 ({elapsed:.1f}s > "
                f"{self.AKANE_ULT_WINDOW:.0f}s) -> 跳过 {label}"
                "（按了会变成新的一段大）"
            )
            return False
        self.logger.info(f"[轮椅轴] {label}（距一段大 {elapsed:.1f}s，窗口内）")
        self._press_my_ultimate(label)
        return True

    def _teammate_ultimate_ready(self, target) -> bool:
        """判断队友大招（能量）是否就绪。

        目标已经在场时走当前 UI 的颜色/冷却判断；不在场时走 `ultimate_available(index)`
        的图标匹配, 都能在不切人的前提下问一句"能量满了没"。
        """
        try:
            return bool(target.ultimate_available())
        except Exception as error:
            self.logger.debug(f"[轮椅轴] 查询 {getattr(target, 'ufn_name', '?')} 大招失败: {error}")
            return False

    def _teammate_skill_ready(self, target) -> bool:
        """队友的 E 现在能不能按。

        CD 中还去按的话 `click_skill()` 会白等 `SKILL_CLICK_TIMEOUT` 秒才超时，
        所以先问一句，不能按就跳过（比如黑羽二段大那一步，E 往往还没转好）。
        """
        try:
            return bool(target.skill_available())
        except Exception as error:
            self.logger.debug(f"[轮椅轴] 查询 {getattr(target, 'ufn_name', '?')} 技能失败: {error}")
            return False

    # ================================ 切人 =================================

    def _switch_to(self, label: str) -> bool:
        """切到指定队友 / 切回明音; 切成功返回 True。

        这里**不查** `task.in_combat()`: 大招特效期间那一查会被判脱战, 一旦判失败
        `_in_combat` 变 False, 后面所有切人都会直接 return, 表现就是"站着不动、不切人"。
        真脱战由 `_run_rotation` 的循环边界负责; 如果确实已经脱战, 框架的
        `_switch_to_char` 会在 `is_in_team` 连续失败后抛 NotInCombatException 收场。
        """
        target = self if self._is_self_label(label) else self._find_teammate(label)
        if target is None:
            self.logger.warning(f"[轮椅轴] 队伍里找不到 '{label}', 跳过这次切人")
            return False
        if target.is_dead:
            self.logger.warning(f"[轮椅轴] {target.ufn_name} 已阵亡, 跳过这次切人")
            return False
        if target.is_current_char:
            return True
        return self._do_switch(target)

    def _do_switch(self, target) -> bool:
        """手动交人：直接走框架的 `_switch_to_char`。

        不用 `context.request_switch()`: 环合反应的优先级（999500）会盖过普通切人
        请求, 固定轴的目标会被改掉。
        """
        current = self.task.get_current_char(raise_exception=False)
        if current is target:
            return True
        if current is None:
            # 状态兜底: 找不到"当前角色"时手动清掉别处的当前标记, 避免同时有两个在场。
            for char in self.task.chars:
                if char is not None and char is not target:
                    char.is_current_char = False
        # 切人前先稳一下: 刚放完技能/时停收尾时按键会被吞, 框架检测不到就一直轮询，
        # 日志里见过「switch char end 6.561s」（靠 active health change 才确认），
        # 表现就是"该切的人没切，当前角色继续平A"（2026-10-18 反馈）。
        # 这段等待**不空站**：继续连点普攻，既保输出也避免角色站着不动。
        self._click_attack(self.SWITCH_PRESS_DELAY, "切人前")
        self.logger.info(
            f"[轮椅轴] 交人 {current.ufn_name if current else '?'} -> {target.ufn_name}"
        )
        self.task._switch_to_char(
            SwitchDecision(
                target=target,
                reason=f"{self.ufn_name} 轮椅轴交人",
                priority=0,
                has_intro=False,
            ),
            current_char=current,
            # 一定要 False: retry_intro=True 会在切人中途重新跑 planner.decide_switch(),
            # 那里可能拉出环合反应决策, 把固定轴的目标改掉。
            retry_intro=False,
        )
        # 切人动画里画面会短暂"不在队伍中", 也跳过战斗检测, 免得又触发 target_enemy。
        with self._animation_guard():
            self.sleep(self.SWITCH_SETTLE)
        return bool(target.is_current_char)

    def _back_to_mingyin(self) -> None:
        """把站场切回明音自己（只在异常兜底时用）。"""
        if self.is_current_char or self.is_dead:
            return
        self._switch_to("明音")

    def clear_intro(self) -> None:
        """压掉明音的入场标记，别让环合反应替固定轴切人。

        环合反应切人的唯一开关就是当前角色的 `has_intro`
        （`_element_reaction_decision` 第一行 `if not has_intro: return None`），
        而 `decide_switch()` 还会把"协奏值满"也算成有入场资源
        （`has_intro = free_intro or current_char.is_cycle_full()`）。
        本脚本在每步前后、每次按键后都把它压回 False，并且固定轴期间根本不调用
        `switch_next_char()`，两条路一起堵死。
        """
        if self.has_intro:
            self.logger.info("[轮椅轴] 压掉入场标记, 防止环合反应抢人")
        self.has_intro = False

    # ============================ 队友识别 / 诊断 ============================

    # 队友识别用**原型类**, 不用名字: 执行器外壳的 cn_name 是"浔（固定轴）",
    # 使用者也可能改显示名, 用名字匹配会 "no teammate matches"。
    TEAMMATE_CLASSES = (
        ("老板娘", ("Hotori",)),
        ("早雾", ("Sakiri",)),
        ("黑羽", ("Blackbird",)),
    )

    def _find_teammate(self, label: str):
        """在队伍里按标签找队友; 先按原型类匹配, 再退回名字匹配。"""
        if self._is_self_label(label):
            return self

        wanted_classes = ()
        for alias, class_names in self.TEAMMATE_CLASSES:
            if label == alias or label in class_names:
                wanted_classes = class_names
                break

        # 1) 原型类匹配（最稳）: 执行器外壳与社区子类的 MRO 里都有原型类
        if wanted_classes:
            for teammate in self.task.chars:
                if teammate is None or teammate is self:
                    continue
                if set(wanted_classes) & {base.__name__ for base in type(teammate).__mro__}:
                    return teammate

        # 2) 名字匹配（兜底）: 显示名 / 类 cn_name / en_name / 类名, 允许"浔（固定轴）"
        wanted_names = {label.strip().lower()}
        for alias, class_names in self.TEAMMATE_CLASSES:
            if label == alias:
                wanted_names.update(name.lower() for name in class_names)
        for teammate in self.task.chars:
            if teammate is None or teammate is self:
                continue
            names = {
                str(teammate.ufn_name or "").strip(),
                str(getattr(type(teammate), "cn_name", "") or "").strip(),
                str(getattr(type(teammate), "en_name", "") or "").strip(),
                type(teammate).__name__,
            }
            lowered = {name.lower() for name in names if name}
            if lowered & wanted_names:
                return teammate
            for name in lowered:
                if name.split("（")[0].split("(")[0] in wanted_names:
                    return teammate
        return None

    @staticmethod
    def _is_self_label(label: str) -> bool:
        return label in {"明音", "明音凛", "self"}

    def _current_name(self) -> str:
        for char in self.task.chars:
            if char is not None and getattr(char, "is_current_char", False):
                return char.ufn_name
        return "?"

    def _warn_broken_teammates(self) -> None:
        """队友特征识别失败会退化成空壳 BaseChar, 被 planner 当成候选抢站场。

        根因不在脚本而在加载方式: 队友是按"角色特征识别"上场的, 特征没匹配上就降级成
        `BaseChar`。彻底解法是在团队管理里对这套阵容点「固定」（固定队伍直接按槽位加载）。
        这里只负责把问题喊出来, 免得又被当成脚本 bug 查半天。
        """
        broken = [
            index
            for index, char in enumerate(self.task.chars)
            if char is not None and char is not self and type(char).__name__ == "BaseChar"
        ]
        if not broken:
            return
        names = ", ".join(f"位置{index + 1}" for index in broken)
        self.logger.warning(
            f"[轮椅轴] 队友没识别出来, 退化成空壳 BaseChar: {names}; "
            "固定轴会被 planner 抢占, 请在团队管理里对这套阵容点「固定」"
        )

    # ============================== 生命周期 ==============================

    def reset_state(self):
        super().reset_state()
        self._round_index = 0
        self._boss_next_action = "E"
        self._boss_seen_not_ready = True
        self._skip_final_switch = False
        self._entry_step_done = False
        self._session_ref = None

    def on_combat_end(self, chars):
        self._round_index = 0
        self._boss_next_action = "E"
        self._boss_seen_not_ready = True
        self._skip_final_switch = False
        self._entry_step_done = False
        self._session_ref = None
        super().on_combat_end(chars)

    def _wait_ultimate_unfreeze(self, start, click=True):
        """明音等大招 CD 图标刷新时不补普攻: 补点击会把站场时间花在平A上。"""
        return super()._wait_ultimate_unfreeze(start, click=False)

    # ============================ 固定步骤表 ============================
    # 顺序即使用者口径。浔不在这里: 她只在开局放一次 E, 之后按能量插入
    # （见 `_maybe_boss_insert`），每一步之前都会检查一次。
    # 存方法名而不是函数对象: 避免"绑定方法/未绑定函数"混用导致的参数错位。
    LOOP = (
        ("早雾·R+E", "_step_zaowu"),
        ("黑羽·E+大招", "_step_blackbird_open"),
        (
            "明音·开大E+R+连点平A到弦能满+强化E+二段大",
            "_step_akane_burst",
        ),
        ("黑羽·E+大招(二段大)", "_step_blackbird_ult_2"),
        (
            "明音·连点平A到弦能满+强化E",
            "_step_akane_after_ult2",
        ),
    )
