from src.char.BaseChar import BaseChar
from src.combat.planner import (
    ActionIntent,
    CombatContext,
    FieldClaim,
    FollowupStep,
    Planner,
    RoleProfile,
)
from src.Labels import Labels


class Blackbird(BaseChar):
    cn_name = "黑羽 (主C)"
    en_name = "Blackbird (DPS)"
    element = BaseChar.ElementType.BLUE
    ULT_DURATION = 15
    ENH_SKILL_COUNT = 3

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.in_ult = None
        self.claim_after_skill = False

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.MAIN_DPS, field_preference=Planner.FieldPreference.MAIN_DPS
        )

    def combat_plan(self, context):
        claims = []
        ultimate = self.click_ultimate_action()
        skill = self.click_skill_action(
            add_tags=Planner.ActionTag.HIGH_PRIORITY, can_execute=self.should_use_skill
        )

        if not self.claim_after_skill and self.skill_available():
            claims.append(FieldClaim.normal(reason="skill instant cycle"))

        if self.claim_after_skill and self.ultimate_available():
            claims.append(FieldClaim.normal(reason="skill succeeded"))

        def entry():
            self.claim_after_skill = False

            if self.in_ult is None:
                self.in_ult = bool(
                    self.task.wait_until(
                        lambda: self.task.find_one(Labels.blackbird_ult_2),
                        post_action=self.click_with_interval,
                        time_out=0.5,
                    )
                )

            if self.in_ult:
                yield ultimate
                self.in_ult = False

            if (yield skill.repeat_for_entry()):
                self.claim_after_skill = True
                return

            if not (yield ultimate.repeat_for_entry()):
                return

            self.in_ult = True
            try:
                self.perform_in_ult(context, skill)
                yield ultimate.repeat_for_entry()
            finally:
                self.in_ult = False

            if (yield skill.repeat_for_entry()):
                self.claim_after_skill = True

        return self.plan(skill, ultimate, claims=claims, entry=entry)

    def should_use_skill(self, context: CombatContext = None):
        return (
            not self.has_element_reaction_teammate()
            or not self.is_cycle_full()
            or (
                context is not None
                and context.strict_route_wants_action(self, slot=Planner.ActionSlot.SKILL)
            )
        )

    def perform_in_ult(self, context: CombatContext, skill: ActionIntent):
        self.logger.info("start perform_in_ult")
        start = self.now()
        skill_count = 0
        normal_attack_deadline = None
        while (elapsed := self.now() - start) < self.ULT_DURATION:
            if normal_attack_deadline is not None and self.now() >= normal_attack_deadline:
                break
            if elapsed > 1 and not self.ultimate_available(False):
                break
            if (
                skill_count < self.ENH_SKILL_COUNT
                and context.is_action_allowed(self, skill)
                and self.click_skill()
            ):
                skill_count += 1
            if skill_count >= self.ENH_SKILL_COUNT and normal_attack_deadline is None:
                normal_attack_deadline = self.now() + 0.9
            self.normal_attack()
            self.sleep(0.1)
        self.logger.info("end perform_in_ult")

    def reset_state(self):
        super().reset_state()
        self.in_ult = None
        self.claim_after_skill = False

    def on_combat_end(self, chars):
        super().on_combat_end(chars)
        self.in_ult = None
        self.claim_after_skill = False

    def _wait_ultimate_unfreeze(self, start, click=True):
        if self.in_ult:
            return super()._wait_ultimate_unfreeze(start, click)
        wait = 2.6
        if click:
            self.continues_normal_attack(wait)
        else:
            self.sleep(wait)
        duration = self.now() - start
        self.add_freeze_duration(start, duration)
        return duration
