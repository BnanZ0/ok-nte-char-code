"""Adler shield support for the community no-DPS package."""

from src.char.Adler import Adler
from src.combat.planner import CombatContext, Planner, RoleProfile


class CommunityAdlerNoDps(Adler):
    """Deploy the shield, optionally cast Q, and return field time to Zankou."""

    cn_name = "阿德勒（社区无 DPS）"
    en_name = "Adler (Community, No DPS)"

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self, context: CombatContext):
        skill = self.click_skill_action(add_tags=Planner.ActionTag.TEAM_BUFF)
        ultimate = self.click_ultimate_action()

        def entry():
            if self.skill_available() and context.is_action_allowed(self, skill):
                self.continues_normal_attack(1.5)
            skill_result = yield skill
            if skill_result:
                self.sleep(0.5)
                yield ultimate

        return self.plan(skill, ultimate, entry=entry)
