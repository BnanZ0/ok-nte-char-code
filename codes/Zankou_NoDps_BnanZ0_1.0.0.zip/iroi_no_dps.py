"""Iroi support for the community no-DPS package."""

from src.char.Iroi import Iroi
from src.combat.planner import Planner, RoleProfile


class CommunityIroiNoDps(Iroi):
    """Fast E/Q support with a short heal-settle delay after E."""

    cn_name = "伊洛伊（社区无 DPS）"
    en_name = "Iroi (Community, No DPS)"
    HEAL_SKILL_SETTLE_TIME = 0.8

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self, context):
        skill = self.click_skill_action(add_tags=Planner.ActionTag.TEAM_BUFF)
        ultimate = self.click_ultimate_action()
        return self.plan(skill, ultimate)

    def click_skill(self, *args, **kwargs):
        kwargs.setdefault("post_sleep", self.HEAL_SKILL_SETTLE_TIME)
        return super().click_skill(*args, **kwargs)
