"""Community setup rotation for Daffodill."""

from src.char.Daffodill import Daffodill
from src.combat.planner import CombatContext, Planner, RoleProfile


class CommunityDaffodill(Daffodill):
    """首个 Q 最多充能六秒，亮起后立即释放并快速离场。"""

    cn_name = "达芙蒂尔（社区版）"
    en_name = "Daffodill (Community)"
    FIRST_Q_CHARGE_SECONDS = 6.0
    HEAVY_ATTACK_TIME = 0.45
    ULT_BURST_DURATION = 0.5

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._charge_session = None

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def _first_charge_pending(self):
        return self._charge_session is not getattr(self.task, "combat_session", None)

    def combat_plan(self, context: CombatContext):
        ultimate = self.click_ultimate_action()
        skill = self.click_skill_action()
        charge = self.planner_action(
            tags={Planner.ActionTag.SUPPORT, Planner.ActionTag.TEAM_BUFF},
            slot=Planner.ActionSlot.CUSTOM,
            execute=lambda _: self._charge_first_q(context, skill),
            name="community_daffodill_first_q",
            reason="达芙首 Q：最多 6 秒重击充能，亮起立即释放",
            can_execute=lambda _: self._first_charge_pending()
            and not self.ultimate_available(),
            priority_ready=lambda _: self._first_charge_pending()
            and not self.ultimate_available(),
        )

        def entry():
            if self.ultimate_available():
                q_result = yield ultimate
                if q_result:
                    self._charge_session = getattr(self.task, "combat_session", None)
                    self._perform_burst(context, skill)
                    return
            if self._first_charge_pending():
                yield charge
                return
            yield skill

        return self.plan(charge, ultimate, skill, entry=entry)

    def _charge_first_q(self, context: CombatContext, skill):
        self._charge_session = getattr(self.task, "combat_session", None)
        deadline = self.now() + self.FIRST_Q_CHARGE_SECONDS
        while self.now() < deadline and not self.ultimate_available():
            self.heavy_attack(duration=self.HEAVY_ATTACK_TIME)
            self.sleep(0.05)

        if not self.ultimate_available():
            self.logger.info("community Daffodill: first-Q charge timed out")
            return False

        q_result = self.click_ultimate()
        if q_result:
            self._perform_burst(context, skill)
        return bool(q_result)
