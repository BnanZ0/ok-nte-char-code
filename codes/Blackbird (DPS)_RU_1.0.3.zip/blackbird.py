from src.char.BaseChar import BaseChar
from src.combat.planner import (
    FieldClaim,
    Planner,
    RoleProfile,
)
from src.Labels import Labels


class Blackbird(BaseChar):
    cn_name = "黑羽 (主C)"
    en_name = "Blackbird (DPS)"
    element = BaseChar.ElementType.BLUE
    ULT_DURATION = 15
    ENH_SKILL_COUNT = 3

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.in_ult = None
        self.claim_after_skill = False

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.MAIN_DPS, field_preference=Planner.FieldPreference.MAIN_DPS
        )

    def combat_plan(self):
        plan = self.plan()
        self.register_skill(
            plan,
            add_tags=Planner.ActionTag.HIGH_PRIORITY,
            can_execute=lambda: self.in_ult or self.should_use_skill(),
        )
        self.register_ultimate(plan)
        if not self.claim_after_skill and self.skill_available():
            plan.add(FieldClaim.normal(reason="skill instant cycle"))
        if self.claim_after_skill and self.ultimate_available():
            plan.add(FieldClaim.normal(reason="skill succeeded"))
        plan.entry = self.perform_entry
        return plan

    def perform_entry(self):
        self.claim_after_skill = False
        if self.in_ult is None:
            self.in_ult = bool(
                self.task.wait_until(
                    lambda: self.task.find_one(Labels.blackbird_ult_2),
                    post_action=self.click_with_interval,
                    time_out=0.5,
                )
            )
        if self.in_ult:
            self.click_ultimate()
            self.in_ult = False
        if self.click_skill():
            self.claim_after_skill = True
            return
        if not self.click_ultimate():
            return
        self.in_ult = True
        try:
            self.perform_in_ult()
            self.click_ultimate()
        finally:
            self.in_ult = False
        if self.click_skill():
            self.claim_after_skill = True

    def should_use_skill(self):
        return (
            not self.has_element_reaction_teammate()
            or not self.is_cycle_full()
            or self.combat_context.strict_route_wants_action(self, slot=Planner.ActionSlot.SKILL)
        )

    def perform_in_ult(self):
        self.logger.info("start perform_in_ult")
        start = self.clock.now()
        timer = self.clock.timer(timeout=self.ULT_DURATION)
        skill_count = 0
        normal_attack_timer = None
        while not timer.expired():
            if normal_attack_timer is not None and normal_attack_timer.expired():
                break
            if self.clock.now() - start > 1 and not self.ultimate_available(False):
                break
            if skill_count < self.ENH_SKILL_COUNT and self.click_skill():
                skill_count += 1
            if skill_count >= self.ENH_SKILL_COUNT and normal_attack_timer is None:
                normal_attack_timer = self.clock.timer(timeout=0.9)
            self.normal_attack()
            self.sleep(0.1)
        self.logger.info("end perform_in_ult")

    def reset_state(self):
        super().reset_state()
        self.in_ult = None
        self.claim_after_skill = False

    def on_combat_end(self, chars):
        super().on_combat_end(chars)
        self.in_ult = None
        self.claim_after_skill = False

    def _wait_ultimate_unfreeze(self, start, click=True):
        wait = 2 if self.in_ult else 2.6
        if click:
            self.continues_normal_attack(wait)
        else:
            self.sleep(wait)
        duration = self.clock.now() - start
        self.add_freeze_duration(start, duration)
        return duration
