"""残虹倾陷早雾分支的阿德勒护盾轮转。"""

from src.char.Adler import Adler
from src.combat.planner import CombatContext, Planner, RoleProfile


class CommunityAdlerSakiri(Adler):
    """部署护盾，按情况释放 Q，然后把站场时间交还给残虹。"""

    cn_name = "阿德勒（早雾分支）"
    en_name = "Adler (Sakiri Branch)"

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self, context: CombatContext):
        skill = self.click_skill_action(add_tags=Planner.ActionTag.TEAM_BUFF)
        ultimate = self.click_ultimate_action()

        def entry():
            if self.skill_available() and context.is_action_allowed(self, skill):
                self.continues_normal_attack(1.5)
            skill_result = yield skill
            if skill_result:
                self.sleep(0.5)
                yield ultimate

        return self.plan(skill, ultimate, entry=entry)
