"""残虹倾陷早雾分支的残虹轮转。"""

from src.char.Zankou import Zankou
from src.combat.planner import Planner


class CommunityZankouSakiri(Zankou):
    """点亮强化 E，并在紫 E 窗口完成双 Q。"""

    cn_name = "残虹（早雾分支）"
    en_name = "Zankou (Sakiri Branch)"
    COMBO_TIMEOUT = 10.0
    HEAVY_ATTACK_TIME = 0.45
    PURPLE_ULTIMATE_WAIT = 3.0

    def combat_plan(self, context):
        ultimate = self.click_ultimate_action()
        skill_combo = self.planner_action(
            tags={
                Planner.ActionTag.DEFAULT_ACTION,
                Planner.ActionTag.DAMAGE,
                Planner.ActionTag.SKILL_ACTION,
                Planner.ActionTag.COORDINATION_FINISHER,
            },
            slot=Planner.ActionSlot.SKILL,
            execute=lambda _: self.perform_skill_combo(),
            name="community_zankou_sakiri_skill_combo",
            reason="残虹重击点亮黄 E，并在紫 E 窗口完成双 Q",
            can_execute=lambda _: True,
            priority_ready=lambda _: True,
        )

        def entry():
            if not self.find_ult_purple():
                combo_result = yield skill_combo
                if combo_result:
                    self.task.wait_until(
                        self.find_ult_purple,
                        post_action=self.click_with_interval,
                        time_out=self.PURPLE_ULTIMATE_WAIT,
                    )

            if self.find_ult_purple():
                first_q = yield ultimate
                if first_q:
                    self.task.wait_until(
                        self.ultimate_available,
                        post_action=self.click_with_interval,
                        time_out=3.0,
                    )
                    yield ultimate.repeat_for_entry()

        return self.plan(skill_combo, ultimate, entry=entry)

    def perform_skill_combo(self):
        """依据技能视觉状态执行轮转，并为循环设置明确时限。"""

        deadline = self.now() + self.COMBO_TIMEOUT
        clicked_skill = False

        while self.now() < deadline:
            feature = self.find_zankou_skill()
            if feature:
                skill_clicked, _ = self.click_zankou_skill()
                clicked_skill = clicked_skill or bool(skill_clicked)
                if self.find_ult_purple():
                    break
            else:
                self.heavy_attack(duration=self.HEAVY_ATTACK_TIME)

            self.sleep(0.1)
            if self.find_ult_purple():
                break

            try:
                self.task.mouse_down()
                for _ in range(5):
                    if self.find_zankou_skill() or self.find_ult_purple():
                        break
                    self.sleep(0.1)
            finally:
                self.task.mouse_up()

        return clicked_skill
