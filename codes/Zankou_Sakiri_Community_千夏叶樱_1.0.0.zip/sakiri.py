"""残虹倾陷早雾分支的增益轮转。"""

from src.char.Sakiri import Sakiri
from src.combat.planner import Planner, RoleProfile


class CommunitySakiri(Sakiri):
    """以 Q→E 的短切顺序提供攻击增益、减防和持续伤害增益。"""

    cn_name = "早雾（残虹倾陷）"
    en_name = "Sakiri (Zankou Team)"

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUPPORT,
            field_preference=Planner.FieldPreference.SETUP_ONLY,
            max_field_time=0,
        )

    def combat_plan(self, context):
        ultimate = self.click_ultimate_action(add_tags=Planner.ActionTag.TEAM_BUFF)
        skill = self.click_skill_action(
            add_tags=Planner.ActionTag.TEAM_BUFF,
            down_time=0.25,
        )
        return self.plan(ultimate, skill)
