"""伊洛伊（1觉残安早伊合轴队）。

排轴定位：援护入场 + e 秒切合轴 / qza 输出段。通过共享模块（zankou.py）
获取全队排轴状态机；本文件自身不持有状态机定义。
"""

import sys


def _load_team_module():
    """加载同目录 zankou.py 内的全队共享排轴状态机（模块级共享实例）。

    外置角色文件之间无法直接 import（注册器把每个文件按独立模块加载），
    这里通过固定的 sys.modules key 共享 zankou.py 的一份模块实例；
    按文件 mtime 失效缓存，zankou.py 更新并重新扫描后自动取到新代码。
    """
    import importlib.util
    from pathlib import Path

    key = "_aczy_zankou_team_module"
    team_path = Path(__file__).resolve().with_name("zankou.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_IROI_E = _team.STAGE_IROI_E
STAGE_IROI_QZA = _team.STAGE_IROI_QZA
STAGE_OPEN_IROI_E = _team.STAGE_OPEN_IROI_E
STAGE_OPEN_IROI_QZA = _team.STAGE_OPEN_IROI_QZA
get_rotation = _team.get_rotation
make_rotation_next_action = _team.make_rotation_next_action

from src.char.Support import Support
from src.combat.planner import Planner


class Iroi(Support):
    cn_name = "伊洛伊（合轴队）"
    en_name = "Iroi (Team Rotation)"
    element = Support.ElementType.GREEN

    # 排轴时值（可按实测微调）
    SKILL_CD_CONFIRM_SLEEP = 0.8   # 按下 e 后等治疗结算
    HEAVY_ATTACK_DURATION = 0.8    # z 长按重击时长
    HEAVY_POST_SLEEP = 0.2         # z 收招后的缓冲

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._mouse_pressed = False

    def combat_plan(self, context):
        rotation = get_rotation(self.task)
        skill = self.click_skill_action(add_tags=Planner.ActionTag.TEAM_BUFF)
        ultimate = self.click_ultimate_action()
        qza = self.planner_action(
            tags={Planner.ActionTag.DEFAULT_ACTION},
            slot=None,
            execute=lambda _: self.perform_qza(),
            name="iroi_qza",
            reason="iroi q z a1",
        )
        rotation_next = make_rotation_next_action(self, rotation)
        rotation_retry = make_rotation_next_action(self, rotation, advance=False, check_cycle=False)

        def entry():
            stage = rotation.stage_for(self)
            self.logger.info(
                f"[rotation] Iroi entry stage={stage} current={rotation.current_stage()} "
                f"queue={rotation.queue} looping={rotation.looping}"
            )
            if stage in (STAGE_OPEN_IROI_E, STAGE_IROI_E):
                # 援护入场（援护动画由框架 wait_intro 处理）→ e → 秒切人合轴
                # 即使 E 攒满能量也不能就地放 Q：排轴要求先 E 切人合轴，
                # 再切回来进 IROI_QZA 放 Q，避免打乱切人合轴节奏
                yield skill
                self.sleep(self.SKILL_CD_CONFIRM_SLEEP)
                yield rotation_next
            elif stage in (STAGE_OPEN_IROI_QZA, STAGE_IROI_QZA):
                # 切回来放 qza：q -> z -> a1（开头已放 Q，z+a1 不会再攒满能量）
                if self.ultimate_available():
                    yield ultimate
                yield qza
                yield rotation_next
            else:
                # 非排轴期望的意外入场：兜底 QE 后请求切回排轴
                if self.ultimate_available():
                    yield ultimate
                if self.skill_available():
                    yield skill
                yield rotation_retry

        return self.plan(skill, ultimate, qza, entry=entry)

    def perform_qza(self):
        """z 长按重击 + a1 普攻。"""
        self.heavy_attack(self.HEAVY_ATTACK_DURATION)
        self.sleep(self.HEAVY_POST_SLEEP)
        self.click()
        return True

    def click_ultimate(self, send_click=True, wait_if_no_cd=0):
        try:
            if ret := super().click_ultimate(send_click=send_click, wait_if_no_cd=wait_if_no_cd):
                self.sleep(0.7)
            return ret
        finally:
            if self._mouse_pressed:
                self.task.mouse_up()
            self._mouse_pressed = False

    def _wait_ultimate_unfreeze(self, start, click=False):
        self.task.mouse_down()
        self._mouse_pressed = True
        return super()._wait_ultimate_unfreeze(start=start, click=click)
