"""早雾（1觉残安早伊合轴队）。

排轴定位：固定首发 + 交替段增益插入。通过共享模块（zankou.py）获取
全队排轴状态机；本文件自身不持有状态机定义。
"""

import sys


def _load_team_module():
    """加载同目录 zankou.py 内的全队共享排轴状态机（模块级共享实例）。

    外置角色文件之间无法直接 import（注册器把每个文件按独立模块加载），
    这里通过固定的 sys.modules key 共享 zankou.py 的一份模块实例；
    按文件 mtime 失效缓存，zankou.py 更新并重新扫描后自动取到新代码。
    """
    import importlib.util
    from pathlib import Path

    key = "_aczy_zankou_team_module"
    team_path = Path(__file__).resolve().with_name("zankou.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_OPEN_SAKIRI = _team.STAGE_OPEN_SAKIRI
STAGE_SAKIRI_QE = _team.STAGE_SAKIRI_QE
get_rotation = _team.get_rotation
make_rotation_next_action = _team.make_rotation_next_action

from src.char.Support import Support
from src.combat.planner import Planner


class Sakiri(Support):
    cn_name = "早雾（合轴队）"
    en_name = "Sakiri (Team Rotation)"
    element = Support.ElementType.RED

    # 1觉残虹排轴：早雾固定首发
    COMBAT_START_PRIORITY = 10
    # 按下 e 后等待图标进入 CD 的确认时间
    SKILL_CD_CONFIRM_SLEEP = 0.3

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def describe_role(self):
        profile = super().describe_role()
        profile.combat_start_priority = self.COMBAT_START_PRIORITY
        return profile

    def combat_policies(self, context):
        """planner reset 队伍时：重置排轴状态机并锁定切人目标（每场战斗一次）。"""
        rotation = get_rotation(self.task)
        self.logger.info(
            f"[rotation] combat_policies reset (queue was {rotation.queue}, "
            f"looping={rotation.looping})"
        )
        rotation.reset()
        # 固定排轴需要确定性切人：环合满时 planner 的元素反应决策优先级
        # （999500）高于切人请求（998000），会按元素环邻居改切目标（本队
        # 会被改切到早雾/安魂曲），打乱固定轮转。这里禁用该自动改切；
        # 环合反应与援护仍会在固定切人路径上由游戏自动触发并记录。
        self.task.find_element_reaction_target = lambda source_char: None

    def combat_plan(self, context):
        rotation = get_rotation(self.task)
        ultimate = self.click_ultimate_action(add_tags=Planner.ActionTag.TEAM_BUFF)
        skill = self.click_skill_action(add_tags=Planner.ActionTag.TEAM_BUFF, down_time=0.25)
        rotation_next = make_rotation_next_action(self, rotation)
        rotation_retry = make_rotation_next_action(self, rotation, advance=False, check_cycle=False)

        def entry():
            stage = rotation.stage_for(self)
            self.logger.info(
                f"[rotation] Sakiri entry stage={stage} current={rotation.current_stage()} "
                f"queue={rotation.queue} looping={rotation.looping}"
            )
            if stage in (STAGE_OPEN_SAKIRI, STAGE_SAKIRI_QE):
                # 有 Q 放 Q，然后放 E（E 图标进 CD 后立刻切人）
                if self.ultimate_available():
                    yield ultimate
                yield skill
                self.sleep(self.SKILL_CD_CONFIRM_SLEEP)
                # 切人前最后检测一次大招：e/援护可能刚把能量攒满，有大开大以免断 buff
                # （repeat_for_entry 允许同一次 entry 在开头放过 Q 后再检测一次）
                if self.ultimate_available():
                    yield ultimate.repeat_for_entry()
                yield rotation_next
            else:
                # 非排轴期望的意外入场：兜底 QE 后请求切回排轴
                if self.ultimate_available():
                    yield ultimate
                if self.skill_available():
                    yield skill
                # 切人前再检测一次大招，避免脱轴入场时漏掉满能量大招
                if self.ultimate_available():
                    yield ultimate.repeat_for_entry()
                yield rotation_retry

        return self.plan(ultimate, skill, entry=entry)
