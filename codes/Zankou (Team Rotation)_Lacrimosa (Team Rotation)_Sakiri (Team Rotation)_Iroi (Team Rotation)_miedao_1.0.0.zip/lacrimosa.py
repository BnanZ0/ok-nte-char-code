"""安魂曲（1觉残安早伊合轴队）。

排轴定位：远程合轴 + E 番茄酱恶魔。通过共享模块（zankou.py）获取
全队排轴状态机；本文件自身不持有状态机定义。

注意：远程模式的 G 键由玩家开战前手动按（整场一次），脚本不按 G；
安魂曲入场即远程形态，直接 QE。
"""

import sys


def _load_team_module():
    """加载同目录 zankou.py 内的全队共享排轴状态机（模块级共享实例）。

    外置角色文件之间无法直接 import（注册器把每个文件按独立模块加载），
    这里通过固定的 sys.modules key 共享 zankou.py 的一份模块实例；
    按文件 mtime 失效缓存，zankou.py 更新并重新扫描后自动取到新代码。
    """
    import importlib.util
    from pathlib import Path

    key = "_aczy_zankou_team_module"
    team_path = Path(__file__).resolve().with_name("zankou.py")
    try:
        stamp = team_path.stat().st_mtime_ns
    except OSError:
        stamp = None
    cached = sys.modules.get(key)
    if cached is not None and getattr(cached, "_TEAM_SOURCE_STAMP", None) == stamp:
        return cached
    spec = importlib.util.spec_from_file_location(key, team_path)
    module = importlib.util.module_from_spec(spec)
    module._TEAM_SOURCE_STAMP = stamp
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


_team = _load_team_module()
STAGE_FUSION = _team.STAGE_FUSION
STAGE_LACRI_E = _team.STAGE_LACRI_E
STAGE_OPEN_LACRI = _team.STAGE_OPEN_LACRI
get_rotation = _team.get_rotation
make_rotation_next_action = _team.make_rotation_next_action

from src.char.BaseChar import BaseChar
from src.combat.planner import Planner, RoleProfile


class Lacrimosa(BaseChar):
    cn_name = "安魂曲（合轴队）"
    en_name = "Lacrimosa (Team Rotation)"
    element = BaseChar.ElementType.PURPLE

    # 排轴时值（可按实测微调）
    SKILL_POST_CAST_SLEEP = 0    # E 按下后即切人（E 总动画 3s 在后台继续播放）
    REMOTE_ATTACK_INTERVAL = 0.3   # a1远/a2远/a3远 每段间隔（按实测调快）

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def describe_role(self):
        return RoleProfile(
            role=Planner.Role.SUB_DPS,
            field_preference=Planner.FieldPreference.SUB_DPS,
            max_field_time=3.5,
        )

    def combat_plan(self, context):
        rotation = get_rotation(self.task)
        ultimate = self.click_ultimate_action(reason="lacrimosa Q available")
        skill = self.click_skill_action(reason="lacrimosa E available")
        remote_fusion = self.planner_action(
            tags={Planner.ActionTag.DEFAULT_ACTION},
            slot=None,
            execute=lambda _: self.perform_remote_fusion(),
            name="lacrimosa_remote_fusion",
            reason="lacrimosa remote fusion a1a2a3 + pre-input",
        )
        rotation_next = make_rotation_next_action(self, rotation)
        rotation_retry = make_rotation_next_action(self, rotation, advance=False, check_cycle=False)

        def entry():
            stage = rotation.stage_for(self)
            self.logger.info(
                f"[rotation] Lacrimosa entry stage={stage} current={rotation.current_stage()} "
                f"queue={rotation.queue} looping={rotation.looping}"
            )
            if stage == STAGE_OPEN_LACRI:
                # 首次入场（远程模式已由玩家手动按 G 开启）：Q → E 番茄酱恶魔 → 等 1.1s 切人
                if self.ultimate_available():
                    yield ultimate
                yield skill
                self.sleep(self.SKILL_POST_CAST_SLEEP)
                yield rotation_next
            elif stage == STAGE_LACRI_E:
                # 1觉循环：Q → E（按下后即切人，动画后台继续）
                if self.ultimate_available():
                    yield ultimate
                yield skill
                self.sleep(self.SKILL_POST_CAST_SLEEP)
                yield rotation_next
            elif stage == STAGE_FUSION:
                # 1觉循环远程合轴：有 Q 先放 Q（时停大招）→ a1远 a2远 a3远 + 预输入（a4远 后台）
                if self.ultimate_available():
                    yield ultimate
                yield remote_fusion
                yield rotation_next
            else:
                # 非排轴期望的意外入场：兜底 Q + E + 远程普攻后请求切回排轴
                if self.ultimate_available():
                    yield ultimate
                if self.skill_available():
                    yield skill
                    self.sleep(self.SKILL_POST_CAST_SLEEP)
                yield remote_fusion
                yield rotation_retry

        return self.plan(ultimate, skill, remote_fusion, entry=entry)

    def perform_remote_fusion(self):
        """远程普攻 a1远/a2远/a3远，a4远 由切人检测点击触发后台释放。

        每段间隔 REMOTE_ATTACK_INTERVAL。只打 3 下普攻（a1/a2/a3），第 4 下
        输入由框架 _switch_to_char 的 switch_char_click 提供——它既用于切人
        检测（造成血量变化），又恰好充当 a4 远的输入，切人后由安魂曲后台
        自动释放。不在这里多按一下，否则会与切人检测点击叠加成 a5。
        """
        for _ in range(3):
            self.click()
            self.sleep(self.REMOTE_ATTACK_INTERVAL)
        return True

    def wait_intro(self, time_out=-1, click=False):
        """安魂曲入场不等援护动画。

        默认 wait_intro 会 sleep 约 1.5s（INTRO_MOTION_FREEZE_DURATION），首轮
        带援护入场时会多出一段无动作停顿；1觉循环里不带援护入场本来也不走这里。
        援护动画在后台自行播放，排轴节奏由 entry 自行控制，直接 QE。
        """
        return

    def on_combat_end(self, chars):
        self.switch_other_char()
